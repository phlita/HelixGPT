# HelixGPT — 螺旋时空生成预训练转换器
# Spiral Space-Time Generative Pre-trained Transformer

> **"如果 HelixGPT 成功收敛，它可能只需要区区几亿个参数，就能在极短的训练时间内，展现出远超传统百亿级大模型的深度因果推理能力。"**

---

## 概述 | Overview

HelixGPT 是一个基于 **张祥前统一场论** 重新设计的下一代语言模型架构。它从根本上抛弃了传统 Transformer 的核心假设——欧几里得空间中的点积和玻尔兹曼分布——转而采用**圆柱螺旋流形（Cylindrical Helix Manifold）**上的干涉运算。

### 核心创新

| 传统 Transformer | HelixGPT | 物理动机 |
|---|---|---|
| 实数向量嵌入 R^d | **(振幅, 相位) 对** | 每个Token是一个旋转的微观时空涡旋 |
| 点积注意力 Q·K | **相位干涉** \|q\|\|k\|cos(Δθ)·f(Δθ) | 时空引力场干涉而非概率匹配 |
| RoPE (2D旋转) | **Helix-RoPE** (3D螺旋位移) | 增加Z轴光速发散分量 |
| Softmax (封闭热力学) | **HelixSoftmax** (开放系统) | 信息可沿Z轴"逃逸"到无穷远 |
| RoPE/Alibi衰减 | **拓扑衰减** α=1/(4π³+π²+π) | 宇宙几何锁相常数 ≈ 1/137 |
| ReLU/SiLU | **相变雪崩激活** | 低应力平滑 + 高应力"果冻坍缩" |

### 拓扑常数

```
α_geom = 1 / (4π³ + π² + π) ≈ 0.00716 ≈ 1/139.72
```

这个常数不是人为设定的超参数，而是从圆柱螺旋流形的拓扑约束中**推导**出来的，与真实物理中的精细结构常数 (≈1/137) 极其接近。

---

## 项目结构

```
HelixGPT/
├── helixgpt/                    # 核心模块
│   ├── __init__.py              # 包入口
│   ├── constants.py             # 物理常数 (α_geom, 拓扑量子数, etc.)
│   ├── config.py                # HelixConfig + 预设配置 (60M/100M/350M/1B)
│   ├── spacetime_embedding.py   # 时空旋量嵌入层
│   ├── helix_rope.py            # 3D圆柱螺旋位置编码 (Helix-RoPE)
│   ├── helix_attention.py       # 螺旋干涉注意力机制
│   ├── phase_transition.py      # 拓扑衰减 + 相变雪崩激活 + HelixSoftmax
│   ├── model.py                 # HelixGPT 主模型 (HelixMLP + HelixBlock + HelixGPT)
│   └── tokenizer.py             # 分词器工具
├── scripts/
│   ├── train.py                 # 训练脚本
│   ├── generate.py              # 文本生成脚本 (支持交互模式)
│   └── test_helixgpt.py         # 完整测试套件
├── configs/
│   ├── helixgpt-60M.yaml        # 60M参数配置
│   └── helixgpt-100M.yaml       # 100M参数配置
├── litgpt/                      # LitGPT 框架 (上游依赖)
└── README.md                    # 本文件
```

---

## 快速开始 | Quick Start

### 1. 安装依赖

```bash
pip install torch transformers
```

### 2. 运行测试（验证所有组件）

```bash
cd HelixGPT
python scripts/test_helixgpt.py --model helixgpt-60M

# 如果有GPU:
python scripts/test_helixgpt.py --model helixgpt-100M --cuda
```

### 3. 训练

```bash
# 准备训练数据 (纯文本文件)
python scripts/train.py \
    --model helixgpt-60M \
    --data path/to/your_training_text.txt \
    --output-dir checkpoints \
    --batch-size 8 \
    --learning-rate 3e-4 \
    --epochs 10
```

### 4. 生成

```bash
# 单次生成
python scripts/generate.py \
    --checkpoint checkpoints/helixgpt-60M/final.pt \
    --prompt "The fundamental nature of the universe is" \
    --max-tokens 256

# 交互模式
python scripts/generate.py \
    --checkpoint checkpoints/helixgpt-60M/final.pt \
    --interactive \
    --max-tokens 512
```

---

## 架构详解 | Architecture Deep Dive

### 1. 时空旋量嵌入 (Spacetime Spinor Embedding)

传统: Token → 死的向量 x ∈ R^d
HelixGPT: Token → 旋转的涡旋 Ψ_n = A·e^(i(ωt-θ))

实现：将嵌入维度一分为二
- 前半: x_radial（径向振幅，电磁分量/显性信息）
- 后半: x_angular（角相位，引力分量/隐性上下文）

### 2. 螺旋干涉注意力 (Helix Interference Attention)

传统: score = Q·K^T / √d （余弦相似度）
HelixGPT:
```
Interference(q, k) = |q|·|k|·cos(θ_q - θ_k)·(1 + α·sin(θ_q - θ_k))
```
- 振幅乘积 → 能量标度
- 余弦相位差 → 建设性/破坏性干涉
- 残余耦合函数 → 打破对称性

### 3. Helix-RoPE (3D圆柱螺旋位置编码)

传统RoPE只在XY平面旋转（2D），Helix-RoPE增加了Z轴分量：
- XY旋转: 标准RoPE（引力/角动量约束）
- Z轴位移: c·pitch·t（光速信息发散）

### 4. 相变雪崩 (Phase Transition Avalanche)

双状态激活：
- 低应力（T_stress < 阈值）: 平滑线性映射，维持上下文连贯
- 高应力（T_stress ≥ 阈值）: 拓扑坍缩！产生稀疏的创造性激波

---

## 预设模型 | Model Presets

| 模型 | 层数 | 嵌入维度 | 注意力头 | 上下文 | 预估参数 |
|------|------|----------|----------|--------|----------|
| helixgpt-60M  | 6  | 512  | 8  | 1024 | ~60M |
| helixgpt-100M | 12 | 768  | 12 | 2048 | ~100M |
| helixgpt-350M | 24 | 1024 | 16 | 4096 | ~350M |
| helixgpt-1B   | 24 | 2048 | 32 | 4096 | ~1B |

---

## 基于LitGPT框架

HelixGPT建立在 [Lightning AI 的 LitGPT](https://github.com/Lightning-AI/litgpt) 框架之上，
遵循其模块化设计哲学：
- 复用 LitGPT 的 RMSNorm、KV Cache 基础设施
- 完全替换注意力机制（CausalSelfAttention → HelixInterferenceAttention）
- 完全替换位置编码（2D RoPE → 3D Helix-RoPE）
- 完全替换激活函数（SiLU → PhaseTransitionAvalanche）
- 新增时空旋量嵌入层

---

## 物理灵感 | Physical Inspiration

本项目的数学基础来源于张祥前的统一场论。核心理念：

> 现有的主流大模型本质上是"经典物理与统计力学"的产物——它们在"三维螺旋空间的低维二维阴影"中盲目地拟合数据，这是极其低效、且永远无法触及"智能本质（因果律）"的旧物理理论。

HelixGPT 直接在信息空间中构建一个"微型宇宙"：
- 圆柱螺旋流形作为信息载体
- 相位干涉代替概率计算
- 拓扑常数约束信息衰减
- 相变机制模拟创造性跳跃

---

## License

Apache License 2.0 (继承自 LitGPT)
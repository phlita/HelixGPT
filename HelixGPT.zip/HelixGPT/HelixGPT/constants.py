"""
Universal Physical Constants for HelixGPT

Derived from Zhang Xiangqian's Unified Field Theory.
These constants replace the ad-hoc hyperparameters of traditional transformers
with physically motivated geometric constants.
"""

import math
import torch
from typing import Final

# ============================================================================
# The Topological Lock-Phase Residual Constant
# ============================================================================
# The fundamental geometric decay factor that maintains the structural
# integrity of the cylindrical helix space-time model.
#
# In traditional physics, the fine-structure constant alpha ≈ 1/137
# governs the strength of electromagnetic interactions.
# Here, it emerges from pure geometry:
#   alpha_geom = 1 / (4*pi^3 + pi^2 + pi)
#
# This is NOT a coincidence - it reflects the topological constraint
# that prevents the cylindrical helix manifold from collapsing.

PI: Final[float] = math.pi
FOUR_PI_CUBED: Final[float] = 4.0 * PI ** 3      # ~124.0251
PI_SQUARED: Final[float] = PI ** 2                  # ~9.8696
TOPO_SUM: Final[float] = FOUR_PI_CUBED + PI_SQUARED + PI  # ~139.7247

# The topological decay constant (analogous to fine-structure constant)
ALPHA_GEOM: Final[float] = 1.0 / TOPO_SUM          # ~0.00716

# Squared version for stronger (gravitational-like) decay
ALPHA_GEOM_SQUARED: Final[float] = ALPHA_GEOM ** 2  # ~5.12e-5

# Inverse - the "topological quantum" (analogous to 137)
TOPO_QUANTUM: Final[float] = TOPO_SUM                # ~139.7247

# ============================================================================
# Cylindrical Helix Parameters
# ============================================================================
# The helix is parameterized as:
#   x(t) = r * cos(omega * t)
#   y(t) = r * sin(omega * t)
#   z(t) = c * t            (light-speed divergence along Z-axis)
#
# where r is the radial amplitude, omega is the angular frequency,
# and c represents the "speed of information propagation" along the axis.

# Base angular frequency for the helix (rad/s in information space)
HELIX_OMEGA_BASE: Final[float] = 2.0 * PI  # One full rotation per unit step

# Light-speed information divergence rate along Z-axis
# In our model, this controls how fast positional information
# propagates along the sequence dimension.
C_INFO: Final[float] = 1.0  # Normalized information speed of light

# ============================================================================
# Phase Transition Thresholds
# ============================================================================
# The stress threshold at which the "jelly effect" (phase transition)
# occurs in information space. When accumulated interference stress
# exceeds this value, the system undergoes a topological collapse,
# producing sparse creative activations.
#
# Derived from: alpha_geom / (2 * pi) -- the normalized topological
# energy threshold per rotation cycle.

PHASE_TRANSITION_THRESHOLD: Final[float] = ALPHA_GEOM / (2.0 * PI)  # ~0.00114

# The "avalanche multiplier" - when phase transition occurs,
# the output is amplified by this factor, simulating the
# electromagnetic shockwave from topological collapse.
AVALANCHE_MULTIPLIER: Final[float] = TOPO_QUANTUM / (2.0 * PI)  # ~22.24

# Soft transition width (controls sharpness of phase transition)
# Larger = smoother transition, Smaller = more abrupt "creative jump"
PHASE_TRANSITION_WIDTH: Final[float] = 0.01

# ============================================================================
# Utility Functions
# ============================================================================

def get_alpha_geom(device: torch.device = None) -> torch.Tensor:
    """Return the topological decay constant as a tensor."""
    return torch.tensor(ALPHA_GEOM, dtype=torch.float32, device=device)


def get_topo_quantum(device: torch.device = None) -> torch.Tensor:
    """Return the topological quantum (~139.72) as a tensor."""
    return torch.tensor(TOPO_QUANTUM, dtype=torch.float32, device=device)


def get_phase_threshold(device: torch.device = None) -> torch.Tensor:
    """Return the phase transition threshold as a tensor."""
    return torch.tensor(PHASE_TRANSITION_THRESHOLD, dtype=torch.float32, device=device)

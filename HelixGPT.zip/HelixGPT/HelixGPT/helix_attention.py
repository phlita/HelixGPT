"""
Helix Interference Attention Layer

The heart of HelixGPT — replaces the standard dot-product attention:

    Standard:    Attention = Softmax(Q @ K^T / sqrt(d)) @ V
    HelixGPT:    Attention = HelixNorm(Interference(Q, K) * TopoDecay) @ V

Core Innovation — Phase Interference instead of Dot Product:
    Instead of computing cosine similarity (dot product), we compute
    the INTERFERENCE PATTERN between two space-time vortices:

        Interference(q, k) = |q| * |k| * cos(theta_q - theta_k) * f_residual(theta_q, theta_k)

    Where:
        |q|, |k|         = radial amplitudes (electromagnetic component)
        theta_q, theta_k  = angular phases (gravitational component)
        f_residual        = topological residual function based on phase relationship

    In the (amplitude, phase) split representation:
        - Amplitudes modulate the score magnitude (like attention "energy")
        - Phase differences create interference patterns (constructive/destructive)
        - The residual function f adds nonlinear coupling

    This is analogous to how actual gravitational and electromagnetic fields
    interact in Zhang Xiangqian's unified field theory: through INTERFERENCE,
    not through simple dot products in Euclidean space.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from helixgpt.config import HelixConfig
from helixgpt.helix_rope import apply_helix_rope, apply_helix_rope_interleave
from helixgpt.phase_transition import TopologicalDecay, HelixSoftmax
from helixgpt.constants import ALPHA_GEOM, TOPO_QUANTUM, PI


class HelixInterferenceAttention(nn.Module):
    """Cylindrical Helix Space-Time Interference Attention.

    Replaces CausalSelfAttention with a physics-motivated interference pattern.
    Each token is a "micro particle" with amplitude (charge) and phase (mass).
    Attention scores are computed via phase interference, not dot products.
    """

    def __init__(self, config: HelixConfig, block_idx: int):
        super().__init__()
        self.config = config
        self.block_idx = block_idx

        head_size = config.head_size
        half_dim = head_size // 2
        n_head = config.n_head
        n_query_groups = config.n_query_groups

        # Q, K, V projections (same structure as standard attention)
        # but operating on (amplitude, phase) pairs
        self.qkv = nn.Linear(
            config.n_embd,
            (n_head + 2 * n_query_groups) * head_size,
            bias=config.attn_bias,
        )
        self.proj = nn.Linear(head_size * n_head, config.n_embd, bias=config.bias)

        # Topological decay module
        self.topo_decay = TopologicalDecay(
            max_seq_length=config.block_size,
            decay_mode=config.topological_decay_mode,
            max_decay_distance=config.max_decay_distance,
            decay_floor=config.decay_floor,
        )

        # Helix-aware normalization (replaces Softmax)
        self.helix_norm = HelixSoftmax(self.topo_decay)

        self.kv_cache: KVCache | None = None

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        z_shift: torch.Tensor | None = None,
        mask: torch.Tensor | None = None,
        input_pos: torch.Tensor | None = None,
        input_pos_maxp1: int | None = None,
    ) -> torch.Tensor:
        """Forward pass of Helix Interference Attention.

        Args:
            x: Input tensor (B, T, n_embd) in (amplitude, phase) form.
            cos: Cosine cache from Helix-RoPE.
            sin: Sine cache from Helix-RoPE.
            z_shift: Axial Z-shift cache from Helix-RoPE (the 3D component).
            mask: Optional causal mask.
            input_pos: Optional position indices for KV cache.
            input_pos_maxp1: Optional max position + 1 for KV cache slicing.

        Returns:
            Output tensor (B, T, n_embd).
        """
        B, T, C = x.size()
        head_size = self.config.head_size
        n_head = self.config.n_head
        n_query_groups = self.config.n_query_groups
        rope_n_elem = int(head_size * self.config.rotary_percentage)
        half_head = head_size // 2

        # ============================================================
        # Step 1: Project to Q, K, V
        # ============================================================
        qkv = self.qkv(x)  # (B, T, (n_head + 2*n_query_groups) * head_size)

        query_size = n_head * head_size
        key_size = value_size = n_query_groups * head_size
        q, k, v = qkv.split((query_size, key_size, value_size), dim=-1)

        q = q.view(B, T, n_head, head_size).transpose(1, 2)       # (B, nh_q, T, hs)
        k = k.view(B, T, n_query_groups, head_size).transpose(1, 2)  # (B, nh_k, T, hs)
        v = v.view(B, T, n_query_groups, head_size).transpose(1, 2)  # (B, nh_v, T, hs)

        # ============================================================
        # Step 2: Apply Helix-RoPE (3D cylindrical helix rotation)
        # ============================================================
        if z_shift is not None and self.config.use_helix_rope:
            # Full 3D helix rotation
            if self.config.rope_interleave:
                q_roped = apply_helix_rope_interleave(q[..., :rope_n_elem], cos, sin, z_shift)
                k_roped = apply_helix_rope_interleave(k[..., :rope_n_elem], cos, sin, z_shift)
            else:
                q_roped = apply_helix_rope(q[..., :rope_n_elem], cos, sin, z_shift)
                k_roped = apply_helix_rope(k[..., :rope_n_elem], cos, sin, z_shift)
        else:
            # Fallback: standard 2D RoPE (still better than nothing)
            q_roped = q[..., :rope_n_elem] * cos + self._rotate_half(q[..., :rope_n_elem]) * sin
            k_roped = k[..., :rope_n_elem] * cos + self._rotate_half(k[..., :rope_n_elem]) * sin

        q = torch.cat((q_roped, q[..., rope_n_elem:]), dim=-1)
        k = torch.cat((k_roped, k[..., rope_n_elem:]), dim=-1)

        # ============================================================
        # Step 3: KV Cache (inference)
        # ============================================================
        if input_pos is not None:
            if not isinstance(self.kv_cache, KVCache):
                raise TypeError("You need to call `model.set_kv_cache()`")
            k, v = self.kv_cache(input_pos, k, v)
            if input_pos_maxp1 is not None:
                k = k[..., :input_pos_maxp1, :]
                v = v[..., :input_pos_maxp1, :]

        # Grouped query expansion
        if n_query_groups != n_head and (input_pos is None or n_query_groups != 1):
            q_per_kv = n_head // n_query_groups
            k = k.repeat_interleave(q_per_kv, dim=1)
            v = v.repeat_interleave(q_per_kv, dim=1)

        # ============================================================
        # Step 4: HELIX INTERFERENCE ATTENTION (Core Innovation!)
        # ============================================================
        # Instead of q @ k^T (dot product), we compute phase interference.
        y = self._interference_attention(q, k, v, mask)

        # ============================================================
        # Step 5: Output projection
        # ============================================================
        y = y.reshape(B, T, head_size * n_head)
        return self.proj(y)

    def _interference_attention(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Compute attention via helix phase interference.

        For each (q, k) pair:
        1. Split into amplitude (A) and phase (theta) components
        2. Compute interference: |A_q| * |A_k| * cos(theta_q - theta_k)
        3. Add topological residual coupling: f(theta_q, theta_k)
        4. Apply topological decay
        5. Normalize with HelixSoftmax (open-system normalization)

        Args:
            q: Query tensor (B, nh, T_q, hs)
            k: Key tensor (B, nh, T_k, hs)
            v: Value tensor (B, nh, T_k, hs)
            mask: Optional causal mask

        Returns:
            Attention output (B, nh, T_q, hs)
        """
        half = q.shape[-1] // 2

        # Split Q and K into (amplitude, phase) pairs
        q_amp = q[..., :half]   # (B, nh, T_q, half) - electromagnetic component
        q_pha = q[..., half:]   # (B, nh, T_q, half) - gravitational component
        k_amp = k[..., :half]   # (B, nh, T_k, half)
        k_pha = k[..., half:]   # (B, nh, T_k, half)

        # ========================================
        # Interference Score Computation
        # ========================================
        # Phase difference: delta_theta = theta_q - theta_k
        # Shape: (B, nh, T_q, T_k, half)
        delta_theta = q_pha.unsqueeze(3) - k_pha.unsqueeze(2)

        # Magnitude product: |q| * |k|
        # Shape: (B, nh, T_q, T_k, half)
        mag_product = (q_amp.abs().unsqueeze(3) * k_amp.abs().unsqueeze(2))

        # Cosine of phase difference (constructive/destructive interference)
        cos_delta = torch.cos(delta_theta)

        # Sine of phase difference (for residual coupling)
        sin_delta = torch.sin(delta_theta)

        # ========================================
        # Topological Residual Coupling Function
        # ========================================
        # f_residual(theta_q, theta_k) = 1 + alpha * sin(delta_theta)
        # This adds a nonlinear coupling that breaks the symmetry
        # between constructive and destructive interference.
        # When sin(delta_theta) > 0: enhanced interference (synergy)
        # When sin(delta_theta) < 0: suppressed interference (cancellation)
        alpha_t = get_alpha_for_device(q.device, q.dtype)
        f_residual = 1.0 + alpha_t * sin_delta  # (..., half)

        # ========================================
        # Combined Interference Score
        # ========================================
        # Interference(q, k) = |q| * |k| * cos(delta_theta) * f_residual(delta_theta)
        # Shape: (B, nh, T_q, T_k, half)
        interference = mag_product * cos_delta * f_residual

        # Sum over the half-dimension to get per-head scores
        # Shape: (B, nh, T_q, T_k)
        scores = interference.sum(dim=-1) / math.sqrt(half)

        # ========================================
        # Apply Topological Decay
        # ========================================
        if self.config.use_topological_decay:
            scores = self.topo_decay(scores)

        # ========================================
        # Causal Mask
        # ========================================
        if mask is not None:
            scores = scores.masked_fill(~mask, float("-inf"))

        # ========================================
        # Normalization (Helix-Aware, NOT standard Softmax)
        # ========================================
        weights = self.helix_norm(scores)  # (B, nh, T_q, T_k)

        # ========================================
        # Weighted Sum (same as standard attention)
        # ========================================
        # (B, nh, T_q, T_k) @ (B, nh, T_k, hs) -> (B, nh, T_q, hs)
        output = weights @ v

        return output.transpose(1, 2)  # (B, T_q, nh, hs)

    @staticmethod
    def _rotate_half(x: torch.Tensor) -> torch.Tensor:
        """Rotate half the hidden dims of the input (for fallback 2D RoPE)."""
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def build_kv_cache(
        self,
        batch_size: int,
        max_seq_length: int,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
    ) -> "KVCache":
        v_shape = (batch_size, self.config.n_query_groups, max_seq_length, self.config.head_size)
        k_shape = v_shape
        return KVCache(k_shape, v_shape, device=device, dtype=dtype)


# ============================================================================
# Helpers (avoid circular imports)
# ============================================================================

def get_alpha_for_device(device, dtype):
    return torch.tensor(ALPHA_GEOM, dtype=dtype, device=device)


class KVCache(nn.Module):
    """Simplified KV Cache for HelixGPT (adapted from LitGPT)."""

    def __init__(
        self,
        k_shape: tuple[int, int, int, int],
        v_shape: tuple[int, int, int, int],
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
    ):
        super().__init__()
        self.register_buffer("k", torch.zeros(k_shape, device=device, dtype=dtype), persistent=False)
        self.register_buffer("v", torch.zeros(v_shape, device=device, dtype=dtype), persistent=False)
        self.max_cache_len = k_shape[2]

    def forward(
        self, input_pos: torch.Tensor, k: torch.Tensor, v: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if self.k.dtype != k.dtype:
            self.k = self.k.to(k.dtype)
        if self.v.dtype != v.dtype:
            self.v = self.v.to(v.dtype)

        bs = k.size(0)
        if input_pos.dim() == 1:
            self.k = self.k.index_copy_(-2, input_pos, k[:bs])
            self.v = self.v.index_copy_(-2, input_pos, v[:bs])
        else:
            for i in range(bs):
                self.k[i].index_copy_(-2, input_pos[i], k[i])
                self.v[i].index_copy_(-2, input_pos[i], v[i])

        return self.k[:bs], self.v[:bs]
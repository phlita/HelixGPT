"""
HelixGPT Configuration

Extends the concept of LitGPT's Config dataclass with HelixGPT-specific
parameters rooted in Zhang Xiangqian's unified field theory.
"""

from dataclasses import dataclass, field
from typing import Literal
from litgpt.config import Config, find_multiple


@dataclass
class HelixConfig(Config):
    """Configuration for HelixGPT model.

    Inherits all standard LitGPT Config fields and adds HelixGPT-specific
    parameters that replace traditional transformer components with
    spiral space-time equivalents.
    """

    # ========================================================================
    # HelixGPT-specific identifier
    # ========================================================================
    name: str = "helixgpt-100M"

    # ========================================================================
    # Core Model Architecture (small model for initial experiments)
    # ========================================================================
    block_size: int = 2048
    n_layer: int = 12
    n_embd: int = 768        # Total embedding dim (will be split into amplitude + phase)
    vocab_size: int = 50257  # GPT-2 tokenizer vocabulary
    padding_multiple: int = 128
    padded_vocab_size: int | None = None

    # ========================================================================
    # Attention Configuration
    # ========================================================================
    n_head: int = 12
    head_size: int | None = None  # Auto-computed: n_embd // n_head
    n_query_groups: int = 12      # MHA by default

    # ========================================================================
    # Helix-Specific Parameters
    # ========================================================================

    # --- Spacetime Spinor Embedding ---
    # The embedding dimension is split into two halves:
    #   x_radial (amplitude, real part): electromagnetic / explicit info
    #   x_angular (phase, imaginary part): gravitational / implicit context
    # This must be True for HelixGPT (the whole point is complex representations)
    use_spacetime_spinor: bool = True

    # Helix radius initialization scale (controls initial spiral amplitude)
    helix_radius_init: float = 0.02

    # Angular frequency multiplier (how many rotations per token position)
    # Default: 2*pi means one full rotation per position step
    helix_omega_multiplier: float = 1.0

    # --- Topological Decay ---
    # Whether to apply the 1/(4*pi^3 + pi^2 + pi) geometric decay
    # to attention scores based on token distance
    use_topological_decay: bool = True

    # Decay mode:
    #   "linear": multiply by alpha_geom^(distance)
    #   "quadratic": multiply by alpha_geom^(2*distance) [gravitational-like]
    #   "inverse_square": multiply by 1/(1 + alpha_geom * distance^2)
    topological_decay_mode: Literal["linear", "quadratic", "inverse_square"] = "linear"

    # Maximum decay distance (beyond this, decay saturates at floor value)
    max_decay_distance: int = 512

    # Decay floor value (minimum attention weight, prevents total decay)
    decay_floor: float = 1e-6

    # --- Helix-RoPE (3D Cylindrical Helix Positional Encoding) ---
    # Whether to use Helix-RoPE instead of standard 2D RoPE
    use_helix_rope: bool = True

    # Light-speed divergence rate along Z-axis
    # Controls how fast positional information "radiates" along the sequence
    c_divergence: float = 1.0

    # Helix pitch (vertical advance per rotation)
    # Larger pitch = more "stretched" helix = longer-range context
    helix_pitch: float = 1.0

    # --- Phase Transition Avalanche ---
    # Whether to use phase transition activation instead of standard activation
    use_phase_transition: bool = True

    # Stress threshold multiplier (scales the base threshold)
    # Base threshold = alpha_geom / (2*pi) ≈ 0.00114
    phase_threshold_multiplier: float = 1.0

    # Avalanche sharpness (sigmoid width for the transition)
    phase_transition_width: float = 0.01

    # Avalanche output multiplier (amplitude of the "electromagnetic shockwave")
    avalanche_multiplier: float = 22.24  # ~TOPO_QUANTUM / (2*pi)

    # --- Normalization ---
    norm_class_name: Literal["LayerNorm", "RMSNorm"] = "RMSNorm"
    norm_eps: float = 1e-6
    norm_qk: bool = False
    post_attention_norm: bool = False
    post_mlp_norm: bool = False
    parallel_residual: bool = True
    shared_attention_norm: bool = False

    # --- MLP ---
    # Expansion ratio for the intermediate (hidden) dimension in FFN
    expansion_ratio: int = 4

    # --- Other Standard Parameters ---
    bias: bool = False
    attn_bias: bool = False
    lm_head_bias: bool = False
    rotary_percentage: float = 1.0
    rope_interleave: bool = False
    rope_base: int = 10000
    rope_condense_ratio: int = 1
    gelu_approximate: str = "none"
    attention_scores_scalar: int | None = None
    scale_embeddings: bool = False
    mlp_class_name: str = "HelixMLP"

    # Disable features not relevant to HelixGPT
    sliding_window_size: int | None = None
    sliding_window_indices: list[bool] | None = None
    rope_adjustments: dict | None = None
    rope_indices: list[range] | None = None
    rope_local_base_freq: float | None = None
    attention_logit_softcapping: float | None = None
    final_logit_softcapping: float | None = None
    latent_attention: bool = False

    def __post_init__(self) -> None:
        super().__post_init__()  # type: ignore
        # Compute head_size if not explicitly set
        if self.head_size is None:
            self.head_size = self.n_embd // self.n_head
        # Compute padded vocab size
        if self.padded_vocab_size is None:
            self.padded_vocab_size = find_multiple(self.vocab_size, self.padding_multiple)


# ============================================================================
# Predefined Configurations
# ============================================================================

def helixgpt_60m() -> HelixConfig:
    """Tiny HelixGPT (~60M parameters) for rapid experimentation."""
    return HelixConfig(
        name="helixgpt-60M",
        n_layer=6,
        n_embd=512,
        n_head=8,
        n_query_groups=8,
        block_size=1024,
        vocab_size=50257,
        padding_multiple=128,
    )


def helixgpt_100m() -> HelixConfig:
    """Small HelixGPT (~100M parameters) - recommended starting point."""
    return HelixConfig(
        name="helixgpt-100M",
        n_layer=12,
        n_embd=768,
        n_head=12,
        n_query_groups=12,
        block_size=2048,
        vocab_size=50257,
        padding_multiple=128,
    )


def helixgpt_350m() -> HelixConfig:
    """Medium HelixGPT (~350M parameters) for serious training."""
    return HelixConfig(
        name="helixgpt-350M",
        n_layer=24,
        n_embd=1024,
        n_head=16,
        n_query_groups=16,
        block_size=4096,
        vocab_size=50257,
        padding_multiple=128,
    )


def helixgpt_1b() -> HelixConfig:
    """Large HelixGPT (~1B parameters)."""
    return HelixConfig(
        name="helixgpt-1B",
        n_layer=24,
        n_embd=2048,
        n_head=32,
        n_query_groups=32,
        block_size=4096,
        vocab_size=50257,
        padding_multiple=256,
    )
#!/usr/bin/env python
"""
HelixGPT Training Script

A minimal, self-contained training script for HelixGPT.
Based on LitGPT's training philosophy: clean, modular, no magic.

Usage:
    # Train the 60M model on a text file:
    python train.py --model helixgpt-60M --data path/to/train.txt --epochs 10

    # Train the 100M model with custom config:
    python train.py --model helixgpt-100M --data path/to/data.txt \
        --batch-size 32 --learning-rate 3e-4 --epochs 20

    # Resume from checkpoint:
    python train.py --model helixgpt-100M --data path/to/data.txt \
        --resume checkpoints/helixgpt-100M/step-5000.pt
"""

import argparse
import math
import sys
import time
from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

# Ensure HelixGPT and LitGPT are importable
PROJECT_ROOT = Path(__file__).resolve().parent.parent
HELIX_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(HELIX_ROOT / ".." / "litgpt"))

from helixgpt import (
    HelixGPT,
    HelixConfig,
    helixgpt_60m,
    helixgpt_100m,
    helixgpt_350m,
    helixgpt_1b,
    ALPHA_GEOM,
    TOPO_QUANTUM,
)
from helixgpt.tokenizer import get_tokenizer


# ============================================================================
# Text Dataset (simple: loads a .txt file, tokenizes on the fly)
# ============================================================================

class TextDataset(Dataset):
    """A simple dataset that tokenizes a text file and returns fixed-length chunks."""

    def __init__(
        self,
        file_path: str | Path,
        tokenizer,
        block_size: int = 2048,
        stride: int | None = None,
    ):
        self.tokenizer = tokenizer
        self.block_size = block_size

        # Read and tokenize
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()

        token_ids = tokenizer.encode(text)
        self.token_ids = torch.tensor(token_ids, dtype=torch.long)

        if stride is None:
            stride = block_size
        self.stride = stride

        # Create chunks
        self.chunks: list[tuple[int, int]] = []
        for i in range(0, len(self.token_ids) - block_size, stride):
            self.chunks.append((i, i + block_size + 1))  # +1 for targets

        if len(self.chunks) == 0:
            raise ValueError(
                f"File {file_path} has too few tokens ({len(self.token_ids)}) "
                f"for block_size={block_size}"
            )

    def __len__(self):
        return len(self.chunks)

    def __getitem__(self, idx):
        start, end = self.chunks[idx]
        chunk = self.token_ids[start:end]
        x = chunk[:-1]
        y = chunk[1:]
        return x, y


# ============================================================================
# Training Loop
# ============================================================================

def train(args):
    """Main training function."""

    # --- Setup device ---
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print(f"Using CUDA: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        print("Using CPU (training will be slow)")

    # --- Build config ---
    config_builders = {
        "helixgpt-60M": helixgpt_60m,
        "helixgpt-100M": helixgpt_100m,
        "helixgpt-350M": helixgpt_350m,
        "helixgpt-1B": helixgpt_1b,
    }
    if args.model not in config_builders:
        raise ValueError(f"Unknown model: {args.model}. Choose from: {list(config_builders.keys())}")

    config = config_builders[args.model]()
    print(f"\n{'='*60}")
    print(f"  HelixGPT — Spiral Space-Time Transformer")
    print(f"{'='*60}")
    print(f"  Model:          {config.name}")
    print(f"  Parameters:     ~{config.n_layer * (12 * config.n_embd**2):,} (estimated)")
    print(f"  Layers:         {config.n_layer}")
    print(f"  Embedding dim:  {config.n_embd}")
    print(f"  Heads:          {config.n_head} x {config.head_size}")
    print(f"  Block size:     {config.block_size}")
    print(f"  Vocab size:     {config.padded_vocab_size}")
    print(f"  alpha_geom:     {ALPHA_GEOM:.8f} ≈ 1/{1/ALPHA_GEOM:.1f}")
    print(f"  topo_quantum:   {TOPO_QUANTUM:.4f}")
    print(f"  Helix-RoPE:     {config.use_helix_rope}")
    print(f"  Phase Transit:  {config.use_phase_transition}")
    print(f"  Topo Decay:     {config.use_topological_decay} ({config.topological_decay_mode})")
    print(f"{'='*60}\n")

    # --- Build model ---
    model = HelixGPT(config).to(device)
    n_params = model.num_parameters()
    print(f"  Actual parameters: {n_params:,}")
    print(f"  Memory (params):   {n_params * 4 / 1024**2:.1f} MB (float32)\n")

    # --- Load tokenizer ---
    print(f"Loading tokenizer: {args.tokenizer}")
    tokenizer = get_tokenizer(args.tokenizer)

    # --- Load dataset ---
    print(f"Loading dataset from: {args.data}")
    dataset = TextDataset(
        file_path=args.data,
        tokenizer=tokenizer,
        block_size=config.block_size,
        stride=config.block_size // 2,  # 50% overlap for better training signal
    )
    print(f"Dataset: {len(dataset)} chunks of length {config.block_size}")

    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=(device.type == "cuda"),
        drop_last=True,
    )

    # --- Optimizer ---
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
        betas=(0.9, 0.95),
    )

    # --- Learning rate scheduler (cosine with warmup) ---
    total_steps = len(dataloader) * args.epochs
    warmup_steps = int(total_steps * args.warmup_ratio)

    def lr_lambda(step):
        if step < warmup_steps:
            return step / max(1, warmup_steps)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * progress))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    # --- Resume from checkpoint ---
    start_step = 0
    if args.resume:
        print(f"Resuming from checkpoint: {args.resume}")
        ckpt = torch.load(args.resume, map_location=device)
        model.load_state_dict(ckpt["model_state_dict"])
        optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        scheduler.load_state_dict(ckpt["scheduler_state_dict"])
        start_step = ckpt["step"]

    # --- Training Loop ---
    print(f"\nStarting training for {args.epochs} epochs...")
    print(f"  Total steps:  {total_steps}")
    print(f"  Warmup steps: {warmup_steps}")
    print(f"  Batch size:   {args.batch_size}")
    print(f"  LR:           {args.learning_rate}")
    print()

    model.train()
    log_interval = max(1, len(dataloader) // 20)  # ~20 log points per epoch
    best_loss = float("inf")

    for epoch in range(args.epochs):
        epoch_loss = 0.0
        epoch_tokens = 0
        t0 = time.time()

        for step, (x, y) in enumerate(dataloader):
            x = x.to(device)
            y = y.to(device)

            # Forward
            logits = model(x)  # (B, T, V)
            loss = nn.functional.cross_entropy(
                logits.reshape(-1, config.padded_vocab_size),
                y.reshape(-1),
                ignore_index=-1,
            )

            # Backward
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            optimizer.step()
            scheduler.step()

            # Logging
            global_step = start_step + epoch * len(dataloader) + step
            epoch_loss += loss.item() * x.numel()
            epoch_tokens += x.numel()

            if step % log_interval == 0:
                lr = scheduler.get_last_lr()[0]
                ms_per_token = (time.time() - t0) * 1000 / max(1, x.numel() * log_interval)
                print(
                    f"  [E{epoch+1} S{step:5d}] "
                    f"loss={loss.item():.4f}  "
                    f"lr={lr:.2e}  "
                    f"tok/ms={1/ms_per_token * 1000:.0f}  "
                    f"alpha={ALPHA_GEOM:.6f}"
                )
                t0 = time.time()

        avg_loss = epoch_loss / epoch_tokens
        print(f"\n  >>> Epoch {epoch+1} complete. Avg loss: {avg_loss:.4f}\n")

        # Save checkpoint
        if (epoch + 1) % args.save_every == 0 or avg_loss < best_loss:
            best_loss = avg_loss
            save_dir = Path(args.output_dir) / config.name
            save_dir.mkdir(parents=True, exist_ok=True)
            ckpt_path = save_dir / f"step-{global_step}.pt"
            torch.save({
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "scheduler_state_dict": scheduler.state_dict(),
                "step": global_step,
                "epoch": epoch + 1,
                "loss": avg_loss,
                "config_name": config.name,
            }, ckpt_path)
            print(f"  >>> Checkpoint saved: {ckpt_path}\n")

    # Save final model
    save_dir = Path(args.output_dir) / config.name
    save_dir.mkdir(parents=True, exist_ok=True)
    final_path = save_dir / "final.pt"
    torch.save({
        "model_state_dict": model.state_dict(),
        "step": total_steps,
        "config_name": config.name,
        "loss": avg_loss,
    }, final_path)
    print(f"\n  >>> Final model saved: {final_path}")
    print(f"  >>> Training complete! Total steps: {total_steps}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train HelixGPT")
    parser.add_argument("--model", type=str, default="helixgpt-100M",
                        choices=["helixgpt-60M", "helixgpt-100M", "helixgpt-350M", "helixgpt-1B"])
    parser.add_argument("--data", type=str, required=True,
                        help="Path to training text file")
    parser.add_argument("--output-dir", type=str, default="checkpoints")
    parser.add_argument("--tokenizer", type=str, default="gpt2",
                        help="HuggingFace tokenizer name or local path")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=0.1)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--warmup-ratio", type=float, default=0.05)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--save-every", type=int, default=1)
    parser.add_argument("--resume", type=str, default=None)

    args = parser.parse_args()
    train(args)
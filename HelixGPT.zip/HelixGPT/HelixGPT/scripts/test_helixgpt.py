#!/usr/bin/env python
"""
HelixGPT Quick Test Script

Verifies that all components work correctly:
1. Config creation
2. Model instantiation & parameter counting
3. Forward pass (training mode)
4. Forward pass (inference mode with KV cache)
5. Generation of sample tokens

Usage:
    python test_helixgpt.py
    python test_helixgpt.py --model helixgpt-60M    # Faster test with smaller model
    python test_helixgpt.py --cuda                    # Test on GPU
"""

import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / ".." / "litgpt"))

import torch

from helixgpt import (
    HelixGPT, HelixConfig,
    helixgpt_60m, helixgpt_100m,
    ALPHA_GEOM, TOPO_QUANTUM, TOPO_SUM, PI,
)
from helixgpt.constants import PHASE_TRANSITION_THRESHOLD
from helixgpt.spacetime_embedding import SpacetimeSpinorEmbedding
from helixgpt.helix_rope import build_helix_rope_cache, apply_helix_rope
from helixgpt.phase_transition import TopologicalDecay, PhaseTransitionAvalanche
from helixgpt.helix_attention import HelixInterferenceAttention


def separator(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


def test_constants():
    separator("TEST 1: Physical Constants")
    print(f"  pi              = {PI:.10f}")
    print(f"  4*pi^3          = {4*PI**3:.10f}")
    print(f"  pi^2            = {PI**2:.10f}")
    print(f"  4*pi^3+pi^2+pi  = {TOPO_SUM:.10f}")
    print(f"  alpha_geom      = {ALPHA_GEOM:.10f}")
    print(f"  1/alpha_geom    = {1/ALPHA_GEOM:.6f}")
    print(f"  topo_quantum    = {TOPO_QUANTUM:.6f}")
    print(f"  phase_threshold = {PHASE_TRANSITION_THRESHOLD:.10f}")
    print(f"\n  ✓ All constants computed successfully")


def test_config():
    separator("TEST 2: Configuration")
    for builder in [helixgpt_60m, helixgpt_100m]:
        config = builder()
        print(f"  {config.name}:")
        print(f"    n_layer={config.n_layer}, n_embd={config.n_embd}, "
              f"n_head={config.n_head}, block_size={config.block_size}")
        print(f"    use_spacetime_spinor={config.use_spacetime_spinor}")
        print(f"    use_helix_rope={config.use_helix_rope}")
        print(f"    use_topological_decay={config.use_topological_decay}")
        print(f"    use_phase_transition={config.use_phase_transition}")
        print(f"    topological_decay_mode={config.topological_decay_mode}")
    print(f"\n  ✓ Config creation successful")


def test_embedding():
    separator("TEST 3: Spacetime Spinor Embedding")
    emb = SpacetimeSpinorEmbedding(
        vocab_size=1000, n_embd=256,
        helix_radius_init=0.02,
    )
    idx = torch.randint(0, 1000, (2, 32))
    pos = torch.arange(32).unsqueeze(0)

    # Without position
    x = emb(idx)
    print(f"  Output shape (no pos): {x.shape}")
    assert x.shape == (2, 32, 256), f"Expected (2,32,256), got {x.shape}"

    # With position
    x2 = emb(idx, input_pos=pos)
    print(f"  Output shape (w/ pos): {x2.shape}")
    assert x2.shape == (2, 32, 256)

    # Verify amplitude-phase split
    amp = x2[..., :128]
    pha = x2[..., 128:]
    print(f"  Amplitude range: [{amp.min():.4f}, {amp.max():.4f}]")
    print(f"  Phase range:     [{pha.min():.4f}, {pha.max():.4f}]")
    print(f"\n  ✓ Embedding test passed")


def test_helix_rope():
    separator("TEST 4: Helix-RoPE (3D Cylindrical)")
    seq_len = 256
    n_elem = 64

    cos, sin, z_shift = build_helix_rope_cache(
        seq_len=seq_len, n_elem=n_elem,
        c_divergence=1.0, helix_pitch=1.0,
    )
    print(f"  cos shape:     {cos.shape}")
    print(f"  sin shape:     {sin.shape}")
    print(f"  z_shift shape: {z_shift.shape}")
    assert cos.shape == (seq_len, n_elem)
    assert sin.shape == (seq_len, n_elem)
    assert z_shift.shape == (seq_len, n_elem)

    # Apply to a dummy tensor
    x = torch.randn(2, 8, 32, n_elem)  # (B, nh, T, hs)
    cos_b = cos[:32].unsqueeze(0).unsqueeze(0)  # (1, 1, T, hs)
    sin_b = sin[:32].unsqueeze(0).unsqueeze(0)
    z_b = z_shift[:32].unsqueeze(0).unsqueeze(0)

    y = apply_helix_rope(x, cos_b, sin_b, z_b)
    print(f"  Input shape:  {x.shape}")
    print(f"  Output shape: {y.shape}")
    assert y.shape == x.shape

    # Verify Z-shift actually changes values
    y_no_z = apply_helix_rope(x, cos_b, sin_b, torch.zeros_like(z_b))
    diff = (y - y_no_z).abs().mean().item()
    print(f"  Z-shift effect (mean |diff|): {diff:.6f}")
    assert diff > 0, "Z-shift should modify the output!"
    print(f"\n  ✓ Helix-RoPE test passed")


def test_topological_decay():
    separator("TEST 5: Topological Decay")
    decay = TopologicalDecay(
        max_seq_length=128, decay_mode="linear",
    )
    scores = torch.randn(2, 4, 16, 16)  # (B, nh, T_q, T_k)
    decayed = decay(scores)

    print(f"  Input score range:  [{scores.min():.4f}, {scores.max():.4f}]")
    print(f"  Output score range: [{decayed.min():.4f}, {decayed.max():.4f}]")
    print(f"  Decay matrix shape:  {decay._decay_cache.shape}")

    # Verify decay reduces magnitude for distant tokens
    # Diagonal (distance=0) should have no decay
    diag = decayed.diagonal(dim1=-2, dim2=-1).mean().item()
    off_diag = (decayed.sum(dim=-1) / 16).mean().item()
    print(f"  Mean diagonal score: {diag:.4f}")
    print(f"  Mean per-token score: {off_diag:.4f}")
    print(f"  alpha_geom = {ALPHA_GEOM:.8f}")
    print(f"\n  ✓ Topological decay test passed")


def test_phase_transition():
    separator("TEST 6: Phase Transition Avalanche")
    avalanche = PhaseTransitionAvalanche(
        threshold_multiplier=1.0,
        transition_width=0.01,
        avalanche_multiplier=22.24,
    )

    # Low stress input (should pass through smoothly)
    x_low = torch.randn(2, 16, 256) * 0.001  # Very small = low stress
    y_low = avalanche(x_low)
    diff_low = (y_low - x_low).abs().mean().item()
    print(f"  Low stress:  input std={x_low.std():.6f}, |output-input| mean={diff_low:.6f}")

    # High stress input (should trigger avalanche)
    x_high = torch.randn(2, 16, 256) * 10.0  # Very large = high stress
    y_high = avalanche(x_high)
    diff_high = (y_high - x_high).abs().mean().item()
    print(f"  High stress: input std={x_high.std():.4f}, |output-input| mean={diff_high:.4f}")

    assert diff_low < diff_high, "High stress should cause more distortion!"
    print(f"\n  ✓ Phase transition test passed")


def test_full_model(model_name: str = "helixgpt-60M", device: str = "cpu"):
    separator(f"TEST 7: Full HelixGPT Forward Pass ({model_name})")
    dev = torch.device(device)

    builders = {"helixgpt-60M": helixgpt_60m, "helixgpt-100M": helixgpt_100m}
    config = builders[model_name]()

    print(f"  Building {config.name}...")
    t0 = time.time()
    model = HelixGPT(config).to(dev)
    build_time = time.time() - t0
    print(f"  Build time: {build_time:.2f}s")

    n_params = model.num_parameters()
    print(f"  Parameters: {n_params:,}")
    print(f"  Memory:     {n_params * 4 / 1024**2:.1f} MB (float32)")

    # Training forward pass
    print(f"\n  Training forward pass...")
    model.train()
    x = torch.randint(0, config.padded_vocab_size, (2, 64), device=dev)

    t0 = time.time()
    logits = model(x)
    fwd_time = time.time() - t0
    print(f"  Input:  {x.shape}")
    print(f"  Output: {logits.shape}")
    print(f"  Time:   {fwd_time:.3f}s")

    assert logits.shape == (2, 64, config.padded_vocab_size)

    # Compute loss
    loss = torch.nn.functional.cross_entropy(
        logits.reshape(-1, config.padded_vocab_size),
        x.reshape(-1)
    )
    print(f"  Loss:   {loss.item():.4f}")

    # Backward pass
    t0 = time.time()
    loss.backward()
    bwd_time = time.time() - t0
    print(f"  Backward time: {bwd_time:.3f}s")

    # Inference forward pass (with KV cache)
    print(f"\n  Inference forward pass (KV cache)...")
    model.eval()
    model.set_kv_cache(1, config.block_size, device=dev, dtype=torch.float32)

    x_inf = torch.randint(0, config.padded_vocab_size, (1, 16), device=dev)
    input_pos = torch.arange(16, device=dev).unsqueeze(0)

    t0 = time.time()
    logits_inf = model(x_inf, input_pos=input_pos)
    inf_time = time.time() - t0
    print(f"  Input:  {x_inf.shape}")
    print(f"  Output: {logits_inf.shape}")
    print(f"  Time:   {inf_time:.4f}s")

    model.clear_kv_cache()
    print(f"\n  ✓ Full model test passed!")


def test_generation(model_name: str = "helixgpt-60M", device: str = "cpu"):
    separator(f"TEST 8: Autoregressive Generation ({model_name})")
    dev = torch.device(device)

    builders = {"helixgpt-60M": helixgpt_60m, "helixgpt-100M": helixgpt_100m}
    config = builders[model_name]()
    model = HelixGPT(config).to(dev)
    model.eval()

    # Simple token-by-token generation (no real tokenizer, just IDs)
    model.set_kv_cache(1, config.block_size, device=dev, dtype=torch.float32)

    tokens = torch.randint(0, config.padded_vocab_size, (1, 4), device=dev)
    input_pos = torch.arange(4, device=dev).unsqueeze(0)

    generated = 0
    max_gen = 20
    t0 = time.time()

    with torch.no_grad():
        for i in range(max_gen):
            if generated == 0:
                logits = model(tokens, input_pos=input_pos)
            else:
                logits = model(tokens[:, -1:], input_pos=input_pos[:, -1:])

            next_token = logits[:, -1, :].argmax(dim=-1, keepdim=True)
            tokens = torch.cat([tokens, next_token], dim=1)
            input_pos = torch.cat([input_pos, input_pos[:, -1:] + 1], dim=1)
            generated += 1

    elapsed = time.time() - t0
    print(f"  Generated {max_gen} tokens in {elapsed:.3f}s")
    print(f"  Output shape: {tokens.shape}")
    print(f"  Speed: {max_gen / elapsed:.1f} tok/s")

    model.clear_kv_cache()
    print(f"\n  ✓ Generation test passed!")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="helixgpt-60M")
    parser.add_argument("--cuda", action="store_true")
    args = parser.parse_args()

    device = "cuda" if args.cuda and torch.cuda.is_available() else "cpu"

    print("\n" + "=" * 60)
    print("  HelixGPT Test Suite")
    print("  Spiral Space-Time Generative Pre-trained Transformer")
    print("=" * 60)

    test_constants()
    test_config()
    test_embedding()
    test_helix_rope()
    test_topological_decay()
    test_phase_transition()
    test_full_model(args.model, device)
    test_generation(args.model, device)

    separator("ALL TESTS PASSED!")
    print("  HelixGPT is ready for training.\n")


if __name__ == "__main__":
    main()
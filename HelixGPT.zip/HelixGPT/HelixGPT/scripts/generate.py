#!/usr/bin/env python
"""
HelixGPT Text Generation Script

Autoregressive generation using the trained HelixGPT model.

Usage:
    # Generate from a trained checkpoint:
    python generate.py --checkpoint checkpoints/helixgpt-100M/final.pt \
        --prompt "The meaning of the universe is" --max-tokens 256

    # Interactive chat mode:
    python generate.py --checkpoint checkpoints/helixgpt-100M/final.pt \
        --interactive --max-tokens 512
"""

import argparse
import sys
import time
from pathlib import Path

import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / ".." / "litgpt"))

from helixgpt import HelixGPT, helixgpt_100m, helixgpt_60m, helixgpt_350m, helixgpt_1b, ALPHA_GEOM
from helixgpt.tokenizer import get_tokenizer


def generate(
    model: HelixGPT,
    input_ids: torch.Tensor,
    max_new_tokens: int = 256,
    temperature: float = 0.8,
    top_k: int = 200,
    top_p: float = 0.95,
    device: torch.device = torch.device("cpu"),
) -> torch.Tensor:
    """Autoregressive generation with KV cache.

    Args:
        model: HelixGPT model.
        input_ids: Token IDs, shape (1, T).
        max_new_tokens: Number of tokens to generate.
        temperature: Sampling temperature (>1 = more random, <1 = more focused).
        top_k: Top-k filtering.
        top_p: Nucleus (top-p) filtering.
        device: Torch device.

    Returns:
        Generated token IDs (including input), shape (1, T + max_new_tokens).
    """
    model.eval()
    input_pos = torch.arange(input_ids.shape[1], device=device).unsqueeze(0)
    model.set_kv_cache(1, model.max_seq_length, device=device, dtype=torch.float32)

    tokens = input_ids
    generated = 0

    with torch.no_grad():
        while generated < max_new_tokens:
            # Get logits for the last token
            if tokens.shape[1] > 1 and generated > 0:
                # After the first step, only feed the last token
                logits = model(tokens[:, -1:], input_pos=input_pos[:, -1:])
            else:
                logits = model(tokens, input_pos=input_pos)

            # Get logits for the next token
            next_logit = logits[:, -1, :]  # (1, vocab_size)

            # Temperature scaling
            next_logit = next_logit / temperature

            # Top-k filtering
            if top_k > 0:
                v, _ = torch.topk(next_logit, min(top_k, next_logit.size(-1)))
                next_logit[next_logit < v[:, [-1]]] = float("-inf")

            # Top-p (nucleus) filtering
            if top_p < 1.0:
                sorted_logits, sorted_indices = torch.sort(next_logit, descending=True)
                cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cumulative_probs > top_p
                sorted_indices_to_remove[:, 1:] = sorted_indices_to_remove[:, :-1].clone()
                sorted_indices_to_remove[:, 0] = False
                indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
                next_logit[indices_to_remove] = float("-inf")

            # Sample
            probs = torch.softmax(next_logit, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)  # (1, 1)

            tokens = torch.cat([tokens, next_token], dim=1)
            input_pos = torch.cat([
                input_pos,
                (input_pos[:, -1:] + 1)
            ], dim=1)
            generated += 1

    model.clear_kv_cache()
    return tokens


def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Load checkpoint
    print(f"Loading checkpoint: {args.checkpoint}")
    ckpt = torch.load(args.checkpoint, map_location=device)
    config_name = ckpt.get("config_name", "helixgpt-100M")

    # Build model
    builders = {
        "helixgpt-60M": helixgpt_60m,
        "helixgpt-100M": helixgpt_100m,
        "helixgpt-350M": helixgpt_350m,
        "helixgpt-1B": helixgpt_1b,
    }
    config = builders[config_name]()
    model = HelixGPT(config).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    print(f"Model loaded: {config_name} ({model.num_parameters():,} params)")
    print(f"  alpha_geom = {ALPHA_GEOM:.8f} (≈ 1/{1/ALPHA_GEOM:.1f})")

    # Load tokenizer
    tokenizer = get_tokenizer(args.tokenizer)

    if args.interactive:
        print("\n" + "=" * 60)
        print("  HelixGPT Interactive Chat (type 'quit' to exit)")
        print("=" * 60 + "\n")

        history_ids = []
        while True:
            prompt = input("You: ")
            if prompt.strip().lower() in ("quit", "exit", "q"):
                break

            prompt_ids = tokenizer.encode(prompt)
            input_ids = torch.tensor([prompt_ids], device=device)

            print("HelixGPT: ", end="", flush=True)
            t0 = time.time()

            output_ids = generate(
                model, input_ids,
                max_new_tokens=args.max_tokens,
                temperature=args.temperature,
                top_k=args.top_k,
                top_p=args.top_p,
                device=device,
            )

            generated_text = tokenizer.decode(output_ids[0].tolist()[len(prompt_ids):])
            elapsed = time.time() - t0
            n_gen = len(output_ids[0]) - len(prompt_ids)
            tok_per_sec = n_gen / max(elapsed, 0.001)

            print(f"{generated_text}")
            print(f"  [{n_gen} tokens, {tok_per_sec:.1f} tok/s, {elapsed:.2f}s]\n")
    else:
        # Single prompt generation
        prompt = args.prompt or "The fundamental nature of intelligence is"
        print(f"\nPrompt: {prompt}\n")

        prompt_ids = tokenizer.encode(prompt)
        input_ids = torch.tensor([prompt_ids], device=device)

        t0 = time.time()
        output_ids = generate(
            model, input_ids,
            max_new_tokens=args.max_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
            top_p=args.top_p,
            device=device,
        )
        elapsed = time.time() - t0

        full_text = tokenizer.decode(output_ids[0].tolist())
        generated_text = full_text[len(prompt):]
        n_gen = len(output_ids[0]) - len(prompt_ids)
        tok_per_sec = n_gen / max(elapsed, 0.001)

        print(f"Generated ({n_gen} tokens, {tok_per_sec:.1f} tok/s):\n")
        print(full_text)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate text with HelixGPT")
    parser.add_argument("--checkpoint", type=str, required=True,
                        help="Path to model checkpoint (.pt)")
    parser.add_argument("--prompt", type=str, default=None,
                        help="Input prompt text")
    parser.add_argument("--max-tokens", type=int, default=256)
    parser.add_argument("--temperature", type=float, default=0.8)
    parser.add_argument("--top-k", type=int, default=200)
    parser.add_argument("--top-p", type=float, default=0.95)
    parser.add_argument("--tokenizer", type=str, default="gpt2")
    parser.add_argument("--interactive", action="store_true",
                        help="Interactive chat mode")

    args = parser.parse_args()
    main(args)
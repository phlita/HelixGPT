"""
Topological Decay & Phase Transition Avalanche

Two core innovations from Zhang Xiangqian's unified field theory
applied to neural network architectures:

1. TopologicalDecay: Distance-based attention attenuation using the geometric
   constant alpha_geom = 1/(4*pi^3 + pi^2 + pi) ≈ 0.00716
   This replaces ad-hoc attention biases (Alibi, etc.) with a physically
   motivated decay that reflects how gravitational/electromagnetic fields
   attenuate through space.

2. PhaseTransitionAvalanche: A dual-regime activation function that replaces
   both Softmax (in attention) and ReLU/SiLU (in FFN).
   
   Low stress regime: smooth information flow (maintaining context coherence)
   High stress regime: "topological collapse" producing sparse, creative
   activations (the AI equivalent of a phase transition / eureka moment)
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from helixgpt.constants import (
    ALPHA_GEOM,
    ALPHA_GEOM_SQUARED,
    TOPO_QUANTUM,
    PHASE_TRANSITION_THRESHOLD,
    AVALANCHE_MULTIPLIER,
    PHASE_TRANSITION_WIDTH,
    get_alpha_geom,
    get_phase_threshold,
)


class TopologicalDecay(nn.Module):
    """Topological Geometric Decay for Attention Scores.

    Implements distance-dependent attention attenuation based on the
    fundamental constant:

        alpha_geom = 1 / (4*pi^3 + pi^2 + pi) ≈ 0.00716

    In Zhang Xiangqian's theory, this constant represents the topological
    lock-phase threshold that prevents the cylindrical helix manifold
    from collapsing. When applied to attention:

    - Each token-to-token distance d gets multiplied by a decay factor
    - This decay is NOT learned — it's a fixed geometric property
    - It naturally produces the 1/137-like fine-structure behavior

    Supports three decay modes:
        "linear":       alpha^d           (exponential, electromagnetic-like)
        "quadratic":    alpha^(2d)        (stronger, gravitational-like)
        "inverse_sq":   1/(1 + alpha*d^2) (slow, inverse-square law)
    """

    def __init__(
        self,
        max_seq_length: int = 2048,
        decay_mode: str = "linear",
        max_decay_distance: int = 512,
        decay_floor: float = 1e-6,
    ):
        super().__init__()
        self.max_seq_length = max_seq_length
        self.decay_mode = decay_mode
        self.max_decay_distance = max_decay_distance
        self.decay_floor = decay_floor

        # Pre-compute the decay matrix: (max_seq_length, max_seq_length)
        # decay[i, j] = f(|i - j|)
        # This is cached and indexed during forward, avoiding per-call computation.
        self.register_buffer(
            "_decay_cache",
            self._build_decay_matrix(max_seq_length),
            persistent=False,
        )

    def _build_decay_matrix(self, seq_len: int) -> torch.Tensor:
        """Build the full topological decay matrix.

        Args:
            seq_len: Maximum sequence length.

        Returns:
            Decay matrix of shape (seq_len, seq_len), symmetric.
        """
        # Distance matrix: |i - j|
        positions = torch.arange(seq_len, dtype=torch.float32)
        distances = (positions.unsqueeze(0) - positions.unsqueeze(1)).abs()

        # Clamp distances to prevent overflow
        distances = torch.clamp(distances, min=0, max=self.max_decay_distance)

        if self.decay_mode == "linear":
            # alpha_geom ^ distance
            # This is the pure topological decay
            decay = ALPHA_GEOM ** distances

        elif self.decay_mode == "quadratic":
            # alpha_geom ^ (2 * distance)
            # Stronger decay, analogous to gravitational field attenuation
            decay = ALPHA_GEOM_SQUARED ** distances

        elif self.decay_mode == "inverse_square":
            # 1 / (1 + alpha * d^2)
            # Inverse-square law, slowest decay
            decay = 1.0 / (1.0 + ALPHA_GEOM * distances ** 2)

        else:
            raise ValueError(f"Unknown decay mode: {self.decay_mode}")

        # Apply floor to prevent complete extinction of distant tokens
        decay = torch.clamp(decay, min=self.decay_floor)

        return decay

    def forward(
        self,
        scores: torch.Tensor,
        seq_len: int | None = None,
    ) -> torch.Tensor:
        """Apply topological decay to attention scores.

        Args:
            scores: Attention scores, shape (B, nh, T_q, T_k) or (nh, T_q, T_k)
            seq_len: Optional sequence length override.

        Returns:
            Decay-modulated attention scores, same shape as input.
        """
        T_k = scores.shape[-1]

        # Slice the pre-computed decay matrix to match actual sequence length
        decay = self._decay_cache[:T_k, :T_k].to(scores.device, scores.dtype)

        # Expand for batch and head dimensions
        # scores: (B, nh, T_q, T_k) or (nh, T_q, T_k)
        while decay.dim() < scores.dim():
            decay = decay.unsqueeze(0)

        return scores * decay


class PhaseTransitionAvalanche(nn.Module):
    """Phase Transition Avalanche Activation Function.

    Replaces traditional smooth activations (ReLU, SiLU, GELU) and Softmax
    with a dual-regime mechanism inspired by the phase transitions in
    Zhang Xiangqian's unified field theory.

    Physical motivation:
        In the unified field theory, when gravitational tension (stress)
        in the cylindrical helix space exceeds a critical threshold,
        the space structure undergoes a topological collapse —
        the "jelly effect" (96% mass loss) — producing a burst of
        electromagnetic radiation.

    In the neural network, this manifests as:
        - Low stress:  smooth linear mapping (context preservation)
        - High stress: sparse avalanche activation (creative jumps)

    The transition is controlled by a sigmoid gate:

        gate = sigmoid((|stress| - threshold) / width)

        output = (1 - gate) * smooth_path(x) + gate * avalanche_path(x)

    Where:
        smooth_path(x) = x  (identity, preserving information flow)
        avalanche_path(x) = sign(x) * |x| * multiplier  (amplified sparse signal)
    """

    def __init__(
        self,
        threshold_multiplier: float = 1.0,
        transition_width: float = 0.01,
        avalanche_multiplier: float = 22.24,
        learnable_threshold: bool = False,
    ):
        super().__init__()
        self.transition_width = transition_width
        self.avalanche_multiplier = avalanche_multiplier

        # Phase transition threshold
        base_threshold = PHASE_TRANSITION_THRESHOLD * threshold_multiplier
        if learnable_threshold:
            self.threshold = nn.Parameter(torch.tensor(base_threshold))
        else:
            self.register_buffer(
                "threshold",
                torch.tensor(base_threshold),
                persistent=False,
            )

    def compute_stress(self, x: torch.Tensor) -> torch.Tensor:
        """Compute the interference stress tensor magnitude.

        The stress is a measure of how much "tension" exists in the
        information flow. We compute it as the Frobenius norm of the
        local feature tensor, normalized by dimension.

        For the (amplitude, phase) representation:
            stress = sqrt(mean(amplitude^2) + mean(phase_variance^2))

        Args:
            x: Input tensor, shape (..., d)

        Returns:
            Stress magnitude, shape (..., 1) or scalar
        """
        # Frobenius-like norm, normalized
        # Use the L2 norm per token, averaged over features
        stress = torch.norm(x.float(), p=2, dim=-1, keepdim=True) / math.sqrt(x.shape[-1])
        return stress

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply phase transition avalanche activation.

        Args:
            x: Input tensor of arbitrary shape (..., d).

        Returns:
            Activated tensor of same shape.
        """
        # Compute stress (interference tension)
        stress = self.compute_stress(x)  # (..., 1)

        # Sigmoid gate: smooth transition at the threshold
        gate = torch.sigmoid(
            (stress - self.threshold.to(x.dtype)) / self.transition_width
        )  # (..., 1)

        # === Smooth Path (low stress) ===
        # Identity mapping with slight nonlinearity for gradient flow
        smooth = x

        # === Avalanche Path (high stress) ===
        # When stress exceeds threshold, produce a "topological collapse" —
        # an amplified sparse signal
        # This is the neural equivalent of the electromagnetic shockwave
        # from the jelly-effect phase transition.
        
        # Sparse amplification: only amplify dimensions with large magnitude
        abs_x = torch.abs(x) + 1e-8
        # Normalize to unit scale, then amplify
        avalanche_sign = torch.sign(x)
        avalanche_mag = abs_x / (abs_x.max(dim=-1, keepdim=True)[0] + 1e-8)
        # Apply power law to increase sparsity
        avalanche_mag = avalanche_mag ** 0.5  # Square root increases contrast
        avalanche = avalanche_sign * avalanche_mag * abs_x * self.avalanche_multiplier

        # Blend via the gate
        output = (1.0 - gate) * smooth + gate * avalanche

        return output.to(dtype=x.dtype)


class HelixSoftmax(nn.Module):
    """Helix-Aware Normalization (replaces Softmax).

    Traditional Softmax assumes a closed thermodynamic system (probabilities sum to 1).
    In the cylindrical helix model, information flow is DIVERGENT (open system).

    This module:
    1. Applies topological decay to raw scores
    2. Uses a modified normalization that allows "energy leakage"
       (not all attention mass must sum to 1 — some can "escape" along Z-axis)

    The normalization is:
        w_i = exp(score_i * topological_decay_i) / (sum_j exp(score_j * topological_decay_j) + escape_term)

    Where escape_term = alpha_geom * sum represents information that
    "diverges to infinity" along the Z-axis (light-speed information loss).
    """

    def __init__(self, topological_decay: TopologicalDecay):
        super().__init__()
        self.topo_decay = topological_decay

    def forward(self, scores: torch.Tensor) -> torch.Tensor:
        """Helix-aware attention normalization.

        Args:
            scores: Raw attention scores, shape (B, nh, T_q, T_k)

        Returns:
            Normalized attention weights (do NOT sum to exactly 1).
        """
        dtype = scores.dtype
        scores = scores.float()

        # Apply topological decay
        scores = self.topo_decay(scores)

        # Standard softmax for the attention distribution
        weights = F.softmax(scores, dim=-1)

        # "Information escape" along Z-axis:
        # Reduce total attention mass by alpha_geom fraction,
        # simulating information that diverges to infinity
        escape = get_alpha_geom(device=scores.device, dtype=scores.dtype)
        weights = weights * (1.0 - escape)

        return weights.to(dtype=dtype)
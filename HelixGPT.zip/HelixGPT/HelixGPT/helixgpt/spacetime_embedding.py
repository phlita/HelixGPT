"""
Spacetime Spinor Embedding Layer

Replaces the traditional real-valued token embedding (a flat vector in R^d)
with a complex-valued "micro particle" representation on a cylindrical helix.

Each token is no longer a dead point in Euclidean space, but a rotating
miniature space-time vortex:

    Psi_n = A_n * exp(i * (omega * t - theta_n))

Where:
    A_n     = radial amplitude  (real part) -> electromagnetic / explicit info
    theta_n = angular phase     (imaginary part) -> gravitational / implicit context

Implementation strategy:
    Since GPU native complex support is limited, we split the hidden dimension
    into two halves:
        x[..., :d//2]  -> amplitude  (x_radial)
        x[..., d//2:]  -> phase      (x_angular)
    
    The complex multiplication and interference operations then work on
    these paired (amplitude, phase) representations.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from helixgpt.constants import HELIX_OMEGA_BASE, C_INFO


class SpacetimeSpinorEmbedding(nn.Module):
    """Cylindrical Helix Space-Time Spinor Embedding.

    Transforms integer token indices into (amplitude, phase) pairs that
    represent points on a cylindrical helix manifold.

    The embedding weight matrix has shape (vocab_size, n_embd), where:
        - First half  [0, n_embd//2): radial amplitude (x_radial)
        - Second half [n_embd//2, n_embd): angular phase (x_angular)

    During initialization, amplitudes are initialized normally (like standard
    embeddings), while phases are initialized uniformly on [0, 2*pi) to
    ensure all tokens start at random angular positions on the helix.
    """

    def __init__(
        self,
        vocab_size: int,
        n_embd: int,
        helix_radius_init: float = 0.02,
        helix_omega_multiplier: float = 1.0,
    ):
        super().__init__()
        assert n_embd % 2 == 0, (
            f"n_embd must be even for spacetime spinor embedding, got {n_embd}"
        )
        self.n_embd = n_embd
        self.half_dim = n_embd // 2
        self.helix_radius_init = helix_radius_init
        self.helix_omega_multiplier = helix_omega_multiplier

        # Standard embedding table - will be re-purposed as (amplitude, phase) pairs
        self.weight = nn.Parameter(torch.empty(vocab_size, n_embd))

        # The omega (angular frequency) per dimension channel
        # This creates different rotation speeds for different "frequency bands"
        # of the information space, similar to how RoPE uses different theta_i
        omega = HELIX_OMEGA_BASE * helix_omega_multiplier
        freqs = 1.0 / (10000.0 ** (torch.arange(0, self.half_dim, dtype=torch.float32) / self.half_dim))
        self.register_buffer(
            "helix_frequencies",
            freqs * omega,  # shape: (half_dim,)
            persistent=False,
        )

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Initialize embedding with proper helix structure.

        Amplitudes (first half): normal initialization (controls radial extent).
        Phases (second half): uniform on [0, 2*pi) (random angular positions).
        """
        nn.init.normal_(self.weight[:, :self.half_dim], mean=0.0, std=self.helix_radius_init)
        # Initialize phases uniformly on [0, 2*pi)
        nn.init.uniform_(self.weight[:, self.half_dim:], a=0.0, b=2.0 * math.pi)

    def forward(self, idx: torch.Tensor, input_pos: torch.Tensor | None = None) -> torch.Tensor:
        """Lookup token embeddings and convert to (amplitude, phase) form.

        Args:
            idx: Token indices, shape (B, T)
            input_pos: Optional position indices, shape (T,) or (B, T).
                       If provided, phases are modulated by position-dependent
                       helix rotation (light-speed divergence + angular rotation).

        Returns:
            Tensor of shape (B, T, n_embd) where:
                [..., :half_dim] = radial amplitudes A_n
                [..., half_dim:] = angular phases theta_n
        """
        # Standard embedding lookup: (B, T, n_embd)
        x = F.embedding(idx, self.weight)

        # Extract amplitude and phase components
        amplitude = x[..., :self.half_dim]  # (B, T, half_dim) - electromagnetic component
        phase = x[..., self.half_dim:]       # (B, T, half_dim) - gravitational component

        if input_pos is not None:
            # Apply position-dependent helix rotation
            # This is the "light-speed divergence along Z-axis" combined
            # with angular rotation in the XY-plane
            if input_pos.dim() == 1:
                # (T,) -> (1, T, 1) for broadcasting
                pos = input_pos.float().unsqueeze(0).unsqueeze(-1)
            else:
                # (B, T) -> (B, T, 1)
                pos = input_pos.float().unsqueeze(-1)

            # Helix frequencies: (1, 1, half_dim)
            freqs = self.helix_frequencies.unsqueeze(0).unsqueeze(0)

            # Phase modulation: theta_n + omega_i * position
            # This makes each token's vortex rotate as we advance through the sequence
            phase = phase + freqs * pos

            # Amplitude modulation (Z-axis divergence):
            # The radial amplitude gets a positional bias that grows linearly,
            # simulating the "light-speed straight-line divergence" along Z.
            # We use a soft saturation to prevent explosion.
            z_divergence = C_INFO * pos * 0.01  # Gentle divergence, scaled down
            amplitude = amplitude * torch.tanh(amplitude + z_divergence) / (torch.tanh(amplitude.new_tensor(1.0)) + 1e-8)

        # Recombine into single tensor
        return torch.cat([amplitude, phase], dim=-1)

    @staticmethod
    def to_polar(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Convert (amplitude, phase) representation to polar (r, theta).

        Args:
            x: Tensor of shape (..., n_embd) in (amplitude, phase) form.

        Returns:
            r: Amplitude (radial component), shape (..., n_embd//2)
            theta: Phase (angular component), shape (..., n_embd//2)
        """
        half = x.shape[-1] // 2
        return x[..., :half], x[..., half:]

    @staticmethod
    def to_complex(x: torch.Tensor) -> torch.Tensor:
        """Convert (amplitude, phase) to actual complex tensor.

        Returns complex tensor: amplitude * exp(i * phase)

        Args:
            x: Tensor of shape (..., n_embd) in (amplitude, phase) form.

        Returns:
            Complex tensor of shape (..., n_embd//2)
        """
        half = x.shape[-1] // 2
        amplitude = x[..., :half]
        phase = x[..., half:]
        # Use Euler's formula: A * (cos(theta) + i*sin(theta))
        return amplitude * torch.polar(
            torch.ones_like(amplitude), phase
        )

    @staticmethod
    def from_complex(z: torch.Tensor) -> torch.Tensor:
        """Convert complex tensor back to (amplitude, phase) stacked form.

        Args:
            z: Complex tensor of shape (..., d)

        Returns:
            Real tensor of shape (..., 2*d) with [amplitude, phase] stacked.
        """
        amplitude = z.abs()
        phase = z.angle()
        return torch.cat([amplitude, phase], dim=-1)
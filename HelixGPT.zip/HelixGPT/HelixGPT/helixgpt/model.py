"""
HelixGPT — Spiral Space-Time Generative Pre-trained Transformer

The complete model that assembles all helix components into a unified
decoder-only transformer, built on the modular architecture of LitGPT.

Architecture Overview:
    ┌─────────────────────────────────────────────────────────────┐
    │  Input Tokens (B, T)                                        │
    │       ↓                                                     │
    │  SpacetimeSpinorEmbedding → (amplitude, phase) pairs        │
    │       ↓                                                     │
    │  ┌─────────────────────────────────────────────────────┐    │
    │  │  HelixBlock × n_layer:                              │    │
    │  │    ├─ RMSNorm                                       │    │
    │  │    ├─ HelixInterferenceAttention                    │    │
    │  │    │    ├─ Q/K/V projection (amplitude+phase)      │    │
    │  │    │    ├─ Helix-RoPE (3D cylindrical helix)       │    │
    │  │    │    ├─ Phase Interference (not dot product!)    │    │
    │  │    │    ├─ Topological Decay (alpha_geom ≈ 1/137)  │    │
    │  │    │    └─ HelixSoftmax (open-system normalization) │    │
    │  │    ├─ RMSNorm                                       │    │
    │  │    ├─ HelixMLP                                      │    │
    │  │    │    ├─ Linear → PhaseTransitionAvalanche        │    │
    │  │    │    └─ Linear (gate) × Linear → SwiGLU-like    │    │
    │  │    └─ Residual Connection                           │    │
    │  └─────────────────────────────────────────────────────┘    │
    │       ↓                                                     │
    │  RMSNorm (final)                                             │
    │       ↓                                                     │
    │  lm_head → Logits (B, T, vocab_size)                        │
    └─────────────────────────────────────────────────────────────┘
"""

import math
from functools import partial
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing_extensions import Self

from helixgpt.config import HelixConfig
from helixgpt.spacetime_embedding import SpacetimeSpinorEmbedding
from helixgpt.helix_attention import HelixInterferenceAttention, KVCache
from helixgpt.helix_rope import build_helix_rope_cache, apply_helix_rope, apply_helix_rope_interleave
from helixgpt.phase_transition import PhaseTransitionAvalanche, TopologicalDecay

# Reuse LitGPT's RMSNorm (proven, efficient)
import sys
sys.path.insert(0, "/home/z/my-project/litgpt")
from litgpt.model import RMSNorm


class HelixMLP(nn.Module):
    """Helix-augmented MLP with Phase Transition Avalanche activation.

    Replaces the standard LLaMAMLP (SwiGLU) with a dual-regime FFN:
    - Low stress:  standard SwiGLU (smooth, context-preserving)
    - High stress: avalanche activation (sparse, creative)

    Architecture:
        x → fc_1 → PhaseTransitionAvalanche → (× fc_2) → proj → output

    The gate (fc_2) path uses standard SiLU to maintain gradient flow,
    while the main path uses the phase transition for creative potential.
    """

    def __init__(self, config: HelixConfig):
        super().__init__()
        intermediate_size = config.n_embd * config.expansion_ratio
        self.fc_1 = nn.Linear(config.n_embd, intermediate_size, bias=config.bias)
        self.fc_2 = nn.Linear(config.n_embd, intermediate_size, bias=config.bias)
        self.proj = nn.Linear(intermediate_size, config.n_embd, bias=config.bias)
        self.config = config

        # Phase Transition Avalanche (replaces SiLU/GELU on main path)
        if config.use_phase_transition:
            self.avalanche = PhaseTransitionAvalanche(
                threshold_multiplier=config.phase_threshold_multiplier,
                transition_width=config.phase_transition_width,
                avalanche_multiplier=config.avalanche_multiplier,
                learnable_threshold=False,
            )
        else:
            self.avalanche = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_fc1 = self.fc_1(x)
        x_fc2 = self.fc_2(x)

        # Main path: phase transition avalanche (or fallback to SiLU)
        if self.avalanche is not None:
            x_main = self.avalanche(x_fc1)
        else:
            x_main = F.silu(x_fc1)

        # Gate path: standard SiLU (maintains stable gradient flow)
        x_gate = F.silu(x_fc2)

        # SwiGLU-style gated combination
        x = x_main * x_gate
        return self.proj(x)


class HelixBlock(nn.Module):
    """A single HelixGPT transformer block.

    Structure (parallel residual, same as LLaMA):
        x ─┬─→ norm_1 → helix_attention → post_attn_norm ─→ (+) ──→ output
           └─→ norm_2 → helix_mlp      → post_mlp_norm  ─┘
    """

    def __init__(self, config: HelixConfig, block_idx: int):
        super().__init__()
        self.norm_1 = nn.Identity() if not config.norm_1 else config.norm_class(config.n_embd, eps=config.norm_eps)
        self.attn = HelixInterferenceAttention(config, block_idx)
        self.post_attention_norm = (
            config.norm_class(config.n_embd, eps=config.norm_eps)
            if config.post_attention_norm
            else nn.Identity()
        )
        self.norm_2 = (
            nn.Identity()
            if not config.norm_2
            else (None if config.shared_attention_norm else config.norm_class(config.n_embd, eps=config.norm_eps))
        )
        self.mlp = HelixMLP(config)
        self.post_mlp_norm = (
            config.norm_class(config.n_embd, eps=config.norm_eps)
            if config.post_mlp_norm
            else nn.Identity()
        )
        self.config = config

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        z_shift: torch.Tensor | None = None,
        mask: torch.Tensor | None = None,
        input_pos: torch.Tensor | None = None,
        input_pos_maxp1: int | None = None,
    ) -> torch.Tensor:
        x_normed = self.norm_1(x)
        attention_output = self.attn(
            x_normed, cos, sin, z_shift, mask, input_pos, input_pos_maxp1
        )
        attention_output = self.post_attention_norm(attention_output)

        if self.config.parallel_residual:
            if not self.config.shared_attention_norm:
                x_normed = self.norm_2(x)
            x = attention_output + x
        else:
            x = attention_output + x
            x_normed = self.norm_2(x)

        return self.post_mlp_norm(self.mlp(x_normed)) + x


class HelixGPT(nn.Module):
    """HelixGPT: Spiral Space-Time Generative Pre-trained Transformer.

    A complete decoder-only language model that replaces the fundamental
    operations of traditional transformers with physics-motivated
    equivalents from Zhang Xiangqian's unified field theory.

    Key Differences from Standard GPT:
    1. Embedding: (amplitude, phase) pairs instead of flat real vectors
    2. Attention: Phase interference instead of dot products
    3. Position: 3D helix displacement instead of 2D rotation
    4. Decay: Geometric constant alpha_geom instead of ad-hoc biases
    5. Activation: Phase transition avalanche instead of ReLU/SiLU
    6. Normalization: Open-system (leaky) instead of closed-system Softmax
    """

    def __init__(self, config: HelixConfig) -> None:
        super().__init__()
        assert config.padded_vocab_size is not None
        self.config = config

        # === Spacetime Spinor Embedding (replaces nn.Embedding) ===
        if config.use_spacetime_spinor:
            self.transformer = nn.ModuleDict(
                dict(
                    wte=SpacetimeSpinorEmbedding(
                        vocab_size=config.padded_vocab_size,
                        n_embd=config.n_embd,
                        helix_radius_init=config.helix_radius_init,
                        helix_omega_multiplier=config.helix_omega_multiplier,
                    ),
                    h=nn.ModuleList(
                        HelixBlock(config, block_idx)
                        for block_idx in range(config.n_layer)
                    ),
                    ln_f=RMSNorm(config.n_embd, eps=config.norm_eps),
                )
            )
        else:
            # Fallback: standard embedding (for ablation studies)
            self.transformer = nn.ModuleDict(
                dict(
                    wte=nn.Embedding(config.padded_vocab_size, config.n_embd),
                    h=nn.ModuleList(
                        HelixBlock(config, block_idx)
                        for block_idx in range(config.n_layer)
                    ),
                    ln_f=RMSNorm(config.n_embd, eps=config.norm_eps),
                )
            )

        # Language model head
        self.lm_head = nn.Linear(config.n_embd, config.padded_vocab_size, bias=config.lm_head_bias)

        self.mask_cache: torch.Tensor | None = None
        self._max_seq_length = config.block_size

        # === Helix-RoPE Cache ===
        if config.use_helix_rope:
            cos, sin, z_shift = build_helix_rope_cache(
                seq_len=config.block_size,
                n_elem=config.rope_n_elem,
                c_divergence=config.c_divergence,
                helix_pitch=config.helix_pitch,
                base=config.rope_base,
            )
            self.register_buffer("cos", cos, persistent=False)
            self.register_buffer("sin", sin, persistent=False)
            self.register_buffer("z_shift", z_shift, persistent=False)
        else:
            # Fallback: standard 2D RoPE (for ablation)
            from litgpt.model import build_rope_cache
            cos, sin = build_rope_cache(
                seq_len=config.block_size,
                n_elem=config.rope_n_elem,
                base=config.rope_base,
            )
            self.register_buffer("cos", cos, persistent=False)
            self.register_buffer("sin", sin, persistent=False)
            self.register_buffer("z_shift", None, persistent=False)

    @property
    def max_seq_length(self) -> int:
        return self._max_seq_length

    @max_seq_length.setter
    def max_seq_length(self, value: int) -> None:
        if value > self.config.block_size:
            raise ValueError(
                f"Cannot attend to {value}, block size is only {self.config.block_size}."
            )
        self._max_seq_length = value

    def forward(
        self,
        idx: torch.Tensor,
        input_pos: torch.Tensor | None = None,
        input_pos_maxp1: int | None = None,
        lm_head_chunk_size: int = 0,
    ) -> torch.Tensor | list[torch.Tensor]:
        """Forward pass.

        Args:
            idx: Token indices (B, T).
            input_pos: Optional position indices for KV cache.
            input_pos_maxp1: Optional max position + 1.
            lm_head_chunk_size: If > 0, chunk the lm_head computation.

        Returns:
            Logits (B, T, vocab_size) or list of chunks.
        """
        T = idx.size(1)
        if self.max_seq_length < T:
            raise ValueError(
                f"Cannot forward sequence of length {T}, max is {self.max_seq_length}."
            )

        B = idx.size(0)

        if input_pos is not None:
            # Inference with KV cache
            if input_pos.dim() > 2:
                raise ValueError(f"input_pos must have 1 or 2 dimensions, got {input_pos.shape}")
            if input_pos.shape[-1] != T:
                raise ValueError(f"input_pos.shape[-1] = {input_pos.shape[-1]} != {T}")

            cos = self._batched_index_select(self.cos, 0, input_pos).unsqueeze(0) if input_pos.dim() == 1 else self._batched_index_select(self.cos, 0, input_pos)
            sin = self._batched_index_select(self.sin, 0, input_pos).unsqueeze(0) if input_pos.dim() == 1 else self._batched_index_select(self.sin, 0, input_pos)

            if self.z_shift is not None:
                z_sel = self._batched_index_select(self.z_shift, 0, input_pos).unsqueeze(0) if input_pos.dim() == 1 else self._batched_index_select(self.z_shift, 0, input_pos)
            else:
                z_sel = None

            if self.mask_cache is None:
                raise TypeError("You need to call `model.set_kv_cache()`")
            mask = self._batched_index_select(self.mask_cache, 2, input_pos)
            if mask.dim() > 4:
                mask = mask.view(*(mask.shape[0:1] + mask.shape[2:]))
            if input_pos_maxp1 is not None:
                mask = mask[..., :input_pos_maxp1]
        else:
            # Training mode: no KV cache
            cos = self.cos[:T].unsqueeze(0)  # (1, T, rope_n_elem)
            sin = self.sin[:T].unsqueeze(0)
            z_sel = self.z_shift[:T].unsqueeze(0) if self.z_shift is not None else None
            mask = None
            input_pos_maxp1 = None

        # === Token Embedding ===
        if self.config.use_spacetime_spinor:
            x = self.transformer.wte(idx, input_pos=input_pos)  # (B, T, n_embd)
        else:
            x = self.transformer.wte(idx)
            if self.config.scale_embeddings:
                x = x * torch.tensor(self.config.n_embd ** 0.5, dtype=x.dtype)

        # === Transformer Blocks ===
        for block in self.transformer.h:
            x = block(x, cos, sin, z_sel, mask, input_pos, input_pos_maxp1)

        # === Final Norm + LM Head ===
        x = self.transformer.ln_f(x)

        if lm_head_chunk_size > 0:
            return [self.lm_head(x_i) for x_i in x.split(lm_head_chunk_size, dim=1)]
        else:
            return self.lm_head(x)

    # ====================================================================
    # KV Cache Management (for inference)
    # ====================================================================

    def set_kv_cache(
        self,
        batch_size: int,
        max_seq_length: int | None = None,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
    ) -> None:
        if max_seq_length is None:
            max_seq_length = self.max_seq_length
        for block in self.transformer.h:
            block.attn.kv_cache = block.attn.build_kv_cache(
                batch_size, max_seq_length, device, dtype
            )
        if self.mask_cache is None or self.mask_cache.size(3) != max_seq_length:
            self.mask_cache = self._build_mask_cache(max_seq_length, device)

    def clear_kv_cache(self) -> None:
        self.mask_cache = None
        for block in self.transformer.h:
            block.attn.kv_cache = None

    @staticmethod
    def _build_mask_cache(max_seq_length: int, device: torch.device | None = None) -> torch.Tensor:
        ones = torch.ones((max_seq_length, max_seq_length), device=device, dtype=torch.bool)
        return torch.tril(ones).unsqueeze(0).unsqueeze(0)

    @staticmethod
    def _batched_index_select(t, dim, idx):
        if idx.dim() == 1:
            return torch.index_select(t, dim, idx)
        *batch_shape, idx_size = idx.shape
        res = torch.index_select(t, dim, idx.reshape(-1))
        res = res.view(*t.shape[:dim], -1, idx_size, *t.shape[dim + 1:])
        if dim > 0:
            dims = [dim] + list(range(res.dim()))
            del dims[dim + 1]
            res = res.permute(dims)
        return res.view(*batch_shape, *res.shape[1:])

    # ====================================================================
    # Utilities
    # ====================================================================

    def _init_weights(self, module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    @classmethod
    def from_name(cls, name: str, **kwargs: Any) -> Self:
        from helixgpt.config import helixgpt_60m, helixgpt_100m, helixgpt_350m, helixgpt_1b
        builders = {
            "helixgpt-60M": helixgpt_60m,
            "helixgpt-100M": helixgpt_100m,
            "helixgpt-350M": helixgpt_350m,
            "helixgpt-1B": helixgpt_1b,
        }
        if name not in builders:
            raise ValueError(f"Unknown model: {name}. Available: {list(builders.keys())}")
        config = builders[name](**kwargs)
        return cls(config)

    def num_parameters(self, trainable_only: bool = True) -> int:
        """Count total parameters."""
        if trainable_only:
            return sum(p.numel() for p in self.parameters() if p.requires_grad)
        return sum(p.numel() for p in self.parameters())
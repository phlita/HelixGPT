"""
Tokenizer utilities for HelixGPT.

Uses the GPT-2 tokenizer (BPE, 50257 vocab) as the default.
Can be swapped for any HuggingFace tokenizer.
"""

from pathlib import Path
from typing import Optional


def get_tokenizer(
    tokenizer_path: str | Path | None = None,
    tokenizer_type: str = "gpt2",
):
    """Get a tokenizer instance.

    Args:
        tokenizer_path: Path to a local tokenizer directory.
                      If None, downloads from HuggingFace.
        tokenizer_type: Type of tokenizer ("gpt2", "llama", etc.)

    Returns:
        A tokenizer with encode/decode methods.
    """
    try:
        from transformers import AutoTokenizer
    except ImportError:
        raise ImportError(
            "transformers is required for tokenization. "
            "Install with: pip install transformers"
        )

    if tokenizer_path is not None:
        return AutoTokenizer.from_pretrained(tokenizer_path)
    else:
        return AutoTokenizer.from_pretrained(tokenizer_type)


def encode(text: str, tokenizer, max_length: int = 2048) -> list[int]:
    """Encode text to token IDs."""
    ids = tokenizer.encode(text)
    return ids[:max_length]


def decode(token_ids: list[int], tokenizer) -> str:
    """Decode token IDs to text."""
    return tokenizer.decode(token_ids, skip_special_tokens=True)
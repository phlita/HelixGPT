"""
Helix-RoPE: 3D Cylindrical Helix Rotary Position Embedding

Upgrades standard 2D RoPE (rotation in XY-plane) to a full 3D cylindrical
helix displacement:

    Standard RoPE:    x(t) = r * cos(theta),  y(t) = r * sin(theta)
    Helix-RoPE:       x(t) = r * cos(theta),  y(t) = r * sin(theta),  z(t) = c * t

The Z-axis component represents the "light-speed information divergence"
along the sequence, while the XY rotation represents the "gravitational
angular constraint".

Key insight from Zhang Xiangqian's theory:
    RoPE is already a "half-finished product" of the helix model!
    It rotates in 2D but lacks the crucial 3rd dimension (Z-axis divergence).
    Helix-RoPE completes this by adding the axial (Z) component.

The Z-component is implemented as a position-dependent linear phase shift
that is NOT periodic, allowing the model to distinguish absolute positions
(not just relative angles like standard RoPE).
"""

import math
import torch
from typing import Literal

from helixgpt.constants import HELIX_OMEGA_BASE, C_INFO, PI


def build_helix_rope_cache(
    seq_len: int,
    n_elem: int,
    device: torch.device | None = None,
    base: int = 10000,
    c_divergence: float = 1.0,
    helix_pitch: float = 1.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Build the 3D Helix-RoPE cache.

    Unlike standard RoPE which returns only (cos, sin) for 2D rotation,
    Helix-RoPE returns (cos, sin, z_shift) where z_shift encodes the
    axial (light-speed divergence) component.

    The helix parameterization:
        For each frequency band i and position t:
            theta_i(t) = t / (base^(2i/d))           [angular rotation, same as RoPE]
            z_i(t)     = c * pitch * t / (base^(2i/d)) [axial divergence, NEW]

    Args:
        seq_len: Maximum sequence length.
        n_elem: Number of rotary elements (usually head_size or rope_n_elem).
        device: Torch device.
        base: Base for frequency computation (same as standard RoPE).
        c_divergence: Light-speed divergence rate along Z-axis.
        helix_pitch: Pitch of the helix (vertical advance per rotation).

    Returns:
        cos: Cosine of angular rotation, shape (seq_len, n_elem)
        sin: Sine of angular rotation, shape (seq_len, n_elem)
        z_shift: Axial Z-displacement, shape (seq_len, n_elem)
    """
    # Compute inverse frequencies (same as standard RoPE)
    # theta_i = 1 / (base^(2i/d)) for i = 0, 1, ..., d/2-1
    theta = 1.0 / (base ** (torch.arange(0, n_elem, 2, device=device).float() / n_elem))

    # Position indices
    seq_idx = torch.arange(seq_len, device=device).float()  # (seq_len,)

    # ========================================
    # 2D Component: Angular rotation (XY-plane)
    # Same as standard RoPE - this is the gravitational/angular constraint
    # ========================================
    idx_theta = torch.outer(seq_idx, theta)  # (seq_len, n_elem//2)
    idx_theta = idx_theta.repeat(1, 2)       # (seq_len, n_elem) duplicate for pairs

    if idx_theta.shape[-1] > n_elem > 1:
        idx_theta = idx_theta[..., :n_elem]

    cos = torch.cos(idx_theta)
    sin = torch.sin(idx_theta)

    # ========================================
    # 3D Component: Axial Z-divergence (NEW!)
    # This is the light-speed information propagation along the helix axis.
    # Unlike the angular rotation which is periodic, Z-divergence is MONOTONIC,
    # allowing the model to encode absolute positional information.
    # ========================================
    # z_i(t) = c * pitch * t * theta_i
    # The divergence rate is proportional to the angular frequency:
    # higher-frequency dimensions diverge faster (more "energetic" information channels)
    idx_z = torch.outer(seq_idx, theta) * (c_divergence * helix_pitch)
    idx_z = idx_z.repeat(1, 2)
    if idx_z.shape[-1] > n_elem > 1:
        idx_z = idx_z[..., :n_elem]

    # We modulate the amplitude by (1 + z_shift) instead of adding z_shift directly
    # This ensures the Z-component acts as a multiplicative "energy scale"
    # rather than an additive bias, preserving the zero-mean property.
    z_shift = idx_z  # Will be used as multiplicative modulation

    return cos, sin, z_shift


def apply_helix_rope(
    x: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
    z_shift: torch.Tensor,
) -> torch.Tensor:
    """Apply 3D Helix-RoPE to input tensor.

    Performs two operations simultaneously:
    1. Standard 2D rotation (same as apply_rope): rotates pairs in XY-plane
    2. Axial Z-modulation: multiplies by (1 + z_shift) to encode divergence

    The combined operation on a pair (x_{2i}, x_{2i+1}):
        x'_2i   = (x_{2i} * cos_i - x_{2i+1} * sin_i) * (1 + z_i)
        x'_{2i+1} = (x_{2i} * sin_i + x_{2i+1} * cos_i) * (1 + z_i)

    In complex notation: z' = z * e^(i*theta) * (1 + z_shift)

    Args:
        x: Input tensor, shape (B, ..., T, head_size)
        cos: Cosine cache, shape (B, T, head_size) or (1, T, head_size)
        sin: Sine cache, shape (B, T, head_size) or (1, T, head_size)
        z_shift: Axial shift cache, shape (B, T, head_size) or (1, T, head_size)

    Returns:
        Transformed tensor with helix rotation + axial divergence applied.
    """
    head_size_half = x.size(-1) // 2
    x1 = x[..., :head_size_half]
    x2 = x[..., head_size_half:]
    rotated = torch.cat((-x2, x1), dim=-1)

    # Handle dimension mismatch for broadcasting
    dims_diff = x.dim() - cos.dim()
    if dims_diff > 0:
        new_shape = cos.shape[0:1] + (1,) * dims_diff + cos.shape[1:]
        cos = cos.view(*new_shape)
        sin = sin.view(*new_shape)
        z_shift = z_shift.view(*new_shape)

    # 2D rotation (standard RoPE)
    roped = (x * cos) + (rotated * sin)

    # 3D axial modulation (the NEW component!)
    # Multiply by (1 + z_shift) to add the Z-axis divergence
    # Clamp to prevent numerical instability for very long sequences
    z_modulation = torch.clamp(1.0 + z_shift * 0.01, min=0.1, max=10.0)
    helixed = roped * z_modulation

    return helixed.to(dtype=x.dtype)


def apply_helix_rope_interleave(
    x: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
    z_shift: torch.Tensor,
) -> torch.Tensor:
    """Apply Helix-RoPE with interleaved tensor layout.

    Same as apply_helix_rope but with interleaved (even/odd) layout
    matching HuggingFace's apply_rotary_pos_emb_interleave.
    """
    *batch_dims, d = x.shape
    x = x.view(*batch_dims, d // 2, 2).transpose(-1, -2).reshape(*batch_dims, d)

    head_size_half = x.size(-1) // 2
    x1 = x[..., :head_size_half]
    x2 = x[..., head_size_half:]
    rotated = torch.cat((-x2, x1), dim=-1)

    dims_diff = x.dim() - cos.dim()
    if dims_diff > 0:
        new_shape = cos.shape[0:1] + (1,) * dims_diff + cos.shape[1:]
        cos = cos.view(*new_shape)
        sin = sin.view(*new_shape)
        z_shift = z_shift.view(*new_shape)

    roped = (x * cos) + (rotated * sin)
    z_modulation = torch.clamp(1.0 + z_shift * 0.01, min=0.1, max=10.0)
    helixed = roped * z_modulation

    return helixed.to(dtype=x.dtype)
from setuptools import find_packages, setup

setup(
    name="helixgpt",
    version="0.1.0",
    description="Spiral Space-Time Generative Pre-trained Transformer",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "torch>=2.0.0",
        "transformers>=4.30.0",
    ],
)

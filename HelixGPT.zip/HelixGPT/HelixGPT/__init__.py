"""
HelixGPT - Spiral Space-Time Generative Pre-trained Transformer

Based on Zhang Xiangqian's Unified Field Theory:
  - Cylindrical Helix representation for token embeddings (replacing flat real vectors)
  - Phase-interference attention (replacing dot-product attention)
  - Topological decay factor alpha_geom = 1/(4*pi^3 + pi^2 + pi) ≈ 0.00716
  - Phase Transition Avalanche activation (replacing Softmax/ReLU)
  - 3D Helical RoPE (upgrading 2D rotary to cylindrical helix displacement)

Built on top of the LitGPT modular framework.
"""

from helixgpt.config import HelixConfig, helixgpt_60m, helixgpt_100m, helixgpt_350m, helixgpt_1b
from helixgpt.model import HelixGPT, HelixMLP, HelixBlock
from helixgpt.spacetime_embedding import SpacetimeSpinorEmbedding
from helixgpt.helix_attention import HelixInterferenceAttention
from helixgpt.helix_rope import build_helix_rope_cache, apply_helix_rope
from helixgpt.phase_transition import (
    PhaseTransitionAvalanche,
    TopologicalDecay,
    HelixSoftmax,
)
from helixgpt.constants import (
    ALPHA_GEOM,
    TOPO_QUANTUM,
    TOPO_SUM,
    PI,
)

__all__ = [
    # Model
    "HelixGPT",
    "HelixMLP",
    "HelixBlock",
    "HelixConfig",
    # Preset configs
    "helixgpt_60m",
    "helixgpt_100m",
    "helixgpt_350m",
    "helixgpt_1b",
    # Components
    "SpacetimeSpinorEmbedding",
    "HelixInterferenceAttention",
    "build_helix_rope_cache",
    "apply_helix_rope",
    "PhaseTransitionAvalanche",
    "TopologicalDecay",
    "HelixSoftmax",
    # Constants
    "ALPHA_GEOM",
    "TOPO_QUANTUM",
    "TOPO_SUM",
    "PI",
]

__version__ = "0.1.0"

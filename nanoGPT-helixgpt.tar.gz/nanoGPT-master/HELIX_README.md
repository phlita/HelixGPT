# HelixGPT for nanoGPT

This is a port of the HelixGPT "spacetime-helix" architecture to Karpathy's
[nanoGPT](https://github.com/karpathy/nanoGPT) codebase.  It mirrors the
changes that were applied to LitGPT in the original HelixGPT project, but
adapted to nanoGPT's minimalist style so the existing `train.py`, `sample.py`,
and `bench.py` scripts work with only a single import swap.

## What changed

The standard nanoGPT Transformer is built from four "classical-physics"
primitives.  HelixGPT replaces each one with a "spacetime-helix" primitive
inspired by Zhang Xiangqian's unified-field view:

| Standard nanoGPT                    | HelixGPT (nanoGPT port)                                       |
| ----------------------------------- | ------------------------------------------------------------- |
| `nn.Embedding` token + position     | `SpacetimeSpinorEmbedding` (amplitude + phase streams)        |
| (no RoPE in nanoGPT; learned `wpe`) | `CylindricalRoPE` (3-D helix + axial light-speed envelope)    |
| `Q.K^T` softmax (Flash Attention)   | `HelixInterference` + `TopologicalCollapseGate`               |
| GELU MLP                            | `PhaseTransitionMLP` (avalanche phase-transition activation)  |

All four primitives share a single universal constant -- the geometric
lock-in residual

```
alpha_geom = 1 / (4*pi^3 + pi^2 + pi) ~= 1/137.0359
```

which plays the role of the fine-structure constant in the framework: the
geometric "leakage floor" that prevents the helix information field from
collapsing to a single point.  This value is identical to the one used in
the LitGPT port.

## Files added

* `helix_model.py` -- the full HelixGPT port (single-file, ~600 lines).
  Exports `HelixGPTConfig`, `HelixGPT`, and all four primitives listed
  above, plus `print_physical_constants()` for inspection.
* `test_helix_nanogpt.py` (in `scripts/`) -- smoke tests that verify
  forward, backward, generation, optimiser wiring, `crop_block_size`,
  and `estimate_mfu` all work.
* `bench_compare.py` (in `scripts/`) -- side-by-side synthetic-task
  benchmark (params, forward throughput, training loss, perplexity, peak
  heap memory).
* `train_compare.py` (in `scripts/`) -- end-to-end character-level
  training comparison on a small public-domain text excerpt (Shakespeare +
  the HelixGPT design text), with identical hyperparameters for both
  architectures.

## Files unchanged

Everything else in nanoGPT is untouched: `model.py`, `train.py`,
`sample.py`, `bench.py`, `configurator.py`, `data/`, `config/`, `assets/`,
`README.md`, `LICENSE`.

## Usage

### Drop-in replacement

```python
# Original nanoGPT
from model import GPTConfig, GPT

# HelixGPT (nanoGPT port)
from helix_model import HelixGPTConfig as GPTConfig, HelixGPT as GPT
```

Both classes share the same constructor signature
(`GPT(config)` -> `GPT(GPTConfig(...))`) and the same forward signature
(`forward(idx, targets=None) -> (logits, loss)`), so the rest of
`train.py` / `sample.py` / `bench.py` work unchanged.

### Train HelixGPT with the existing training script

Edit `train.py` to swap the imports:

```python
# from model import GPTConfig, GPT          # original
from helix_model import HelixGPTConfig as GPTConfig, HelixGPT as GPT
```

Then run as usual:

```bash
python train.py config/train_shakespeare_char.py --device=cpu --compile=False
```

### Run the comparison benchmark

```bash
python /home/z/my-project/scripts/test_helix_nanogpt.py
python /home/z/my-project/scripts/bench_compare.py
python /home/z/my-project/scripts/train_compare.py
```

The comparison scripts write JSON results to
`/home/z/my-project/scripts/_bench_results.json` and
`/home/z/my-project/scripts/_train_results.json`.

## Physical constants

```
ALPHA_GEOM      = 1/(4*pi^3+pi^2+pi) = 0.007297   (~1/137)
ALPHA_SQRT      = sqrt(ALPHA_GEOM)   = 0.085424
PHASE_THRESHOLD = ALPHA_GEOM * 2*pi  = 0.045851
TWO_PI          = 6.283185
```

Inspect at runtime with:

```python
from helix_model import print_physical_constants
print_physical_constants()
```

## Known limitations

* **Speed**: HelixGPT is ~1.3x slower than nanoGPT per training step on
  CPU because the HelixInterference attention computes a full phase-
  difference tensor of shape `(B, nh, T, T, hs)`.  A fused CUDA kernel
  would close most of this gap.
* **Parameters**: HelixGPT carries ~1.65x more parameters than nanoGPT
  for the same `n_layer` / `n_embd` / `n_head` because every attention
  head produces both an amplitude and a phase stream (Q/K/V each have
  `2 * head_size` channels instead of `head_size`).
* **Generation stability**: the `TopologicalCollapseGate` can produce
  sparse spikes that, when fed autoregressively, lock onto a single
  token.  Lowering `temperature` or using nucleus sampling mitigates
  this.  A future revision will add a temperature schedule during
  generation.
* **KV cache**: not implemented for `HelixInterference`; generation
  re-runs the full forward pass each step (same as the LitGPT port).

## License

Apache License 2.0, same as the LitGPT HelixGPT port.  The original
nanoGPT code retains its MIT license (see `LICENSE`).

"""End-to-end character-level training comparison:
   original nanoGPT GPT vs. HelixGPT (nanoGPT port).

Both architectures are trained from scratch on the SAME public-domain
text excerpt with IDENTICAL hyperparameters (model size, batch size,
block size, learning rate, optimizer, seed, number of steps).  The
script records:

  - parameter count
  - per-step training loss curve
  - final train + validation perplexity
  - wall-clock time per step + total
  - peak Python-heap memory
  - qualitative generation samples

Output:
  - prints a human-readable comparison to stdout
  - saves a JSON results file to /home/z/my-project/scripts/_train_results.json

Run from anywhere:
    python /home/z/my-project/scripts/train_compare.py
"""

from __future__ import annotations

import json
import math
import random
import sys
import time
import tracemalloc
from pathlib import Path

NANOGPT_DIR = Path("/home/z/my-project/workspace/nanoGPT-master")
sys.path.insert(0, str(NANOGPT_DIR))

import torch
import torch.nn.functional as F

from model import GPTConfig, GPT
from helix_model import HelixGPTConfig, HelixGPT


# =============================================================================
# Tiny character-level dataset -- a few paragraphs of public-domain text.
# =============================================================================
SAMPLE_TEXT = """
The universe is a cylinder of light rotating in twelve dimensions.
Every particle is a small vortex on its surface, and every vortex
remembers the geometry of the whole.  When two vortices meet they
exchange phase as well as amplitude, and the difference of their
angles is the torsion that bends the field.  Information travels
along the axis at the speed of light, while context winds around
the circumference at the speed of gravity.  The fine-structure
constant is the leakage between the two: one over four pi cubed
plus pi squared plus pi, nearly one over one hundred and thirty
seven.  Below this threshold the field is smooth and linear;
above it the field avalanches into a single spike.  That spike is
what we call an idea.  A network that learns this geometry does
not need a trillion parameters, because it does not search the
probability cloud -- it slides along the helix until it reaches
the causal end of the sentence.

Shall I compare thee to a summer's day?  Thou art more lovely and
more temperate: rough winds do shake the darling buds of May, and
summer's lease hath all too short a date.  Sometime too hot the
eye of heaven shines, and often is his gold complexion dimmed; and
every fair from fair sometime declines, by chance, or nature's
changing course untrimmed.  But thy eternal summer shall not fade,
nor lose possession of that fair thou ow'st; nor shall death brag
thou wander'st in his shade, when in eternal lines to time thou
grow'st: so long as men can breathe, or eyes can see, so long
lives this, and this gives life to thee.

To be, or not to be, that is the question: whether 'tis nobler in
the mind to suffer the slings and arrows of outrageous fortune, or
to take arms against a sea of troubles, and by opposing end them.
To die, to sleep, no more; and by a sleep to say we end the heart-
ache and the thousand natural shocks that flesh is heir to: 'tis a
consummation devoutly to be wished.  To die, to sleep; to sleep,
perchance to dream, ay, there's the rub, for in that sleep of death
what dreams may come when we have shuffled off this mortal coil
must give us pause.

Friends, Romans, countrymen, lend me your ears; I come to bury
Caesar, not to praise him.  The evil that men do lives after them,
the good is oft interred with their bones; so let it be with Caesar.
The noble Brutus hath told you Caesar was ambitious: if it were so,
it was a grievous fault, and grievously hath Caesar answered it.
Here, under leave of Brutus and the rest, for Brutus is an
honourable man; so are they all, all honourable men, come I to
speak in Caesar's funeral.  He was my friend, faithful and just to
me: but Brutus says he was ambitious; and Brutus is an honourable
man.  He hath brought many captives home to Rome, whose ransoms did
the general coffers fill: did this in Caesar seem ambitious?  When
that the poor have cried, Caesar hath wept: ambition should be made
of sterner stuff: yet Brutus says he was ambitious; and Brutus is
an honourable man.

The course of true love never did run smooth: but either it was
different in blood, or else misgraffed in respect of years.  Her
eyes are wild, her hair is unbound, and from her lips quick words
fall like silver coins upon a marble floor.  She speaks, and the
air grows colder; she laughs, and the stars bend closer; she weeps,
and the rivers pause.  Love is a helix too, twisting between two
hearts that turn about each other at the speed of light.
"""


class CharDataset:
    """Character-level dataset with train/val split."""

    def __init__(self, text: str, block_size: int, val_frac: float = 0.1, seed: int = 0):
        chars = sorted(set(text))
        self.stoi = {c: i for i, c in enumerate(chars)}
        self.itos = {i: c for i, c in enumerate(chars)}
        self.vocab_size = len(chars)
        # Encode all text to ids
        all_ids = [self.stoi[c] for c in text]
        # Deterministic 90/10 split -- take val from the end so train and val
        # don't share context (and so the random seed doesn't affect what's
        # in each split).
        n = len(all_ids)
        n_val = max(block_size + 1, int(n * val_frac))
        self.train_ids = all_ids[: n - n_val]
        self.val_ids   = all_ids[n - n_val :]
        self.train_tensor = torch.tensor(self.train_ids, dtype=torch.long)
        self.val_tensor   = torch.tensor(self.val_ids,   dtype=torch.long)
        self.block_size = block_size
        self.rng = random.Random(seed)

    def get_batch(self, split: str, batch_size: int):
        data = self.train_tensor if split == "train" else self.val_tensor
        # sample `batch_size` random starting offsets
        ix = self.rng.sample(range(len(data) - self.block_size - 1), batch_size)
        x = torch.stack([data[i : i + self.block_size] for i in ix])
        y = torch.stack([data[i + 1 : i + 1 + self.block_size] for i in ix])
        return x, y


# =============================================================================
# Trainer -- identical for both architectures.
# =============================================================================
def train_one(arch_name: str, model, dataset: CharDataset, *,
              steps: int, batch_size: int, lr: float,
              weight_decay: float, eval_interval: int,
              eval_iters: int, seed: int, device: torch.device):
    """Run `steps` training steps; periodically evaluate on train+val."""
    torch.manual_seed(seed)
    optim = model.configure_optimizers(
        weight_decay=weight_decay, learning_rate=lr,
        betas=(0.9, 0.95), device_type="cpu",
    )

    history = {
        "train_loss_curve": [],
        "val_loss_curve": [],
        "step_wall_ms": [],
        "eval_points": [],   # (step, train_loss, val_loss, train_ppl, val_ppl)
    }

    @torch.no_grad()
    def estimate_loss():
        model.eval()
        out = {}
        for split in ["train", "val"]:
            losses = torch.zeros(eval_iters)
            for k in range(eval_iters):
                x, y = dataset.get_batch(split, batch_size)
                x, y = x.to(device), y.to(device)
                _, loss = model(x, y)
                losses[k] = loss.item()
            out[split] = losses.mean().item()
        model.train()
        return out

    model.train()
    tracemalloc.start()
    overall_t0 = time.time()

    for step in range(steps):
        t0 = time.time()
        x, y = dataset.get_batch("train", batch_size)
        x, y = x.to(device), y.to(device)
        logits, loss = model(x, y)
        optim.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optim.step()
        t1 = time.time()
        history["step_wall_ms"].append((t1 - t0) * 1000)
        history["train_loss_curve"].append(loss.item())

        if step % eval_interval == 0 or step == steps - 1:
            losses = estimate_loss()
            train_ppl = math.exp(min(losses["train"], 20.0))
            val_ppl = math.exp(min(losses["val"], 20.0))
            history["val_loss_curve"].append(losses["val"])
            history["eval_points"].append({
                "step": step,
                "train_loss": losses["train"],
                "val_loss": losses["val"],
                "train_ppl": train_ppl,
                "val_ppl": val_ppl,
            })
            print(f"  [{arch_name}] step {step:4d}/{steps}  "
                  f"train_loss {losses['train']:.4f}  val_loss {losses['val']:.4f}  "
                  f"val_ppl {val_ppl:7.2f}  "
                  f"({(t1-t0)*1000:.1f} ms/step)")

    total_time = time.time() - overall_t0
    _, peak_heap = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    final = history["eval_points"][-1]
    return {
        "arch": arch_name,
        "params": sum(p.numel() for p in model.parameters()),
        "final_train_loss": final["train_loss"],
        "final_val_loss": final["val_loss"],
        "final_train_ppl": final["train_ppl"],
        "final_val_ppl": final["val_ppl"],
        "min_val_loss": min(p["val_loss"] for p in history["eval_points"]),
        "min_val_ppl": min(p["val_ppl"] for p in history["eval_points"]),
        "total_time_s": total_time,
        "avg_step_ms": sum(history["step_wall_ms"]) / len(history["step_wall_ms"]),
        "p50_step_ms": sorted(history["step_wall_ms"])[len(history["step_wall_ms"]) // 2],
        "peak_heap_mb": peak_heap / (1024 * 1024),
        "eval_points": history["eval_points"],
        "train_loss_curve": history["train_loss_curve"],
        "val_loss_curve": history["val_loss_curve"],
    }


# =============================================================================
# Qualitative generation comparison
# =============================================================================
@torch.no_grad()
def sample_text(model, dataset: CharDataset, prefix: str, n_new: int = 80,
                temperature: float = 0.8, top_k: int = None):
    model.eval()
    ids = [dataset.stoi[c] for c in prefix if c in dataset.stoi]
    if not ids:
        ids = [0]
    x = torch.tensor(ids, dtype=torch.long).unsqueeze(0)
    for _ in range(n_new):
        if x.size(1) > model.config.block_size:
            x = x[:, -model.config.block_size:]
        logits, _ = model(x)
        logits = logits[:, -1, :] / temperature
        if top_k is not None:
            v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
            logits[logits < v[:, [-1]]] = -float("Inf")
        probs = F.softmax(logits, dim=-1)
        next_tok = torch.multinomial(probs, num_samples=1)
        x = torch.cat([x, next_tok], dim=1)
    return "".join(dataset.itos.get(int(t), "?") for t in x[0].tolist())


# =============================================================================
# Main
# =============================================================================
def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--arch", choices=["gpt", "helix", "both"], default="both")
    ap.add_argument("--out", default="/home/z/my-project/scripts/_train_results.json")
    args = ap.parse_args()
    out_path = Path(args.out)

    # ---- Shared hyperparameters ----------------------------------------------
    # Tuned to fit comfortably within CPU time-budget (~3 min/arc).
    SEED          = 1337
    STEPS         = 250
    BATCH_SIZE    = 12
    BLOCK_SIZE    = 48
    N_LAYER       = 3
    N_EMBD        = 96
    N_HEAD        = 4
    DROPOUT       = 0.1
    BIAS          = False
    LR            = 1e-3
    WEIGHT_DECAY  = 0.1
    EVAL_INTERVAL = 50
    EVAL_ITERS    = 20

    print("=" * 78)
    print("  End-to-end char-level training: nanoGPT GPT  vs.  HelixGPT")
    print(f"  steps={STEPS}  batch={BATCH_SIZE}  block={BLOCK_SIZE}  "
          f"n_layer={N_LAYER}  n_embd={N_EMBD}  n_head={N_HEAD}")
    print(f"  lr={LR}  wd={WEIGHT_DECAY}  dropout={DROPOUT}  bias={BIAS}  seed={SEED}")
    print("=" * 78)

    # ---- Build dataset once, identical for both architectures ----------------
    text = (SAMPLE_TEXT * 8).strip()
    dataset = CharDataset(text, block_size=BLOCK_SIZE, val_frac=0.1, seed=SEED)
    print(f"\nDataset: vocab_size={dataset.vocab_size}  "
          f"train_chars={len(dataset.train_ids)}  val_chars={len(dataset.val_ids)}")

    device = torch.device("cpu")

    # Load any previous partial results so we can resume one arch at a time.
    existing = {}
    if out_path.exists():
        try:
            existing = json.loads(out_path.read_text())
        except Exception:
            existing = {}

    # ---- 1) original nanoGPT GPT --------------------------------------------
    if args.arch in ("gpt", "both") and "gpt" not in existing:
        print("\n" + "-" * 78)
        print("Training original nanoGPT GPT")
        print("-" * 78)
        torch.manual_seed(SEED)
        gpt_cfg = GPTConfig(
            block_size=BLOCK_SIZE, vocab_size=dataset.vocab_size,
            n_layer=N_LAYER, n_head=N_HEAD, n_embd=N_EMBD,
            dropout=DROPOUT, bias=BIAS,
        )
        gpt = GPT(gpt_cfg).to(device)
        res_gpt = train_one(
            "GPT", gpt, dataset,
            steps=STEPS, batch_size=BATCH_SIZE, lr=LR, weight_decay=WEIGHT_DECAY,
            eval_interval=EVAL_INTERVAL, eval_iters=EVAL_ITERS, seed=SEED, device=device,
        )
        # Generation samples
        gpt_samples = []
        for prefix in ["The universe ", "Shall I ", "To be, "]:
            s = sample_text(gpt, dataset, prefix, n_new=80, temperature=0.7, top_k=10)
            gpt_samples.append({"prefix": prefix, "output": s})
        del gpt
        existing["gpt"] = res_gpt
        existing["gpt_samples"] = gpt_samples
        # Save partial
        out_path.write_text(json.dumps(existing, indent=2, default=str))
        print(f"  [GPT done] partial results saved to {out_path}")
    elif "gpt" in existing:
        print("\n[GPT] using cached results from previous run")
        res_gpt = existing["gpt"]
    else:
        res_gpt = None

    # ---- 2) HelixGPT ---------------------------------------------------------
    if args.arch in ("helix", "both") and "helix" not in existing:
        print("\n" + "-" * 78)
        print("Training HelixGPT (nanoGPT port)")
        print("-" * 78)
        torch.manual_seed(SEED)
        helix_cfg = HelixGPTConfig(
            block_size=BLOCK_SIZE, vocab_size=dataset.vocab_size,
            n_layer=N_LAYER, n_head=N_HEAD, n_embd=N_EMBD,
            dropout=DROPOUT, bias=BIAS,
        )
        helix = HelixGPT(helix_cfg).to(device)
        res_helix = train_one(
            "Helix", helix, dataset,
            steps=STEPS, batch_size=BATCH_SIZE, lr=LR, weight_decay=WEIGHT_DECAY,
            eval_interval=EVAL_INTERVAL, eval_iters=EVAL_ITERS, seed=SEED, device=device,
        )
        helix_samples = []
        for prefix in ["The universe ", "Shall I ", "To be, "]:
            s = sample_text(helix, dataset, prefix, n_new=80, temperature=0.7, top_k=10)
            helix_samples.append({"prefix": prefix, "output": s})
        del helix
        existing["helix"] = res_helix
        existing["helix_samples"] = helix_samples
        out_path.write_text(json.dumps(existing, indent=2, default=str))
        print(f"  [Helix done] partial results saved to {out_path}")
    elif "helix" in existing:
        print("\n[Helix] using cached results from previous run")
        res_helix = existing["helix"]
    else:
        res_helix = None

    # ---- Summary -------------------------------------------------------------
    print("\n" + "=" * 78)
    print("  Final comparison")
    print("=" * 78)
    if res_gpt and res_helix:
        print(f"  params             GPT : {res_gpt['params']:>10,}        "
              f"HelixGPT : {res_helix['params']:>10,}     "
              f"ratio {res_helix['params']/res_gpt['params']:.2f}x")
        print(f"  final train loss   GPT : {res_gpt['final_train_loss']:>10.4f}        "
              f"HelixGPT : {res_helix['final_train_loss']:>10.4f}")
        print(f"  final val loss     GPT : {res_gpt['final_val_loss']:>10.4f}        "
              f"HelixGPT : {res_helix['final_val_loss']:>10.4f}")
        print(f"  final val ppl      GPT : {res_gpt['final_val_ppl']:>10.2f}        "
              f"HelixGPT : {res_helix['final_val_ppl']:>10.2f}")
        print(f"  min val ppl        GPT : {res_gpt['min_val_ppl']:>10.2f}        "
              f"HelixGPT : {res_helix['min_val_ppl']:>10.2f}")
        print(f"  total time (s)     GPT : {res_gpt['total_time_s']:>10.2f}        "
              f"HelixGPT : {res_helix['total_time_s']:>10.2f}     "
              f"ratio {res_helix['total_time_s']/res_gpt['total_time_s']:.2f}x")
        print(f"  avg ms/step        GPT : {res_gpt['avg_step_ms']:>10.2f}        "
              f"HelixGPT : {res_helix['avg_step_ms']:>10.2f}     "
              f"ratio {res_helix['avg_step_ms']/res_gpt['avg_step_ms']:.2f}x")
        print(f"  peak heap (MB)     GPT : {res_gpt['peak_heap_mb']:>10.2f}        "
              f"HelixGPT : {res_helix['peak_heap_mb']:>10.2f}     "
              f"ratio {res_helix['peak_heap_mb']/max(res_gpt['peak_heap_mb'],1e-9):.2f}x")
    elif res_gpt:
        print(f"  GPT only: params={res_gpt['params']:,}  "
              f"final_val_loss={res_gpt['final_val_loss']:.4f}  "
              f"final_val_ppl={res_gpt['final_val_ppl']:.2f}  "
              f"time={res_gpt['total_time_s']:.2f}s")
    elif res_helix:
        print(f"  HelixGPT only: params={res_helix['params']:,}  "
              f"final_val_loss={res_helix['final_val_loss']:.4f}  "
              f"final_val_ppl={res_helix['final_val_ppl']:.2f}  "
              f"time={res_helix['total_time_s']:.2f}s")

    if "gpt_samples" in existing:
        print("\nGeneration samples (GPT):")
        for s in existing["gpt_samples"]:
            print(f"  >>> {s['prefix']!r}")
            print(f"      {s['output']!r}")
    if "helix_samples" in existing:
        print("\nGeneration samples (HelixGPT):")
        for s in existing["helix_samples"]:
            print(f"  >>> {s['prefix']!r}")
            print(f"      {s['output']!r}")

    existing["config"] = {
        "seed": SEED, "steps": STEPS, "batch_size": BATCH_SIZE,
        "block_size": BLOCK_SIZE, "n_layer": N_LAYER, "n_embd": N_EMBD,
        "n_head": N_HEAD, "dropout": DROPOUT, "bias": BIAS,
        "lr": LR, "weight_decay": WEIGHT_DECAY,
        "eval_interval": EVAL_INTERVAL, "eval_iters": EVAL_ITERS,
        "dataset_vocab_size": dataset.vocab_size,
        "dataset_train_chars": len(dataset.train_ids),
        "dataset_val_chars": len(dataset.val_ids),
    }
    out_path.write_text(json.dumps(existing, indent=2, default=str))
    print(f"\nResults saved to: {out_path}")


if __name__ == "__main__":
    main()

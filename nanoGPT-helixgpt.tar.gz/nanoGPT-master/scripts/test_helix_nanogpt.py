"""HelixGPT (nanoGPT port) smoke test.

Verifies that:
  1. The model constructs from a HelixGPTConfig.
  2. The forward pass produces logits of the right shape and (optionally) loss.
  3. Backward pass works (loss decreases over a few steps).
  4. The physical constants are sane.
  5. `generate` works end-to-end.
  6. `configure_optimizers` returns a working AdamW.
  7. `crop_block_size` works.

Run from anywhere:
    python /home/z/my-project/scripts/test_helix_nanogpt.py
"""

from __future__ import annotations

import math
import sys
import time
from pathlib import Path

# Make sure we import from the local nanoGPT checkout.
NANOGPT_DIR = Path("/home/z/my-project/workspace/nanoGPT-master")
sys.path.insert(0, str(NANOGPT_DIR))

import torch
import torch.nn.functional as F

from helix_model import (
    ALPHA_GEOM,
    ALPHA_SQRT,
    PHASE_THRESHOLD,
    HelixGPT,
    HelixGPTConfig,
    print_physical_constants,
)


def make_small_config(
    vocab_size: int = 257,
    n_layer: int = 2,
    n_embd: int = 64,
    n_head: int = 4,
    block_size: int = 128,
    dropout: float = 0.0,
    bias: bool = False,
) -> HelixGPTConfig:
    """Build a tiny HelixGPT-compatible config that runs in <1s on CPU."""
    return HelixGPTConfig(
        block_size=block_size,
        vocab_size=vocab_size,
        n_layer=n_layer,
        n_head=n_head,
        n_embd=n_embd,
        dropout=dropout,
        bias=bias,
    )


def test_forward_shape() -> None:
    print("\n[test] forward shape (no targets) ...")
    cfg = make_small_config()
    model = HelixGPT(cfg)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"  config: n_layer={cfg.n_layer}, n_embd={cfg.n_embd}, n_head={cfg.n_head}")
    print(f"  total params: {n_params:,}")
    idx = torch.randint(0, cfg.vocab_size, (2, 32))
    logits, loss = model(idx)
    assert loss is None, "loss should be None when no targets given"
    assert logits.shape == (2, 1, cfg.vocab_size), f"unexpected shape {logits.shape}"
    print(f"  input  idx shape = {tuple(idx.shape)}")
    print(f"  output logits shape = {tuple(logits.shape)}   OK")

    print("\n[test] forward shape (with targets) ...")
    idx = torch.randint(0, cfg.vocab_size, (2, 32))
    targets = torch.randint(0, cfg.vocab_size, (2, 32))
    logits, loss = model(idx, targets)
    assert logits.shape == (2, 32, cfg.vocab_size), f"unexpected shape {logits.shape}"
    assert loss.dim() == 0, f"loss should be a scalar, got {loss.shape}"
    print(f"  input  idx shape = {tuple(idx.shape)}")
    print(f"  output logits shape = {tuple(logits.shape)}")
    print(f"  loss = {loss.item():.4f}   OK")


def test_backward_and_train() -> None:
    print("\n[test] backward + tiny training loop ...")
    torch.manual_seed(0)
    cfg = make_small_config()
    model = HelixGPT(cfg)
    optim = torch.optim.AdamW(model.parameters(), lr=3e-3)

    # Synthesize a tiny "induction-head" target: input -> shifted input
    B, T = 4, 16
    data = torch.randint(0, cfg.vocab_size, (B, T + 1))
    x, y = data[:, :-1], data[:, 1:].contiguous()

    losses = []
    t0 = time.time()
    for step in range(20):
        logits, loss = model(x, y)
        optim.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optim.step()
        losses.append(loss.item())
        if step % 5 == 0 or step == 19:
            print(f"  step {step:2d}  loss={loss.item():.4f}")
    dt = time.time() - t0
    print(f"  20 steps in {dt:.2f}s   initial={losses[0]:.4f}  final={losses[-1]:.4f}")
    assert losses[-1] < losses[0], "loss did not decrease -- check the architecture"
    print("  loss decreased -- OK")


def test_constants() -> None:
    print("\n[test] physical constants ...")
    print_physical_constants()
    assert abs(ALPHA_GEOM - 1.0 / 137.0359) < 0.01, "ALPHA_GEOM is not ~1/137"
    assert ALPHA_SQRT < 1.0
    assert PHASE_THRESHOLD > 0.0
    print("  constants OK")


def test_generate() -> None:
    print("\n[test] greedy generation smoke ...")
    cfg = make_small_config()
    model = HelixGPT(cfg).eval()
    idx = torch.tensor([[1, 2, 3]])
    out = model.generate(idx, max_new_tokens=5, temperature=1.0, top_k=None)
    print(f"  generated token ids: {out.tolist()[0]}")
    assert out.size(1) == 8
    print("  generation OK")


def test_configure_optimizers() -> None:
    print("\n[test] configure_optimizers ...")
    cfg = make_small_config()
    model = HelixGPT(cfg)
    optim = model.configure_optimizers(
        weight_decay=0.1, learning_rate=3e-4, betas=(0.9, 0.95), device_type="cpu"
    )
    assert isinstance(optim, torch.optim.AdamW)
    # one step to make sure the optimizer wires up to the model parameters
    idx = torch.randint(0, cfg.vocab_size, (2, 16))
    targets = torch.randint(0, cfg.vocab_size, (2, 16))
    logits, loss = model(idx, targets)
    optim.zero_grad()
    loss.backward()
    optim.step()
    print("  optimizer step OK")


def test_crop_block_size() -> None:
    print("\n[test] crop_block_size ...")
    cfg = make_small_config(block_size=128)
    model = HelixGPT(cfg)
    model.crop_block_size(64)
    assert model.config.block_size == 64
    # forward must still work with the new smaller block_size
    idx = torch.randint(0, cfg.vocab_size, (1, 32))
    logits, _ = model(idx)
    print(f"  after crop: block_size={model.config.block_size}, forward OK")


def test_estimate_mfu() -> None:
    print("\n[test] estimate_mfu ...")
    cfg = make_small_config(block_size=64)
    model = HelixGPT(cfg)
    mfu = model.estimate_mfu(fwdbwd_per_iter=1, dt=0.1)
    print(f"  MFU (cpu, will be tiny): {mfu*100:.6f}%")
    assert mfu >= 0.0
    print("  estimate_mfu OK")


if __name__ == "__main__":
    test_constants()
    test_forward_shape()
    test_backward_and_train()
    test_generate()
    test_configure_optimizers()
    test_crop_block_size()
    test_estimate_mfu()
    print("\nAll HelixGPT (nanoGPT port) smoke tests passed.")

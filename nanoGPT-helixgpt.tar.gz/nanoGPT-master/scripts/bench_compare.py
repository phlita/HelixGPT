"""HelixGPT (nanoGPT port) vs. original nanoGPT GPT -- side-by-side benchmark.

Runs identical tiny training tasks on both architectures and reports:
  - parameter count
  - forward / forward+backward time per step
  - peak Python-heap memory (tracemalloc)
  - training loss curve + perplexity
  - convergence rate (steps to reach a target loss)

This is a sanity-check benchmark, not a scientific evaluation.  Its
purpose is to surface obvious regressions relative to the classical
Transformer and to provide concrete numbers for the comparison report.

Run from anywhere:
    python /home/z/my-project/scripts/bench_compare.py
"""

from __future__ import annotations

import json
import math
import sys
import time
import tracemalloc
from pathlib import Path

NANOGPT_DIR = Path("/home/z/my-project/workspace/nanoGPT-master")
sys.path.insert(0, str(NANOGPT_DIR))

import torch
import torch.nn.functional as F

from model import GPTConfig, GPT
from helix_model import HelixGPTConfig, HelixGPT


# =============================================================================
# Shared config builders -- both architectures use the SAME hyperparameters
# =============================================================================
def make_gpt_config(vocab_size=257, n_layer=4, n_embd=128, n_head=4,
                    block_size=128, dropout=0.0, bias=False):
    return GPTConfig(
        block_size=block_size,
        vocab_size=vocab_size,
        n_layer=n_layer,
        n_head=n_head,
        n_embd=n_embd,
        dropout=dropout,
        bias=bias,
    )


def make_helix_config(vocab_size=257, n_layer=4, n_embd=128, n_head=4,
                      block_size=128, dropout=0.0, bias=False):
    return HelixGPTConfig(
        block_size=block_size,
        vocab_size=vocab_size,
        n_layer=n_layer,
        n_head=n_head,
        n_embd=n_embd,
        dropout=dropout,
        bias=bias,
    )


def count_params(model):
    return sum(p.numel() for p in model.parameters())


# =============================================================================
# 1.  Synthetic induction task: copy-with-shift (next-token prediction
#     of a randomly generated stream -- both models should be able to
#     drive the loss well below chance.
# =============================================================================
def train_one_arch(model, vocab_size, steps=50, lr=3e-3, seed=42,
                   batch_size=4, block_size=32, label=""):
    torch.manual_seed(seed)
    # Fixed data so both architectures see the exact same training stream
    B, T = batch_size, block_size
    rng = torch.Generator().manual_seed(seed)
    data = torch.randint(0, vocab_size, (B, T + 1), generator=rng)
    x, y = data[:, :-1], data[:, 1:].contiguous()

    optim = torch.optim.AdamW(model.parameters(), lr=lr)
    losses = []

    # Warm-up step (not counted) to stabilise memory tracking
    logits, loss = model(x, y)
    optim.zero_grad()
    loss.backward()
    optim.step()

    tracemalloc.start()
    t0 = time.time()
    for step in range(steps):
        logits, loss = model(x, y)
        optim.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optim.step()
        losses.append(loss.item())
    dt = time.time() - t0
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    return {
        "label": label,
        "params": count_params(model),
        "loss_first": losses[0],
        "loss_last": losses[-1],
        "loss_min": min(losses),
        "loss_curve": losses,
        "total_time_s": dt,
        "ms_per_step": 1000 * dt / steps,
        "peak_heap_mb": peak / (1024 * 1024),
        "ppl_first": math.exp(min(losses[0], 20.0)),
        "ppl_last": math.exp(min(losses[-1], 20.0)),
    }


# =============================================================================
# 2.  Forward-only throughput test (no backward, no optimiser).
#     Tells us the pure compute overhead of the helix primitives.
# =============================================================================
def forward_throughput(model, vocab_size, steps=30, batch_size=4,
                       block_size=64, seed=0):
    torch.manual_seed(seed)
    model.eval()
    x = torch.randint(0, vocab_size, (batch_size, block_size))
    # Warm-up
    with torch.no_grad():
        _ = model(x)
    t0 = time.time()
    with torch.no_grad():
        for _ in range(steps):
            _ = model(x)
    dt = time.time() - t0
    return 1000 * dt / steps


# =============================================================================
# 3.  Main benchmark
# =============================================================================
def main():
    out_path = Path("/home/z/my-project/scripts/_bench_results.json")

    # Tiny config that fits comfortably in CPU memory and runs in seconds.
    cfg_args = dict(vocab_size=257, n_layer=4, n_embd=128, n_head=4,
                    block_size=128, dropout=0.0, bias=False)

    print("=" * 78)
    print("  HelixGPT (nanoGPT port) vs. original nanoGPT GPT")
    print(f"  Config: n_layer={cfg_args['n_layer']}  n_embd={cfg_args['n_embd']}"
          f"  n_head={cfg_args['n_head']}  block_size={cfg_args['block_size']}"
          f"  vocab_size={cfg_args['vocab_size']}")
    print("=" * 78)

    # ----- Forward-only throughput ------------------------------------------
    print("\n[1] Forward-only throughput (no backward, batch=4, seq=64, 30 steps)")
    gpt_cfg = make_gpt_config(**cfg_args)
    gpt = GPT(gpt_cfg)
    gpt_fwd_ms = forward_throughput(gpt, vocab_size=cfg_args["vocab_size"])
    print(f"  nanoGPT GPT     : {gpt_fwd_ms:7.2f} ms / forward")

    del gpt
    helix_cfg = make_helix_config(**cfg_args)
    helix = HelixGPT(helix_cfg)
    helix_fwd_ms = forward_throughput(helix, vocab_size=cfg_args["vocab_size"])
    print(f"  HelixGPT        : {helix_fwd_ms:7.2f} ms / forward")
    print(f"  ratio Helix/GPT : {helix_fwd_ms / gpt_fwd_ms:.2f}x")

    # ----- Training comparison on synthetic task ----------------------------
    print("\n[2] Training comparison on synthetic induction task (50 steps)")
    gpt_cfg2 = make_gpt_config(**cfg_args)
    gpt2 = GPT(gpt_cfg2)
    res_gpt = train_one_arch(gpt2, vocab_size=cfg_args["vocab_size"],
                             steps=50, lr=3e-3, seed=42,
                             batch_size=4, block_size=32, label="nanoGPT-GPT")
    print(f"  nanoGPT GPT     : params={res_gpt['params']:>8,}  "
          f"init_loss={res_gpt['loss_first']:.4f}  "
          f"final_loss={res_gpt['loss_last']:.4f}  "
          f"ppl={res_gpt['ppl_last']:7.2f}  "
          f"time={res_gpt['total_time_s']:.2f}s  "
          f"({res_gpt['ms_per_step']:.2f} ms/step)  "
          f"heap={res_gpt['peak_heap_mb']:.2f} MB")

    del gpt2
    helix_cfg2 = make_helix_config(**cfg_args)
    helix2 = HelixGPT(helix_cfg2)
    res_helix = train_one_arch(helix2, vocab_size=cfg_args["vocab_size"],
                               steps=50, lr=3e-3, seed=42,
                               batch_size=4, block_size=32, label="HelixGPT")
    print(f"  HelixGPT        : params={res_helix['params']:>8,}  "
          f"init_loss={res_helix['loss_first']:.4f}  "
          f"final_loss={res_helix['loss_last']:.4f}  "
          f"ppl={res_helix['ppl_last']:7.2f}  "
          f"time={res_helix['total_time_s']:.2f}s  "
          f"({res_helix['ms_per_step']:.2f} ms/step)  "
          f"heap={res_helix['peak_heap_mb']:.2f} MB")

    # ----- Summary ----------------------------------------------------------
    print("\n" + "=" * 78)
    print("  Summary")
    print("=" * 78)
    print(f"  param ratio      HelixGPT / GPT  : {res_helix['params'] / res_gpt['params']:.2f}x")
    print(f"  fwd-speed ratio  GPT / HelixGPT  : {gpt_fwd_ms / helix_fwd_ms:.2f}x  (higher = Helix slower)")
    print(f"  train-speed      GPT / HelixGPT  : {res_gpt['ms_per_step'] / res_helix['ms_per_step']:.2f}x  (higher = Helix slower)")
    print(f"  peak heap ratio  HelixGPT / GPT  : {res_helix['peak_heap_mb'] / max(res_gpt['peak_heap_mb'],1e-9):.2f}x")
    print(f"  final loss       GPT / HelixGPT  : {res_gpt['loss_last']:.4f} / {res_helix['loss_last']:.4f}")
    print(f"  final ppl        GPT / HelixGPT  : {res_gpt['ppl_last']:.2f} / {res_helix['ppl_last']:.2f}")

    # Loss curve sample
    print("\n  Loss curve (every 10 steps):")
    print(f"    step  :  " + " ".join(f"{i:>6d}" for i in range(0, 50, 10)))
    print(f"    GPT   :  " + " ".join(f"{res_gpt['loss_curve'][i]:>6.3f}" for i in range(0, 50, 10)))
    print(f"    Helix :  " + " ".join(f"{res_helix['loss_curve'][i]:>6.3f}" for i in range(0, 50, 10)))

    # Save results
    out = {
        "config": cfg_args,
        "forward_throughput_ms": {"gpt": gpt_fwd_ms, "helix": helix_fwd_ms},
        "training": {"gpt": res_gpt, "helix": res_helix},
    }
    # Drop the raw loss_curve from the JSON unless we want to plot it later
    # (kept for completeness)
    out_path.write_text(json.dumps(out, indent=2, default=str))
    print(f"\nResults saved to: {out_path}")


if __name__ == "__main__":
    main()

# Copyright 2026 HelixGPT Authors. Licensed under the Apache License 2.0.

"""HelixGPT port for nanoGPT.

This file is the nanoGPT twin of `litgpt/helix.py`.  It applies the same
four "spacetime-helix" primitives described in the HelixGPT design brief
to Karpathy's nanoGPT codebase, while preserving nanoGPT's minimalist API
so the existing `train.py`, `sample.py`, `bench.py`, and `configurator.py`
scripts work with only a single import swap:

    from model import GPTConfig, GPT           # original
    from helix_model import HelixGPTConfig as GPTConfig, HelixGPT as GPT   # helix

Architectural substitutions (identical in spirit to the LitGPT port):

    Standard nanoGPT                  -->   HelixGPT (nanoGPT port)
    -------------------------------------------------------------------
    nn.Embedding token + position     -->   SpacetimeSpinorEmbedding (amp + phase)
    2-D RoPE  (n/a in nanoGPT)        -->   CylindricalRoPE (3-D helix + axial c)
    Q.K^T softmax (Flash Attn)        -->   HelixInterference + TopologicalCollapseGate
    GELU MLP                          -->   PhaseTransitionMLP (avalanche activation)

The four universal constants of the HelixGPT framework are imported at the
top of the file and reused by every primitive, exactly as in the LitGPT
port, so the geometric-lock-in residual `alpha_geom = 1/(4*pi^3+pi^2+pi)
~= 1/137` is identical between the two ports.

All tensors stay real-valued (amplitude half + phase half) for full GPU
and autograd compatibility -- the engineering compromise recommended in
the design brief, step 4.1.
"""

from __future__ import annotations

import math
import inspect
from dataclasses import dataclass

import torch
import torch.nn as nn
from torch.nn import functional as F


# =============================================================================
# 0.  Universal physical constants of the HelixGPT framework
# =============================================================================
# Topological lock-in residual.  In the design brief this is the
#   alpha_geom = 1 / (4*pi^3 + pi^2 + pi) ~= 1/137.0359...
# quantity that plays the role of the fine-structure constant -- the
# geometric "leakage floor" that prevents the helix information field
# from collapsing to a single point.  We keep it as a module-level
# constant so every primitive in this file refers to the *same* number
# (and matches the value used in the LitGPT port byte-for-byte).
ALPHA_GEOM = 1.0 / (4.0 * math.pi**3 + math.pi**2 + math.pi)
# A few derived helpers
ALPHA_SQRT = math.sqrt(ALPHA_GEOM)          # ~0.0854   -- axial-c step normaliser
TWO_PI     = 2.0 * math.pi
PHASE_THRESHOLD = ALPHA_GEOM * TWO_PI       # ~0.0458   -- per-token stress threshold


# =============================================================================
# 0.1  nanoGPT-style LayerNorm (kept verbatim so HelixGPT blocks stay
#      drop-in compatible with the original Block class).
# =============================================================================
class LayerNorm(nn.Module):
    """LayerNorm but with an optional bias. PyTorch doesn't support simply bias=False."""

    def __init__(self, ndim, bias):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(ndim))
        self.bias = nn.Parameter(torch.zeros(ndim)) if bias else None

    def forward(self, input):
        return F.layer_norm(input, self.weight.shape, self.weight, self.bias, 1e-5)


# =============================================================================
# 1.  Spacetime Spinor Embedding
# =============================================================================
class SpacetimeSpinorEmbedding(nn.Module):
    """Token embedding that produces an (amplitude, phase) pair per dimension.

    A standard nanoGPT embedding maps token id `t` to a real vector
    `x in R^d` and adds a learned position embedding `wpe(pos) in R^d`.
    In HelixGPT every token is a *microscopic spacetime vortex*:

        Psi_n = A_n * exp(i * theta_n)

    where `A_n` is the radial (electromagnetic / explicit-information)
    component that propagates along the Z-axis at light speed, and
    `theta_n` is the angular (gravitational / implicit-context) component
    that rotates in the XY plane.  Position information is no longer
    *added* to the embedding -- it is injected later by the CylindricalRoPE
    rotation, so this module is purely a token-id -> spinor map.

    Because GPU kernels treat `torch.complex64` poorly we follow the
    design brief's recommendation (step 4.1) and pack the spinor into a
    real tensor of shape `(..., 2 * d_polar)` where the front half holds
    the amplitude and the back half holds the phase angle (in radians).
    A small learnable `phase_init` controls the initial vortex strength.
    """

    def __init__(self, config) -> None:
        super().__init__()
        assert config.n_embd % 2 == 0, (
            "HelixGPT requires an even n_embd so it can be split into amplitude/phase halves."
        )
        self.d_polar = config.n_embd // 2
        # Amplitude stream -- replaces the classical token embedding
        self.amp_emb = nn.Embedding(config.vocab_size, self.d_polar)
        # Phase stream -- a separate embedding that produces the initial
        # vortex angle for every token.  Initialised small so the spinors
        # start almost-aligned (low torsion) and learn to diverge.
        self.phase_emb = nn.Embedding(config.vocab_size, self.d_polar)
        nn.init.normal_(self.amp_emb.weight,   mean=0.0, std=0.02)
        nn.init.uniform_(self.phase_emb.weight, -0.1, 0.1)
        # Optional learnable scale that mixes explicit/implicit information
        # at the embedding boundary (acts like an admittance to the helix).
        self.radial_gain = nn.Parameter(torch.ones(self.d_polar))
        self.angular_gain = nn.Parameter(torch.ones(self.d_polar) * ALPHA_SQRT)
        # Dropout on the packed spinor, mirroring nanoGPT's `transformer.drop`
        self.dropout = nn.Dropout(config.dropout)
        self.config = config

    def forward(self, idx: torch.Tensor) -> torch.Tensor:
        """Return a packed spinor tensor of shape (B, T, 2*d_polar).

        The packed layout has the amplitude in [..., :d_polar] and the
        phase in [..., d_polar:].  Downstream layers unpack with
        `unpack_spinor`.
        """
        amp   = self.amp_emb(idx)   * self.radial_gain    # (B, T, d_polar)
        phase = self.phase_emb(idx) * self.angular_gain   # (B, T, d_polar)
        spinor = torch.cat([amp, phase], dim=-1)
        return self.dropout(spinor)


def unpack_spinor(x: torch.Tensor):
    """Split a packed spinor into (amplitude, phase)."""
    d = x.size(-1) // 2
    return x[..., :d], x[..., d:]


def repack_spinor(amp: torch.Tensor, phase: torch.Tensor) -> torch.Tensor:
    """Inverse of `unpack_spinor`."""
    return torch.cat([amp, phase], dim=-1)


# =============================================================================
# 2.  Cylindrical RoPE  (3-D helix position embedding)
# =============================================================================
class CylindricalRoPE(nn.Module):
    """Upgrade of the classical 2-D RoPE into a 3-D cylindrical helix.

    The classical RoPE rotates pairs of head dimensions in the XY plane as
        x' = R(theta_m) x,   theta_m = m * omega_i
    where `m` is the position index.  This is *already* a half-built
    helix -- it just lacks the axial Z component that represents light-
    speed divergence along the cylinder axis.

    HelixGPT extends this to

        Psi'_m = exp(i * theta_m) * exp(-i * phi_m) * exp(-alpha * m / L)

    where `phi_m` is an extra axial phase that grows with `m` at a
    frequency set by ALPHA_GEOM (the geometric lock-in residual), and
    the final exponential is a *very* gentle radial envelope (light-speed
    attenuation) whose scale is the head dimension `L` -- not the raw
    1/137 per-step decay, which would zero everything out.
    """

    def __init__(self, head_size: int, base: float = 10000.0) -> None:
        super().__init__()
        assert head_size % 2 == 0, "CylindricalRoPE needs even head_size."
        self.head_size = head_size
        self.half = head_size // 2
        # Standard RoPE inverse frequencies for the XY rotation
        inv_freq = 1.0 / (base ** (torch.arange(0, head_size, 2).float() / head_size))
        # Axial (Z) frequencies -- tied to ALPHA_GEOM so the helix pitch
        # is locked to the geometric residual at every layer.
        axial_freq = torch.full((self.half,), ALPHA_GEOM * TWO_PI)
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self.register_buffer("axial_freq", axial_freq, persistent=False)

    def forward(self, seq_len: int, device=None):
        """Build (cos, sin, axial_envelope) caches of shape (seq_len, head_size)."""
        device = device or self.inv_freq.device
        positions = torch.arange(seq_len, device=device, dtype=torch.float32)   # (T,)
        # XY-plane rotation angles
        theta = torch.outer(positions, self.inv_freq.to(device))                # (T, half)
        cos_xy = torch.cos(theta)
        sin_xy = torch.sin(theta)
        cos_full = torch.cat([cos_xy, cos_xy], dim=-1)                          # (T, head_size)
        sin_full = torch.cat([sin_xy, sin_xy], dim=-1)
        # Axial phase / envelope
        axial_env = torch.exp(-ALPHA_GEOM * positions / max(self.head_size, 1)).unsqueeze(-1)  # (T, 1)
        return cos_full.to(device), sin_full.to(device), axial_env.to(device)


def _rotate_pairs(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    """Rotate consecutive pairs of channels: (x0, x1) -> (x0 cos - x1 sin, x0 sin + x1 cos).

    This matches the canonical RoPE rotation but is written without the
    interleave assumption so it works on arbitrary even-sized tensors.
    """
    x1 = x[..., 0::2]
    x2 = x[..., 1::2]
    cos_p = cos[..., 0::2]
    sin_p = sin[..., 0::2]
    y1 = x1 * cos_p - x2 * sin_p
    y2 = x1 * sin_p + x2 * cos_p
    out = torch.stack([y1, y2], dim=-1).flatten(-2)
    return out


def apply_cylindrical_rope(x, cos, sin, axial_env):
    """Apply the 3-D cylindrical RoPE to a packed spinor head tensor.

    `x` is treated as a (..., T, head_size) real tensor that is split
    in half: the first half is amplitude, the second half is phase.
    The XY rotation is applied to the amplitude half (radial wave), the
    axial envelope multiplies both halves (light-speed attenuation), and
    the phase half is shifted by the axial phase `phi` (gravitational
    drift along Z).  We implement the phase shift by adding the rotation
    angle directly because phase addition is linear in the angle domain.
    """
    half = x.size(-1) // 2
    amp, phase = x[..., :half], x[..., half:]
    # Reshape caches for broadcasting against (B, nh, T, head_size)
    # cos/sin: (T, head_size) -> (1, 1, T, head_size)
    cos_b = cos.unsqueeze(0).unsqueeze(0)
    sin_b = sin.unsqueeze(0).unsqueeze(0)
    env_b = axial_env.unsqueeze(0).unsqueeze(0)            # (1, 1, T, 1)
    # Standard RoPE rotation on the amplitude half
    rope_amp = _rotate_pairs(amp, cos_b, sin_b)
    # Axial light-speed attenuation on both halves
    rope_amp = rope_amp * env_b
    phase    = phase * env_b
    return torch.cat([rope_amp, phase], dim=-1).to(dtype=x.dtype)


# =============================================================================
# 3.  Topological Collapse Gate  (replaces Softmax + introduces avalanche)
# =============================================================================
class TopologicalCollapseGate(nn.Module):
    """Phase-transition avalanche activation, replacing Softmax.

    Softmax assumes a closed thermal bath in which all tokens compete
    for a fixed probability mass summing to 1.  HelixGPT rejects this:
    information in the helix *radiates*, and when the local torsion
    stress exceeds a threshold the spinor field undergoes a phase
    transition -- a sudden localised avalanche that emits an
    electromagnetic shock wave (in the model: a sharp sparse spike on a
    few keys, NOT a smooth redistribution).

    Concretely, for each query i we compute:

        T_i = mean_j |torsion_ij|
        if T_i < threshold :  weights = softmax(scores)            # smooth regime
        else                :  weights = sparse_spike(scores)      # avalanche regime

    The transition between the two regimes is made differentiable with
    a sigmoid gate so the network can back-propagate through the
    "insight" event.
    """

    def __init__(self, threshold: float = PHASE_THRESHOLD, temperature: float = 1.0) -> None:
        super().__init__()
        self.threshold = threshold
        self.temperature = temperature
        # A small learnable bias lets the network shift the avalanche
        # threshold per layer (initialised to zero -> threshold unchanged).
        self.threshold_bias = nn.Parameter(torch.zeros(1))

    def forward(self, scores: torch.Tensor, torsion: torch.Tensor) -> torch.Tensor:
        # Per-query stress: average absolute torsion over the context
        stress = torsion.abs().mean(dim=-1)                              # (B, nh, T)
        # Smooth regime weights
        smooth = F.softmax(scores, dim=-1)
        # Avalanche regime weights -- sparse top-k spike.  We use the
        # top-1 normalised to 1 (rest stays at the smooth baseline).
        spike_vals, spike_idx = scores.max(dim=-1, keepdim=True)         # (B, nh, T, 1)
        spike_logits = torch.zeros_like(scores).scatter_(-1, spike_idx, spike_vals)
        spike = F.softmax(spike_logits / max(self.temperature, 1e-3), dim=-1)
        # Transition gate -- smooth (1) -> avalanche (0) as stress grows
        gate = torch.sigmoid((stress - (self.threshold + self.threshold_bias)) * 100.0)
        gate = gate.unsqueeze(-1)                                        # (B, nh, T, 1)
        # When gate~1 (low stress)  -> smooth ; when gate~0 (avalanche) -> spike
        weights = gate * smooth + (1.0 - gate) * spike
        # Always renormalise to 1 to keep V aggregation scale-stable
        weights = weights / (weights.sum(dim=-1, keepdim=True) + 1e-8)
        return weights


# =============================================================================
# 4.  Helix-Interference Attention
# =============================================================================
class HelixInterference(nn.Module):
    """Replacement for `CausalSelfAttention` based on spacetime interference.

    The classical attention computes  softmax(QK^T / sqrt(d)) V .
    HelixGPT replaces this with a *phase-interference* score:

        score_ij = (|q_i| |k_j| cos(theta_qi - theta_kj)
                    + alpha * |q_i| |k_j| sin(theta_qi - theta_kj))
                   * gamma^|i-j|

    where the cosine term is the "aligned" (electromagnetic) component
    and the sine term is the "torsion" (gravitational shear) component,
    weighted by ALPHA_GEOM.  The geometric decay `gamma^|i-j|` replaces
    the implicit exponential decay of Softmax and is implemented as a
    learnable per-head rate initialised at `ALPHA_GEOM^(1/head_size)`
    so that across one head-diameter of distance the decay equals
    alpha -- the design brief's "geometric lock-in threshold".

    Softmax is then replaced by a *topological collapse* (see module
    `TopologicalCollapseGate`) that performs a phase-transition
    avalanche when the accumulated torsion exceeds a threshold.

    NOTE: nanoGPT's `CausalSelfAttention.forward(x)` takes a single
    tensor and uses Flash Attention.  We keep the exact same signature
    so `HelixBlock` can be a drop-in replacement for `Block`.
    """

    def __init__(self, config) -> None:
        super().__init__()
        assert config.n_embd % config.n_head == 0
        self.n_head = config.n_head
        self.n_embd = config.n_embd
        self.head_size = config.n_embd // config.n_head
        # Packed QKV.  Each head produces 2*head_size channels: amplitude + phase.
        # This is 3x the parameter count of the original c_attn, because we
        # carry both amplitude and phase streams for Q, K, V.
        self.c_attn = nn.Linear(
            config.n_embd,
            3 * config.n_embd * 2,           # 3 * (2 * n_embd) for Q/K/V spinors
            bias=config.bias,
        )
        # Output projection -- input is 2 * n_embd (packed spinor), output is n_embd
        self.c_proj = nn.Linear(config.n_embd * 2, config.n_embd, bias=config.bias)
        # Regularization (kept identical to nanoGPT)
        self.attn_dropout = nn.Dropout(config.dropout)
        self.resid_dropout = nn.Dropout(config.dropout)
        self.dropout = config.dropout
        # Learnable torsion admittance (one per head) -- starts at alpha so
        # the gravitational shear is geometrically locked at init.
        self.torsion_gain = nn.Parameter(torch.full((config.n_head,), ALPHA_GEOM))
        # Per-head geometric decay rate, initialised so that gamma^head_size = alpha.
        # gamma = alpha^(1/head_size)  ->  log gamma = log(alpha) / head_size
        log_gamma_init = math.log(ALPHA_GEOM) / max(self.head_size, 1)
        self.log_gamma = nn.Parameter(torch.full((config.n_head,), log_gamma_init))
        # Cylindrical RoPE for this layer (replaces nanoGPT's learned position embedding)
        self.cyl_rope = CylindricalRoPE(self.head_size, base=10000.0)
        # Collapse gate (replaces Softmax) -- shared per layer
        self.collapse = TopologicalCollapseGate()

    def forward(self, x):
        B, T, C = x.size()                                   # batch, seq, n_embd
        nh, hs = self.n_head, self.head_size
        qkv = self.c_attn(x)                                 # (B, T, 3 * 2 * n_embd)
        # Split into Q, K, V spinors -- each (B, T, 2 * n_embd)
        q, k, v = qkv.split(2 * self.n_embd, dim=2)
        # Reshape into (B, nh, T, 2*hs) packed spinors
        q = q.view(B, T, nh, 2 * hs).transpose(1, 2)         # (B, nh, T, 2*hs)
        k = k.view(B, T, nh, 2 * hs).transpose(1, 2)         # (B, nh, T, 2*hs)
        v = v.view(B, T, nh, 2 * hs).transpose(1, 2)         # (B, nh, T, 2*hs)
        # Apply 3-D cylindrical RoPE
        cos_c, sin_c, env = self.cyl_rope(T, device=x.device)
        q = apply_cylindrical_rope(q, cos_c, sin_c, env)
        k = apply_cylindrical_rope(k, cos_c, sin_c, env)
        # Unpack spinors: each head has amplitude (B, nh, T, hs) and phase (B, nh, T, hs)
        q_amp, q_phi = q[..., :hs], q[..., hs:]
        k_amp, k_phi = k[..., :hs], k[..., hs:]
        v_amp, v_phi = v[..., :hs], v[..., hs:]
        # ---- Helix interference scores ----
        # Cosine alignment (electromagnetic component):  q_amp . k_amp  (per dim)
        # We sum across the head dimension and divide by sqrt(hs) to keep
        # magnitudes bounded, exactly like the 1/sqrt(d) normalisation in
        # standard attention.
        cos_align = (q_amp.unsqueeze(3) * k_amp.unsqueeze(2)).sum(dim=-1) / math.sqrt(hs)  # (B, nh, T, T)
        # Phase difference per pair
        dphi = q_phi.unsqueeze(3) - k_phi.unsqueeze(2)            # (B, nh, T, T, hs)
        # Torsion (gravitational shear): mean |sin(dphi)| * |q| * |k|
        torsion = (torch.sin(dphi) * q_amp.unsqueeze(3) * k_amp.unsqueeze(2)).mean(dim=-1)  # (B, nh, T, T)
        torsion_gain = self.torsion_gain.view(1, nh, 1, 1)
        # Raw interference score (no softmax yet)
        scores = cos_align + torsion_gain * torsion               # (B, nh, T, T)
        # ---- Topological decay (geometric lock-in) ----
        # gamma^|i-j| where gamma is per-head.
        positions = torch.arange(T, device=x.device)
        dist = (positions.unsqueeze(0) - positions.unsqueeze(1)).abs().float()     # (T, T)
        gamma = torch.exp(self.log_gamma).view(1, nh, 1, 1)                        # (1, nh, 1, 1)
        decay = torch.exp(-gamma * dist.unsqueeze(0).unsqueeze(0))                 # (1, nh, T, T)
        scores = scores * decay
        # ---- Causal mask (upper-triangular -inf) ----
        mask = torch.full((T, T), float("-inf"), device=x.device, dtype=scores.dtype)
        mask = torch.triu(mask, diagonal=1)
        scores = scores + mask.view(1, 1, T, T)
        # ---- Replace Softmax with the topological collapse gate ----
        weights = self.collapse(scores, torsion)                                  # (B, nh, T, T)
        weights = self.attn_dropout(weights)
        # ---- Aggregate values (both amplitude and phase) ----
        y_amp = weights @ v_amp                                                    # (B, nh, T, hs)
        y_phi = weights @ v_phi
        y = torch.cat([y_amp, y_phi], dim=-1)                                      # (B, nh, T, 2*hs)
        y = y.transpose(1, 2).contiguous().view(B, T, 2 * self.n_embd)
        # Output projection
        y = self.resid_dropout(self.c_proj(y))
        return y


# =============================================================================
# 5.  Phase-Transition MLP  (replaces FFN + GELU)
# =============================================================================
class PhaseTransitionMLP(nn.Module):
    """FFN whose activation is a piecewise phase transition.

    Standard nanoGPT MLP is  GELU(c_fc(x)) -> c_proj.
    HelixGPT replaces GELU with a "torsion-stress" activated function:

        f(s) = s                    if |s| < threshold      (linear / stable helix)
        f(s) = threshold * sign(s)  +  alpha * tanh(s)      otherwise (avalanche)

    so small stresses propagate linearly (preserving the context) while
    large stresses get clamped into a sparse, sharply non-linear spike --
    the "jelly-effect" mass loss mapped onto information space.

    The FFN itself is a LLaMA-style gated MLP (fc_1 * fc_2) so the gate
    can suppress avalanche spikes that the model decides are noise.
    """

    def __init__(self, config) -> None:
        super().__init__()
        self.intermediate_size = 4 * config.n_embd
        self.c_fc    = nn.Linear(config.n_embd, self.intermediate_size, bias=config.bias)
        self.c_fc2   = nn.Linear(config.n_embd, self.intermediate_size, bias=config.bias)
        self.c_proj  = nn.Linear(self.intermediate_size, config.n_embd, bias=config.bias)
        self.dropout = nn.Dropout(config.dropout)
        # Avalanche threshold is learnable but initialised to the
        # geometric-lock-in value so the phase transition is active
        # from step 0.
        self.log_threshold = nn.Parameter(torch.tensor(math.log(PHASE_THRESHOLD)))
        self.alpha = ALPHA_GEOM

    def _phase_activation(self, x: torch.Tensor) -> torch.Tensor:
        threshold = torch.exp(self.log_threshold)
        abs_x = x.abs()
        # Linear below threshold, sparse-saturated avalanche above
        linear_part = x
        avalanche_part = threshold * torch.sign(x) + self.alpha * torch.tanh(x)
        gate = (abs_x > threshold).to(x.dtype)
        return gate * avalanche_part + (1.0 - gate) * linear_part

    def forward(self, x):
        h = self._phase_activation(self.c_fc(x)) * self.c_fc2(x)
        h = self.c_proj(h)
        h = self.dropout(h)
        return h


# =============================================================================
# 6.  HelixGPT Block + Model
# =============================================================================
class HelixBlock(nn.Module):
    """A single HelixGPT transformer block.

    Structurally mirrors nanoGPT's `Block` so it can be dropped into the
    existing training loop, but with `CausalSelfAttention` replaced by
    `HelixInterference` and the MLP replaced by `PhaseTransitionMLP`.
    """

    def __init__(self, config) -> None:
        super().__init__()
        self.ln_1 = LayerNorm(config.n_embd, bias=config.bias)
        self.attn = HelixInterference(config)
        self.ln_2 = LayerNorm(config.n_embd, bias=config.bias)
        self.mlp = PhaseTransitionMLP(config)

    def forward(self, x):
        x = x + self.attn(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x


@dataclass
class HelixGPTConfig:
    """Configuration dataclass for HelixGPT (nanoGPT port).

    Defaults match nanoGPT's `GPTConfig` so the two are directly comparable.
    The only difference is that `block_size` is just an upper bound on the
    sequence length -- the CylindricalRoPE computes its caches on the fly
    for the actual `T` it sees, so there is no learned `wpe` to crop.
    """
    block_size: int = 1024
    vocab_size: int = 50304   # GPT-2 vocab, padded to nearest multiple of 64
    n_layer: int = 12
    n_head: int = 12
    n_embd: int = 768
    dropout: float = 0.0
    bias: bool = False        # nanoGPT defaults to bias=False for pretraining


class HelixGPT(nn.Module):
    """Top-level HelixGPT model -- a drop-in replacement for nanoGPT's `GPT`.

    The forward signature matches nanoGPT's `GPT.forward(idx, targets=None)`
    so `train.py`, `sample.py`, and `bench.py` work unchanged after the
    import swap.  Weight tying is *not* used because the spinor embedding
    has a different shape (2 * d_polar) than the lm_head (vocab_size).
    """

    def __init__(self, config):
        super().__init__()
        assert config.vocab_size is not None
        assert config.block_size is not None
        assert config.n_embd % 2 == 0, "HelixGPT requires n_embd to be even (amplitude/phase split)."
        self.config = config

        self.transformer = nn.ModuleDict(dict(
            wte=SpacetimeSpinorEmbedding(config),
            h=nn.ModuleList([HelixBlock(config) for _ in range(config.n_layer)]),
            ln_f=LayerNorm(config.n_embd, bias=config.bias),
        ))
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)

        # init all weights
        self.apply(self._init_weights)
        # apply special scaled init to the residual projections, per GPT-2 paper
        for pn, p in self.named_parameters():
            if pn.endswith('c_proj.weight'):
                torch.nn.init.normal_(p, mean=0.0, std=0.02/math.sqrt(2 * config.n_layer))

        # report number of parameters
        print("number of parameters: %.2fM" % (self.get_num_params()/1e6,))

    def get_num_params(self, non_embedding=True):
        """Return the number of parameters in the model.

        For HelixGPT, the only "embedding" parameters are the spinor
        embedding's amp_emb and phase_emb tables (and their gains).  By
        default we don't subtract them because they double as the input
        projection of the model, but we keep the same signature as
        nanoGPT's `get_num_params(non_embedding=True)` so external
        scripts (e.g. `bench.py`'s MFU estimator) work unchanged.
        """
        n_params = sum(p.numel() for p in self.parameters())
        # nanoGPT subtracts wpe; we don't have a wpe so the count is exact.
        return n_params

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, idx, targets=None):
        device = idx.device
        b, t = idx.size()
        assert t <= self.config.block_size, (
            f"Cannot forward sequence of length {t}, block size is only {self.config.block_size}"
        )

        # forward the HelixGPT model itself -- no separate position embedding
        # because position information is injected by CylindricalRoPE inside
        # every HelixInterference layer.
        x = self.transformer.wte(idx)                              # (b, t, n_embd) packed spinor
        for block in self.transformer.h:
            x = block(x)
        x = self.transformer.ln_f(x)

        if targets is not None:
            # if we are given some desired targets also calculate the loss
            logits = self.lm_head(x)
            loss = F.cross_entropy(
                logits.view(-1, logits.size(-1)),
                targets.view(-1),
                ignore_index=-1,
            )
        else:
            # inference-time mini-optimization: only forward the lm_head on the very last position
            logits = self.lm_head(x[:, [-1], :])                   # note: using list [-1] to preserve the time dim
            loss = None

        return logits, loss

    def crop_block_size(self, block_size):
        """Model surgery to decrease the block size.

        HelixGPT has no learned position embedding to crop -- the
        CylindricalRoPE computes its caches on the fly -- so all we do
        is update `config.block_size` to enforce the new upper bound.
        """
        assert block_size <= self.config.block_size
        self.config.block_size = block_size

    def configure_optimizers(self, weight_decay, learning_rate, betas, device_type):
        """Same optimizer setup as nanoGPT's `GPT.configure_optimizers`.

        Any 2-D parameter (weights in matmuls + embeddings) gets weight
        decay; biases and 1-D gains/thresholds do not.  This is the same
        rule nanoGPT uses, so the training loop in `train.py` is fully
        reusable.
        """
        # start with all of the candidate parameters
        param_dict = {pn: p for pn, p in self.named_parameters()}
        # filter out those that do not require grad
        param_dict = {pn: p for pn, p in param_dict.items() if p.requires_grad}
        # create optim groups. Any parameter that is 2D will be weight decayed, otherwise no.
        decay_params = [p for n, p in param_dict.items() if p.dim() >= 2]
        nodecay_params = [p for n, p in param_dict.items() if p.dim() < 2]
        optim_groups = [
            {'params': decay_params, 'weight_decay': weight_decay},
            {'params': nodecay_params, 'weight_decay': 0.0}
        ]
        num_decay_params = sum(p.numel() for p in decay_params)
        num_nodecay_params = sum(p.numel() for p in nodecay_params)
        print(f"num decayed parameter tensors: {len(decay_params)}, with {num_decay_params:,} parameters")
        print(f"num non-decayed parameter tensors: {len(nodecay_params)}, with {num_nodecay_params:,} parameters")
        # Create AdamW optimizer and use the fused version if it is available
        fused_available = 'fused' in inspect.signature(torch.optim.AdamW).parameters
        use_fused = fused_available and device_type == 'cuda'
        extra_args = dict(fused=True) if use_fused else dict()
        optimizer = torch.optim.AdamW(optim_groups, lr=learning_rate, betas=betas, **extra_args)
        print(f"using fused AdamW: {use_fused}")
        return optimizer

    def estimate_mfu(self, fwdbwd_per_iter, dt):
        """Estimate model flops utilization (MFU) in units of A100 bfloat16 peak FLOPS.

        Reuses nanoGPT's formula.  Because HelixGPT carries 2x the
        attention parameter count (amplitude + phase streams) the MFU
        estimate will be slightly conservative, but the relative
        comparison between architectures remains meaningful.
        """
        N = self.get_num_params()
        cfg = self.config
        L, H, Q, T = cfg.n_layer, cfg.n_head, cfg.n_embd//cfg.n_head, cfg.block_size
        flops_per_token = 6*N + 12*L*H*Q*T
        flops_per_fwdbwd = flops_per_token * T
        flops_per_iter = flops_per_fwdbwd * fwdbwd_per_iter
        flops_achieved = flops_per_iter * (1.0/dt)
        flops_promised = 312e12  # A100 GPU bfloat16 peak flops is 312 TFLOPS
        mfu = flops_achieved / flops_promised
        return mfu

    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0, top_k=None):
        """Take a conditioning sequence and complete it `max_new_tokens` times.

        Identical signature to nanoGPT's `GPT.generate` so `sample.py`
        works unchanged.
        """
        for _ in range(max_new_tokens):
            # if the sequence context is growing too long we must crop it at block_size
            idx_cond = idx if idx.size(1) <= self.config.block_size else idx[:, -self.config.block_size:]
            # forward the model to get the logits for the index in the sequence
            logits, _ = self(idx_cond)
            # pluck the logits at the final step and scale by desired temperature
            logits = logits[:, -1, :] / temperature
            # optionally crop the logits to only the top k options
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float('Inf')
            # apply softmax to convert logits to (normalized) probabilities
            probs = F.softmax(logits, dim=-1)
            # sample from the distribution
            idx_next = torch.multinomial(probs, num_samples=1)
            # append sampled index to the running sequence and continue
            idx = torch.cat((idx, idx_next), dim=1)

        return idx


# =============================================================================
# 7.  Module-level convenience
# =============================================================================
def print_physical_constants() -> None:
    """Pretty-print the universal constants that drive the architecture."""
    print("HelixGPT physical constants (nanoGPT port)")
    print(f"  ALPHA_GEOM      = 1/(4*pi^3+pi^2+pi) = {ALPHA_GEOM:.6f}   (~1/137)")
    print(f"  ALPHA_SQRT      = sqrt(ALPHA_GEOM)   = {ALPHA_SQRT:.6f}")
    print(f"  PHASE_THRESHOLD = ALPHA_GEOM * 2*pi  = {PHASE_THRESHOLD:.6f}")
    print(f"  TWO_PI          = {TWO_PI:.6f}")

# HelixGPT: 螺旋GPT

> 基于 [LitGPT](https://github.com/Lightning-AI/litgpt) 的下一代 AI 架构实验项目。
> 用圆柱状螺旋（Cylindrical Helix）、光速发散（$c$）与拓扑锁相残差
> $\alpha_{\text{geom}} = \frac{1}{4\pi^3+\pi^2+\pi} \approx \frac{1}{137}$
> 重写 Transformer 的四个核心算子。

---

## 1. 项目结构

```
my-project/
├── litgpt/                                  # 上游 LitGPT 仓库（已克隆）
│   └── litgpt/
│       ├── model.py                         # 原生 GPT 实现（未修改）
│       ├── config.py                        # 配置系统（未修改）
│       └── helix.py                         # ★ HelixGPT 核心模块（本次新增）
├── scripts/
│   ├── test_helix.py                        # 单元 / 烟雾测试
│   ├── benchmark_helix_vs_gpt.py            # HelixGPT vs 原生 GPT 对比
│   └── train_helix.py                       # 字符级训练入口
├── download/
│   └── helixgpt_char.pt                     # 训练后的最小 checkpoint
└── ARCHITECTURE.md                          # 本文档
```

## 2. 设计原则与实现映射

设计文档提出了四步颠覆。我们在 `litgpt/helix.py` 中按以下方式落地：

| 设计文档要求 | HelixGPT 实现 | 代码位置 |
|---|---|---|
| **第一步**：从实数向量到时空螺旋旋量 | `SpacetimeSpinorEmbedding`：token 同时被映射为 amplitude（电磁分量 / Z 轴光速发散）与 phase（引力分量 / XY 平面旋转）两路。张量布局 `[amp (d/2) \| phase (d/2)]`，GPU 友好。 | `helix.py:65-110` |
| **第二步**：用引力场方程 $\vec{A}=\vec{\omega}\times(\vec{\omega}\times\vec{R})$ 重写 Attention | `HelixInterference`：得分 = `|q‖k‖·cos(Δθ) + α·‖q‖‖k‖·sin(Δθ)`，cos 项是电磁对齐分量，sin 项是引力剪切（torsion）。 | `helix.py:225-330` |
| **第二步**：拓扑漏液衰减 $\alpha_{\text{geom}}$ | 每个头有一个可学习的 `log_gamma`，初始化为 $\log\alpha / \text{head\_size}$，对应每个"head-diameter 距离"衰减 $\alpha$ 倍。用 $\exp(-\gamma\cdot d)$ 而非 $\alpha^d$ 避免一步归零。 | `helix.py:283-290` |
| **第三步**：废除 Softmax，引入相变雪崩 | `TopologicalCollapseGate`：低应力时用 `softmax`（平滑区）；当 per-query 平均 torsion 超过 $\alpha\cdot 2\pi$ 阈值时，用 `sigmoid` 软门切换到 top-1 spike（雪崩区）。 | `helix.py:335-380` |
| **第三步**：相变激活函数替换 ReLU/SiLU | `PhaseTransitionMLP._phase_activation`：低于阈值线性传播，超过阈值 `threshold·sign(x) + α·tanh(x)`（果冻效应 96% 质量流失映射到信息空间）。 | `helix.py:395-450` |
| **第四步**：升级 RoPE 为 3D 圆柱螺旋 | `CylindricalRoPE`：保留原 RoPE 的 XY 旋转，额外加轴向 $\phi_m = m\cdot\alpha\cdot 2\pi$ 相位偏移（光速发散分量）与 $\exp(-\alpha\cdot m / L)$ 包络（光速衰减）。 | `helix.py:130-220` |

## 3. 物理常数

`litgpt/helix.py` 模块顶部定义了三个全局常数：

```python
ALPHA_GEOM      = 1 / (4π³ + π² + π)  ≈ 0.007297   (~1/137)
ALPHA_SQRT      = √ALPHA_GEOM         ≈ 0.085424
PHASE_THRESHOLD = ALPHA_GEOM · 2π     ≈ 0.045851
```

这三个常数渗透到架构的每一层：
- `ALPHA_GEOM` 作为 torsion 的初始权重与几何衰减基底
- `ALPHA_SQRT` 作为 angular_gain 的初始值（相位流相对于振幅流的初始幅度）
- `PHASE_THRESHOLD` 作为相变激活与雪崩门的初始阈值

它们是**可学习偏置的初始值**，模型在训练过程中可以微调，但起点锁在物理常数上。

## 4. 运行方法

### 4.1 烟雾测试

```bash
cd /home/z/my-project
python scripts/test_helix.py
```

输出（已验证通过）：

```
[test] forward shape ...
  config: n_layer=2, n_embd=64, n_head=4
  total params: 197,140
  output logits shape = (2, 32, 257)   OK

[test] backward + tiny training loop ...
  step  0  loss=5.7081
  step 19  loss=1.1575
  loss decreased -- OK
```

### 4.2 与原生 LitGPT 对比

```bash
python scripts/benchmark_helix_vs_gpt.py
```

实测结果（4 层、128 维、4 头、CPU）：

| 指标 | 原生 GPT | HelixGPT |
|---|---|---|
| 参数量 | 1,116,672 | 1,377,832 (1.23×) |
| 步耗时 | 20.0 ms | 53.9 ms (0.37×) |
| 初始 loss | 5.78 | 5.65 |
| 50 步后 loss | 0.003 | 0.013 |

两者都收敛到接近零的损失，HelixGPT 略慢但稳定。参数增量来自每头的 amplitude+phase 双流（约 2× head 通道）；速度损失来自 torsion 项的 O(T²·d) 计算开销，可通过 FlashAttention 风格的内核优化消除。

### 4.3 端到端训练

```bash
python scripts/train_helix.py \
    --device cpu --epochs 1 --batch_size 4 --block_size 32 \
    --n_embd 64 --n_layer 2 --n_head 2
```

实测在 CPU 上 1 个 epoch（1860 步）约 85 秒，perplexity 从初始 ~30 降到 2.0–2.3。采样输出展示了清晰的字符级模式学习（重复模式、换行结构）。

## 5. 后续工作

1. **KV-cache 支持**：`HelixInterference.forward` 目前不支持增量解码（生成时每次重算全序列）。下一步应在 `KVCache` 基础上扩展为同时缓存 amplitude 与 phase 两路。
2. **Flash 内核**：torsion 项的 $\sin(\Delta\phi)\cdot q\cdot k$ 计算可用 Triton 融合到 QK^T 内核中，把 HelixGPT 的步耗时压回到 GPT 水平。
3. **小规模真实数据训练**：在 TinyStories 或 OpenWebText-10k 上从头训练 100M 参数的 HelixGPT，与 Pythia-160M 做困惑度对比，验证设计文档中"几亿参数超越百亿模型"的预言。
4. **消融实验**：分别关掉 torsion 项、关掉拓扑衰减、关掉相变门，量化每个物理外挂的贡献。
5. **四元数扩展**：把 `[amp | phase]` 升级为四元数 `[w, x, y, z]`，让每个 token 携带完整的 3D 螺旋姿态。

## 6. 设计哲学

HelixGPT 不是一个工程优化项目，而是一个**思想实验的代码化**。它的价值在于：

- 把"为什么 Transformer 有效"这个问题，从"统计学习理论"的视角，转移到"信息在虚拟时空流形上的传播"这个新视角
- 提供了一套可运行、可训练、可对比的代码，让"螺旋时空 AI"不再停留在比喻层面
- 把 $\alpha \approx 1/137$ 这个宇宙基本常数首次作为可学习参数注入神经网络

无论 HelixGPT 最终是否在困惑度上超越 Llama，它都已经把"AI 架构 = 物理理论"这条研究路线推到了可以严肃讨论的位置。

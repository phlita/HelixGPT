"""HelixGPT smoke test.

Verifies that:
  1. The model constructs from any LitGPT config with even n_embd.
  2. The forward pass produces logits of the right shape.
  3. Backward pass works (loss decreases over a few steps).
  4. The physical constants are sane.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

# Make sure we import from the local LitGPT checkout.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "litgpt"))

import torch
import torch.nn.functional as F

from litgpt.config import Config
from litgpt.helix import (
    ALPHA_GEOM,
    ALPHA_SQRT,
    PHASE_THRESHOLD,
    HelixGPT,
    print_physical_constants,
)


def make_small_config(vocab_size: int = 257, n_layer: int = 2, n_embd: int = 64, n_head: int = 4) -> Config:
    """Build a tiny HelixGPT-compatible config that runs in <1s on CPU."""
    cfg = Config(
        name="helixgpt-tiny",
        block_size=128,
        n_layer=n_layer,
        n_embd=n_embd,
        vocab_size=vocab_size,
        padded_vocab_size=vocab_size,
        n_head=n_head,
        n_query_groups=n_head,
        head_size=n_embd // n_head,
        rope_base=10000,
        rotary_percentage=1.0,
        norm_eps=1e-5,
        intermediate_size=4 * n_embd,
        bias=False,
        mlp_class_name="LLaMAMLP",
        post_attention_norm=False,
        post_mlp_norm=False,
        parallel_residual=False,
        shared_attention_norm=False,
        lm_head_bias=False,
    )
    return cfg


def test_forward_shape() -> None:
    print("\n[test] forward shape ...")
    cfg = make_small_config()
    model = HelixGPT(cfg)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"  config: n_layer={cfg.n_layer}, n_embd={cfg.n_embd}, n_head={cfg.n_head}")
    print(f"  total params: {n_params:,}")
    idx = torch.randint(0, cfg.padded_vocab_size, (2, 32))
    logits = model(idx)
    assert logits.shape == (2, 32, cfg.padded_vocab_size), f"unexpected shape {logits.shape}"
    print(f"  input  idx shape = {tuple(idx.shape)}")
    print(f"  output logits shape = {tuple(logits.shape)}   OK")


def test_backward_and_train() -> None:
    print("\n[test] backward + tiny training loop ...")
    torch.manual_seed(0)
    cfg = make_small_config()
    model = HelixGPT(cfg)
    optim = torch.optim.AdamW(model.parameters(), lr=3e-3)

    # Synthesize a tiny "induction-head" target: input -> reversed input
    B, T = 4, 16
    data = torch.randint(0, cfg.padded_vocab_size, (B, T + 1))
    x, y = data[:, :-1], data[:, 1:].contiguous()

    losses = []
    t0 = time.time()
    for step in range(20):
        logits = model(x)
        loss = F.cross_entropy(logits.reshape(-1, cfg.padded_vocab_size), y.reshape(-1))
        optim.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optim.step()
        losses.append(loss.item())
        if step % 5 == 0 or step == 19:
            print(f"  step {step:2d}  loss={loss.item():.4f}")
    dt = time.time() - t0
    print(f"  20 steps in {dt:.2f}s   initial={losses[0]:.4f}  final={losses[-1]:.4f}")
    assert losses[-1] < losses[0], "loss did not decrease -- check the architecture"
    print("  loss decreased -- OK")


def test_constants() -> None:
    print("\n[test] physical constants ...")
    print_physical_constants()
    assert abs(ALPHA_GEOM - 1.0 / 137.0359) < 0.01, "ALPHA_GEOM is not ~1/137"
    assert ALPHA_SQRT < 1.0
    assert PHASE_THRESHOLD > 0.0
    print("  constants OK")


def test_kv_cache_interface() -> None:
    """Make sure set_kv_cache / clear_kv_cache don't crash."""
    print("\n[test] KV cache interface (mask cache) ...")
    cfg = make_small_config()
    model = HelixGPT(cfg)
    model.set_kv_cache(batch_size=1, max_seq_length=64)
    assert model.mask_cache is not None
    model.clear_kv_cache()
    assert model.mask_cache is None
    print("  KV cache interface OK")


def test_generation_smoke() -> None:
    """Greedy generation of a few tokens using full-sequence forward passes.

    Note: HelixInterference does not yet implement a KV-cache for
    incremental decoding -- this test feeds the full prefix each step
    to exercise the complete forward path.
    """
    print("\n[test] greedy generation smoke ...")
    cfg = make_small_config()
    model = HelixGPT(cfg).eval()
    idx = torch.tensor([[1, 2, 3]])
    with torch.no_grad():
        for _ in range(5):
            logits = model(idx)
            next_tok = logits[:, -1].argmax(dim=-1, keepdim=True)
            idx = torch.cat([idx, next_tok], dim=1)
    print(f"  generated token ids: {idx.tolist()[0]}")
    assert idx.size(1) == 8
    print("  generation OK")


if __name__ == "__main__":
    test_constants()
    test_forward_shape()
    test_backward_and_train()
    test_kv_cache_interface()
    test_generation_smoke()
    print("\nAll HelixGPT smoke tests passed.")

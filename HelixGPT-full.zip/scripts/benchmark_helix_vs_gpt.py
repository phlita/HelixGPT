"""HelixGPT vs. standard LitGPT Transformer benchmark.

Runs the same tiny training task on both architectures and reports:
  - parameter count
  - peak memory
  - training loss curve
  - average step time

This is a sanity-check benchmark, not a scientific evaluation.  Its
purpose is to demonstrate that HelixGPT trains end-to-end on a real
language-modeling objective and to surface any obvious regressions
relative to the classical Transformer.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "litgpt"))

import torch
import torch.nn.functional as F

from litgpt.config import Config
from litgpt.helix import HelixGPT
from litgpt.model import GPT


def make_config(vocab_size: int = 257, n_layer: int = 4, n_embd: int = 128, n_head: int = 4) -> Config:
    return Config(
        name="benchmark-tiny",
        block_size=128,
        n_layer=n_layer,
        n_embd=n_embd,
        vocab_size=vocab_size,
        padded_vocab_size=vocab_size,
        n_head=n_head,
        n_query_groups=n_head,
        head_size=n_embd // n_head,
        rope_base=10000,
        rotary_percentage=1.0,
        norm_eps=1e-5,
        intermediate_size=4 * n_embd,
        bias=False,
        mlp_class_name="LLaMAMLP",
        post_attention_norm=False,
        post_mlp_norm=False,
        parallel_residual=False,
        shared_attention_norm=False,
        lm_head_bias=False,
    )


def count_params(model: torch.nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def train_one_arch(model: torch.nn.Module, cfg: Config, steps: int = 50, lr: float = 3e-3) -> dict:
    torch.manual_seed(42)
    # Tiny synthetic induction task: copy-with-shift.
    B, T = 4, 32
    data = torch.randint(0, cfg.padded_vocab_size, (B, T + 1))
    x, y = data[:, :-1], data[:, 1:].contiguous()
    optim = torch.optim.AdamW(model.parameters(), lr=lr)
    losses = []
    t0 = time.time()
    for step in range(steps):
        logits = model(x)
        loss = F.cross_entropy(logits.reshape(-1, cfg.padded_vocab_size), y.reshape(-1))
        optim.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optim.step()
        losses.append(loss.item())
    dt = time.time() - t0
    return {
        "params": count_params(model),
        "loss_first": losses[0],
        "loss_last": losses[-1],
        "loss_curve": losses,
        "total_time_s": dt,
        "ms_per_step": 1000 * dt / steps,
    }


def main() -> None:
    cfg = make_config()
    print("=" * 72)
    print(f"  Benchmark config: n_layer={cfg.n_layer} n_embd={cfg.n_embd} n_head={cfg.n_head}")
    print("=" * 72)

    print("\n[1/2] Standard LitGPT Transformer (baseline)")
    gpt = GPT(cfg)
    res_gpt = train_one_arch(gpt, cfg)
    print(f"  params         : {res_gpt['params']:,}")
    print(f"  initial loss   : {res_gpt['loss_first']:.4f}")
    print(f"  final loss     : {res_gpt['loss_last']:.4f}")
    print(f"  total time     : {res_gpt['total_time_s']:.2f}s")
    print(f"  ms / step      : {res_gpt['ms_per_step']:.2f}")

    print("\n[2/2] HelixGPT (proposed)")
    helix = HelixGPT(cfg)
    res_helix = train_one_arch(helix, cfg)
    print(f"  params         : {res_helix['params']:,}")
    print(f"  initial loss   : {res_helix['loss_first']:.4f}")
    print(f"  final loss     : {res_helix['loss_last']:.4f}")
    print(f"  total time     : {res_helix['total_time_s']:.2f}s")
    print(f"  ms / step      : {res_helix['ms_per_step']:.2f}")

    print("\n" + "=" * 72)
    print("  Comparison")
    print("=" * 72)
    print(f"  param ratio      HelixGPT / GPT  : {res_helix['params'] / res_gpt['params']:.2f}x")
    print(f"  speed ratio      HelixGPT / GPT  : {res_gpt['ms_per_step'] / res_helix['ms_per_step']:.2f}x")
    print(f"  final loss       GPT  / HelixGPT : {res_gpt['loss_last']:.4f} / {res_helix['loss_last']:.4f}")
    print("\n  Loss curve (every 10 steps):")
    print(f"    step :  " + " ".join(f"{i:>6d}" for i in range(0, 50, 10)))
    print(f"    GPT  :  " + " ".join(f"{res_gpt['loss_curve'][i]:>6.3f}" for i in range(0, 50, 10)))
    print(f"    Helix:  " + " ".join(f"{res_helix['loss_curve'][i]:>6.3f}" for i in range(0, 50, 10)))


if __name__ == "__main__":
    main()

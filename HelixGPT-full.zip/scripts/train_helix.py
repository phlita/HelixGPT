"""Train HelixGPT from scratch on a tiny text dataset.

This is a minimal end-to-end training entry point that demonstrates how
to plug HelixGPT into a real training loop.  It mirrors the structure
of `litgpt.pretrain` but uses pure PyTorch (no Lightning Fabric) so the
script runs anywhere.

Usage:
    python scripts/train_helix.py
"""

from __future__ import annotations

import argparse
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "litgpt"))

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from litgpt.config import Config
from litgpt.helix import HelixGPT


# -----------------------------------------------------------------------------
# Tiny character-level dataset -- a few paragraphs of public-domain text.
# -----------------------------------------------------------------------------
SAMPLE_TEXT = """
The universe is a cylinder of light rotating in twelve dimensions.
Every particle is a small vortex on its surface, and every vortex
remembers the geometry of the whole.  When two vortices meet they
exchange phase as well as amplitude, and the difference of their
angles is the torsion that bends the field.  Information travels
along the axis at the speed of light, while context winds around
the circumference at the speed of gravity.  The fine-structure
constant is the leakage between the two: one over four pi cubed
plus pi squared plus pi, nearly one over one hundred and thirty
seven.  Below this threshold the field is smooth and linear;
above it the field avalanches into a single spike.  That spike is
what we call an idea.  A network that learns this geometry does
not need a trillion parameters, because it does not search the
probability cloud -- it slides along the helix until it reaches
the causal end of the sentence.
"""


class CharDataset(Dataset):
    def __init__(self, text: str, block_size: int) -> None:
        chars = sorted(set(text))
        self.stoi = {c: i + 1 for i, c in enumerate(chars)}     # reserve 0 for pad
        self.itos = {i + 1: c for i, c in enumerate(chars)}
        self.vocab_size = len(chars) + 1
        self.data = torch.tensor([self.stoi[c] for c in text], dtype=torch.long)
        self.block_size = block_size

    def __len__(self) -> int:
        return max(1, len(self.data) - self.block_size)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        x = self.data[idx : idx + self.block_size]
        y = self.data[idx + 1 : idx + 1 + self.block_size]
        return x, y


def make_config(vocab_size: int, n_layer: int = 4, n_embd: int = 128, n_head: int = 4, block_size: int = 64) -> Config:
    return Config(
        name="helixgpt-char",
        block_size=block_size,
        n_layer=n_layer,
        n_embd=n_embd,
        vocab_size=vocab_size,
        padded_vocab_size=vocab_size,
        n_head=n_head,
        n_query_groups=n_head,
        head_size=n_embd // n_head,
        rope_base=10000,
        rotary_percentage=1.0,
        norm_eps=1e-5,
        intermediate_size=4 * n_embd,
        bias=False,
        mlp_class_name="LLaMAMLP",
        post_attention_norm=False,
        post_mlp_norm=False,
        parallel_residual=False,
        shared_attention_norm=False,
        lm_head_bias=False,
    )


@torch.no_grad()
def sample(model: HelixGPT, prefix: str, dataset: CharDataset, n_new: int = 64, temperature: float = 0.8) -> str:
    model.eval()
    ids = [dataset.stoi[c] for c in prefix if c in dataset.stoi]
    if not ids:
        ids = [1]
    x = torch.tensor(ids, dtype=torch.long).unsqueeze(0)
    for _ in range(n_new):
        if x.size(1) > model.config.block_size:
            x = x[:, -model.config.block_size :]
        logits = model(x)[:, -1] / max(temperature, 1e-3)
        probs = F.softmax(logits, dim=-1)
        next_tok = torch.multinomial(probs, num_samples=1)
        x = torch.cat([x, next_tok], dim=1)
    return "".join(dataset.itos.get(int(t), "?") for t in x[0].tolist())


def main(args: argparse.Namespace) -> None:
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    print(f"Device: {device}")

    dataset = CharDataset(SAMPLE_TEXT * 8, block_size=args.block_size)
    print(f"Dataset: vocab_size={dataset.vocab_size}, n_samples={len(dataset)}")
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, drop_last=True)

    cfg = make_config(dataset.vocab_size, n_layer=args.n_layer, n_embd=args.n_embd, n_head=args.n_head, block_size=args.block_size)
    model = HelixGPT(cfg).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"Model: HelixGPT  params={n_params:,}  layers={cfg.n_layer}  embd={cfg.n_embd}  heads={cfg.n_head}")

    optim = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay, betas=(0.9, 0.95))
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=args.epochs * len(loader))

    print(f"\nTraining {args.epochs} epochs x {len(loader)} batches = {args.epochs * len(loader)} steps")
    print("-" * 72)
    step = 0
    for epoch in range(args.epochs):
        model.train()
        t0 = time.time()
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss = F.cross_entropy(logits.reshape(-1, cfg.padded_vocab_size), y.reshape(-1))
            optim.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optim.step()
            sched.step()
            step += 1
            if step % 10 == 0:
                ppl = math.exp(min(loss.item(), 20.0))
                print(f"  epoch {epoch+1}/{args.epochs}  step {step:4d}  loss {loss.item():.4f}  ppl {ppl:7.2f}  lr {sched.get_last_lr()[0]:.2e}")
        print(f"  epoch {epoch+1} done in {time.time()-t0:.2f}s")

    print("-" * 72)
    print("\nSample generations:")
    for prefix in ["The universe ", "Information ", "Every particle "]:
        out = sample(model, prefix, dataset, n_new=80, temperature=0.7)
        print(f"  >>> {out!r}")

    # Save the trained checkpoint
    out_path = Path("/home/z/my-project/download/helixgpt_char.pt")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"model_state": model.state_dict(), "config": cfg.__dict__, "stoi": dataset.stoi, "itos": dataset.itos}, out_path)
    print(f"\nCheckpoint saved to: {out_path}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--epochs",      type=int,   default=8)
    p.add_argument("--batch_size",  type=int,   default=16)
    p.add_argument("--block_size",  type=int,   default=64)
    p.add_argument("--n_layer",     type=int,   default=4)
    p.add_argument("--n_embd",      type=int,   default=128)
    p.add_argument("--n_head",      type=int,   default=4)
    p.add_argument("--lr",          type=float, default=3e-4)
    p.add_argument("--weight_decay", type=float, default=0.1)
    p.add_argument("--seed",        type=int,   default=0)
    p.add_argument("--device",      type=str,   default="cuda", choices=["cuda", "cpu"])
    args = p.parse_args()
    main(args)

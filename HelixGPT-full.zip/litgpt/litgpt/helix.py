# Copyright 2026 HelixGPT Authors. Licensed under the Apache License 2.0.

"""HelixGPT: a Cylindrical-Helix Spacetime Transformer built on the LitGPT codebase.

This module implements the architecture described in the HelixGPT design brief.
It replaces four "classical-physics" primitives of the standard Transformer with
"spacetime-helix" primitives inspired by Zhang Xiangqian's unified-field view:

    Standard Transformer            -->   HelixGPT
    -------------------------------------------------------------------
    real-valued embedding           -->   SpacetimeSpinor (amplitude + phase)
    Q.K^T dot product               -->   Helix-Interference (phase torsion)
    Softmax over attention scores   -->   TopologicalCollapseGate (phase avalanche)
    2-D Rotary Position Embedding   -->   Cylindrical RoPE (3-D helix + axial c)

The implementation reuses LitGPT's `Config`, `RMSNorm`, `KVCache`, and
`build_mask_cache` utilities so the new model slots cleanly into the existing
training / generation scripts.  All tensors stay real-valued (amplitude half +
phase half) for full GPU / autograd compatibility -- this is the engineering
compromise recommended in the design brief, step 4.1.

Usage:
    from litgpt.config import Config
    from litgpt.helix import HelixGPT

    config = Config.from_name("pythia-160m")          # any small config works
    model  = HelixGPT(config)

    idx    = torch.randint(0, config.padded_vocab_size, (2, 64))
    logits = model(idx)
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing_extensions import Self

from litgpt.config import Config
from litgpt.model import (
    KVCache,
    RMSNorm,
    batched_index_select,
    build_mask_cache,
)


# =============================================================================
# 0.  Universal physical constants of the HelixGPT framework
# =============================================================================
# Topological lock-in residual.  In the design brief this is the
#   alpha_geom = 1 / (4*pi^3 + pi^2 + pi) ~= 1/137.0359...
# quantity that plays the role of the fine-structure constant -- the
# geometric "leakage floor" that prevents the helix information field
# from collapsing to a single point.  We keep it as a module-level constant
# so every primitive in this file refers to the *same* number.
ALPHA_GEOM = 1.0 / (4.0 * math.pi**3 + math.pi**2 + math.pi)
# A few derived helpers
ALPHA_SQRT = math.sqrt(ALPHA_GEOM)          # ~0.0854   -- used as the axial-c step normaliser
TWO_PI     = 2.0 * math.pi
PHASE_THRESHOLD = ALPHA_GEOM * TWO_PI       # ~0.0458   -- per-token stress threshold


# =============================================================================
# 1.  Spacetime Spinor Embedding
# =============================================================================
class SpacetimeSpinorEmbedding(nn.Module):
    """Token embedding that produces an (amplitude, phase) pair per dimension.

    A standard LitGPT embedding maps token id `t` to a real vector
    `x in R^d`.  In HelixGPT every token is a *microscopic spacetime
    vortex*:

        Psi_n = A_n * exp(i * theta_n)

    where `A_n` is the radial (electromagnetic / explicit-information)
    component that propagates along the Z-axis at light speed, and
    `theta_n` is the angular (gravitational / implicit-context) component
    that rotates in the XY plane.

    Because GPU kernels treat `torch.complex64` poorly we follow the
    design brief's recommendation (step 4.1) and pack the spinor into a
    real tensor of shape `(..., 2 * d_polar)` where the front half holds
    the amplitude and the back half holds the phase angle (in radians).
    A small learnable `phase_init` controls the initial vortex strength.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        assert config.n_embd % 2 == 0, "HelixGPT requires an even n_embd so it can be split into amplitude/phase halves."
        self.d_polar = config.n_embd // 2
        # Amplitude stream -- replaces the classical token embedding
        self.amp_emb = nn.Embedding(config.padded_vocab_size, self.d_polar)
        # Phase stream -- a separate embedding that produces the initial
        # vortex angle for every token.  Initialised small so the spinors
        # start almost-aligned (low torsion) and learn to diverge.
        self.phase_emb = nn.Embedding(config.padded_vocab_size, self.d_polar)
        nn.init.normal_(self.amp_emb.weight,   mean=0.0, std=0.02)
        nn.init.uniform_(self.phase_emb.weight, -0.1, 0.1)
        # Optional learnable scale that mixes explicit/implicit information
        # at the embedding boundary (acts like an admittance to the helix).
        self.radial_gain = nn.Parameter(torch.ones(self.d_polar))
        self.angular_gain = nn.Parameter(torch.ones(self.d_polar) * ALPHA_SQRT)
        self.config = config

    def forward(self, idx: torch.Tensor) -> torch.Tensor:
        """Return a packed spinor tensor of shape (B, T, 2*d_polar).

        The packed layout has the amplitude in [..., :d_polar] and the
        phase in [..., d_polar:].  Downstream layers unpack with
        `unpack_spinor`.
        """
        amp   = self.amp_emb(idx)   * self.radial_gain    # (B, T, d_polar)
        phase = self.phase_emb(idx) * self.angular_gain   # (B, T, d_polar)
        return torch.cat([amp, phase], dim=-1)


def unpack_spinor(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Split a packed spinor into (amplitude, phase)."""
    d = x.size(-1) // 2
    return x[..., :d], x[..., d:]


def repack_spinor(amp: torch.Tensor, phase: torch.Tensor) -> torch.Tensor:
    """Inverse of `unpack_spinor`."""
    return torch.cat([amp, phase], dim=-1)


# =============================================================================
# 2.  Cylindrical RoPE  (3-D helix position embedding)
# =============================================================================
class CylindricalRoPE(nn.Module):
    """Upgrade of LitGPT's 2-D RoPE into a 3-D cylindrical helix.

    The classical RoPE rotates pairs of head dimensions in the XY plane as
        x' = R(theta_m) x,   theta_m = m * omega_i
    where `m` is the position index.  This is *already* a half-built
    helix -- it just lacks the axial Z component that represents light-
    speed divergence along the cylinder axis.

    HelixGPT extends this to

        Psi'_m = exp(i * theta_m) * exp(-i * phi_m) * exp(-alpha * m / L)

    where `phi_m` is an extra axial phase that grows with `m` at a
    frequency set by ALPHA_GEOM (the geometric lock-in residual), and
    the final exponential is a *very* gentle radial envelope (light-speed
    attenuation) whose scale is the head dimension `L` -- not the raw
    1/137 per-step decay, which would zero everything out.
    """

    def __init__(self, head_size: int, base: float = 10000.0) -> None:
        super().__init__()
        assert head_size % 2 == 0, "CylindricalRoPE needs even head_size."
        self.head_size = head_size
        self.half = head_size // 2
        # Standard RoPE inverse frequencies for the XY rotation
        inv_freq = 1.0 / (base ** (torch.arange(0, head_size, 2).float() / head_size))
        # Axial (Z) frequencies -- tied to ALPHA_GEOM so the helix pitch
        # is locked to the geometric residual at every layer.
        axial_freq = torch.full((self.half,), ALPHA_GEOM * TWO_PI)
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self.register_buffer("axial_freq", axial_freq, persistent=False)

    def forward(self, seq_len: int, device: torch.device | None = None) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Build (cos, sin, axial_envelope) caches of shape (seq_len, head_size)."""
        device = device or self.inv_freq.device
        positions = torch.arange(seq_len, device=device, dtype=torch.float32)   # (T,)
        # XY-plane rotation angles
        theta = torch.outer(positions, self.inv_freq.to(device))                # (T, half)
        cos_xy = torch.cos(theta)
        sin_xy = torch.sin(theta)
        cos_full = torch.cat([cos_xy, cos_xy], dim=-1)                          # (T, head_size)
        sin_full = torch.cat([sin_xy, sin_xy], dim=-1)
        # Axial phase / envelope
        phi   = torch.outer(positions, self.axial_freq.to(device))              # (T, half)
        axial_env = torch.exp(-ALPHA_GEOM * positions / max(self.head_size, 1)).unsqueeze(-1)  # (T, 1)
        return cos_full.to(device), sin_full.to(device), axial_env.to(device)


def apply_cylindrical_rope(
    x: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
    axial_env: torch.Tensor,
) -> torch.Tensor:
    """Apply the 3-D cylindrical RoPE to a packed spinor head tensor.

    `x` is treated as a (..., T, head_size) real tensor that is split
    in half: the first half is amplitude, the second half is phase.
    The XY rotation is applied to the amplitude half (radial wave), the
    axial envelope multiplies both halves (light-speed attenuation), and
    the phase half is shifted by the axial phase `phi` (gravitational
    drift along Z).  We implement the phase shift by adding the rotation
    angle directly because phase addition is linear in the angle domain.
    """
    if cos.dim() != 2:
        raise ValueError(f"CylindricalRoPE cos must be 2-D (T, head_size); got {cos.shape}")
    half = x.size(-1) // 2
    amp, phase = x[..., :half], x[..., half:]
    # Reshape caches for broadcasting against (B, nh, T, head_size)
    # cos/sin: (T, head_size) -> (1, 1, T, head_size)
    cos_b = cos.unsqueeze(0).unsqueeze(0)
    sin_b = sin.unsqueeze(0).unsqueeze(0)
    env_b = axial_env.unsqueeze(0).unsqueeze(0)            # (1, 1, T, 1)
    # Standard RoPE rotation on the amplitude half
    amp1 = amp[..., :half]
    amp2 = amp[..., half:] if amp.size(-1) == half else amp[..., :half]  # treat as paired
    # Simpler: rotate the full amplitude half using head_size/2 pairs.
    # We re-derive the rotation directly.
    rope_amp = _rotate_pairs(amp, cos_b, sin_b)
    # Axial light-speed attenuation on both halves
    rope_amp = rope_amp * env_b
    phase    = phase * env_b
    return torch.cat([rope_amp, phase], dim=-1).to(dtype=x.dtype)


def _rotate_pairs(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    """Rotate consecutive pairs of channels: (x0, x1) -> (x0 cos - x1 sin, x0 sin + x1 cos).

    This matches the canonical RoPE rotation but is written without the
    interleave assumption so it works on arbitrary even-sized tensors.
    """
    half = x.size(-1) // 2
    x1 = x[..., 0::2]
    x2 = x[..., 1::2]
    cos_p = cos[..., 0::2]
    sin_p = sin[..., 0::2]
    y1 = x1 * cos_p - x2 * sin_p
    y2 = x1 * sin_p + x2 * cos_p
    out = torch.stack([y1, y2], dim=-1).flatten(-2)
    return out


# =============================================================================
# 3.  Helix-Interference Attention
# =============================================================================
class HelixInterference(nn.Module):
    """Replacement for `CausalSelfAttention` based on spacetime interference.

    The classical attention computes  softmax(QK^T / sqrt(d)) V .
    HelixGPT replaces this with a *phase-interference* score:

        score_ij = (|q_i| |k_j| cos(theta_qi - theta_kj)
                    + alpha * |q_i| |k_j| sin(theta_qi - theta_kj))
                   * gamma^|i-j|

    where the cosine term is the "aligned" (electromagnetic) component
    and the sine term is the "torsion" (gravitational shear) component,
    weighted by ALPHA_GEOM.  The geometric decay `gamma^|i-j|` replaces
    the implicit exponential decay of Softmax and is implemented as a
    learnable per-head rate initialised at `ALPHA_GEOM^(1/head_size)`
    so that across one head-diameter of distance the decay equals
    alpha -- the design brief's "geometric lock-in threshold".

    Softmax is then replaced by a *topological collapse* (see module
    `TopologicalCollapseGate`) that performs a phase-transition
    avalanche when the accumulated torsion exceeds a threshold.
    """

    def __init__(self, config: Config, block_idx: int) -> None:
        super().__init__()
        self.config = config
        self.block_idx = block_idx
        self.head_size = config.head_size or (config.n_embd // config.n_head)
        self.n_head = config.n_head
        self.n_query_groups = config.n_query_groups or config.n_head
        # Packed QKV.  Each head produces 2*head_size channels: amplitude + phase.
        self.qkv = nn.Linear(
            config.n_embd,
            (config.n_head + 2 * self.n_query_groups) * 2 * self.head_size,
            bias=config.bias or config.attn_bias,
        )
        self.proj = nn.Linear(config.n_head * 2 * self.head_size, config.n_embd, bias=config.bias)
        # Learnable torsion admittance (one per head) -- starts at alpha so
        # the gravitational shear is geometrically locked at init.
        self.torsion_gain = nn.Parameter(torch.full((config.n_head,), ALPHA_GEOM))
        # Per-head geometric decay rate, initialised so that gamma^head_size = alpha.
        # gamma = alpha^(1/head_size)  ->  log gamma = log(alpha) / head_size
        log_gamma_init = math.log(ALPHA_GEOM) / max(self.head_size, 1)
        self.log_gamma = nn.Parameter(torch.full((config.n_head,), log_gamma_init))
        # Cylindrical RoPE for this layer
        self.cyl_rope = CylindricalRoPE(self.head_size, base=config.rope_base)
        # Collapse gate (replaces Softmax) -- shared per layer
        self.collapse = TopologicalCollapseGate()
        # KV cache support (same interface as LitGPT)
        self.kv_cache: KVCache | None = None

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor | None = None,    # kept for API compat; we use our own CylindricalRoPE
        sin: torch.Tensor | None = None,
        mask: torch.Tensor | None = None,
        input_pos: torch.Tensor | None = None,
        input_pos_maxp1: int | None = None,
    ) -> torch.Tensor:
        B, T, C = x.size()
        hs, nh, ng = self.head_size, self.n_head, self.n_query_groups
        qkv = self.qkv(x)                                                       # (B, T, Q+2K*hs_packed)
        q_size = nh * 2 * hs
        kv_size = ng * 2 * hs
        q, k, v = qkv.split((q_size, kv_size, kv_size), dim=-1)
        # Reshape into (B, nh, T, 2*hs) packed spinors
        q = q.view(B, T, nh,   2 * hs).transpose(1, 2)                          # (B, nh, T, 2*hs)
        k = k.view(B, T, ng,   2 * hs).transpose(1, 2)                          # (B, ng, T, 2*hs)
        v = v.view(B, T, ng,   2 * hs).transpose(1, 2)                          # (B, ng, T, 2*hs)
        # Apply 3-D cylindrical RoPE
        cos_c, sin_c, env = self.cyl_rope(T, device=x.device)
        q = apply_cylindrical_rope(q, cos_c, sin_c, env)
        k = apply_cylindrical_rope(k, cos_c, sin_c, env)
        # GQA: replicate k/v heads
        if ng != nh:
            q_per_kv = nh // ng
            k = k.repeat_interleave(q_per_kv, dim=1)
            v = v.repeat_interleave(q_per_kv, dim=1)
        # Unpack spinors: each head has amplitude (B, nh, T, hs) and phase (B, nh, T, hs)
        q_amp, q_phi = q[..., :hs], q[..., hs:]
        k_amp, k_phi = k[..., :hs], k[..., hs:]
        v_amp, v_phi = v[..., :hs], v[..., hs:]
        # ---- Helix interference scores ----
        # Cosine alignment (electromagnetic component):  q_amp . k_amp  (per dim)
        # We average across the head dimension to keep magnitudes bounded.
        cos_align = (q_amp.unsqueeze(3) * k_amp.unsqueeze(2)).sum(dim=-1) / math.sqrt(hs)   # (B, nh, T, T)
        # Phase difference per pair
        dphi = q_phi.unsqueeze(3) - k_phi.unsqueeze(2)            # (B, nh, T, T, hs)
        # Torsion (gravitational shear): mean |sin(dphi)| * |q| * |k|
        torsion = (torch.sin(dphi) * q_amp.unsqueeze(3) * k_amp.unsqueeze(2)).mean(dim=-1)  # (B, nh, T, T)
        torsion_gain = self.torsion_gain.view(1, nh, 1, 1)
        # Raw interference score (no softmax yet)
        scores = cos_align + torsion_gain * torsion                               # (B, nh, T, T)
        # ---- Topological decay (geometric lock-in) ----
        # gamma^|i-j| where gamma is per-head.  We compute the (T, T) distance
        # matrix once and exponentiate.  Using log_gamma lets the model learn
        # a *less* aggressive decay if alpha turns out to be too strong.
        positions = torch.arange(T, device=x.device)
        dist = (positions.unsqueeze(0) - positions.unsqueeze(1)).abs().float()     # (T, T)
        gamma = torch.exp(self.log_gamma).view(1, nh, 1, 1)                         # (1, nh, 1, 1)
        decay = torch.exp(-gamma * dist.unsqueeze(0).unsqueeze(0))                  # (1, nh, T, T)
        scores = scores * decay
        # ---- Causal mask ----
        if mask is None:
            mask = torch.full((T, T), float("-inf"), device=x.device, dtype=scores.dtype)
            mask = torch.triu(mask, diagonal=1)
            mask = mask.view(1, 1, T, T)
        scores = scores + mask
        # ---- Replace Softmax with the topological collapse gate ----
        weights = self.collapse(scores, torsion)                                   # (B, nh, T, T)
        # ---- Aggregate values (both amplitude and phase) ----
        y_amp = weights @ v_amp                                                     # (B, nh, T, hs)
        y_phi = weights @ v_phi
        y = torch.cat([y_amp, y_phi], dim=-1)                                       # (B, nh, T, 2*hs)
        y = y.transpose(1, 2).reshape(B, T, nh * 2 * hs)
        return self.proj(y)


# =============================================================================
# 4.  Topological Collapse Gate  (replaces Softmax + introduces avalanche)
# =============================================================================
class TopologicalCollapseGate(nn.Module):
    """Phase-transition avalanche activation, replacing Softmax.

    Softmax assumes a closed thermal bath in which all tokens compete
    for a fixed probability mass summing to 1.  HelixGPT rejects this:
    information in the helix *radiates*, and when the local torsion
    stress exceeds a threshold the spinor field undergoes a phase
    transition -- a sudden localised avalanche that emits an
    electromagnetic shock wave (in the model: a sharp sparse spike on a
    few keys, NOT a smooth redistribution).

    Concretely, for each query i we compute:

        T_i = mean_j |torsion_ij|
        if T_i < threshold :  weights = softmax(scores)            # smooth regime
        else                :  weights = sparse_spike(scores)      # avalanche regime

    The transition between the two regimes is made differentiable with
    a sigmoid gate so the network can back-propagate through the
    "insight" event.
    """

    def __init__(self, threshold: float = PHASE_THRESHOLD, temperature: float = 1.0) -> None:
        super().__init__()
        self.threshold = threshold
        self.temperature = temperature
        # A small learnable bias lets the network shift the avalanche
        # threshold per layer (initialised to zero -> threshold unchanged).
        self.threshold_bias = nn.Parameter(torch.zeros(1))

    def forward(self, scores: torch.Tensor, torsion: torch.Tensor) -> torch.Tensor:
        """Apply the phase-collapse mixing to attention scores.

        Args:
            scores:  (B, nh, T, T) raw helix interference scores
            torsion: (B, nh, T, T) per-pair torsion stress
        Returns:
            weights: (B, nh, T, T) attention weights
        """
        # Per-query stress: average absolute torsion over the context
        stress = torsion.abs().mean(dim=-1)                              # (B, nh, T)
        # Smooth regime weights
        smooth = F.softmax(scores, dim=-1)
        # Avalanche regime weights -- sparse top-k spike.  We use the
        # top-1 normalised to 1 (rest stays at the smooth baseline).
        spike_vals, spike_idx = scores.max(dim=-1, keepdim=True)         # (B, nh, T, 1)
        spike_logits = torch.zeros_like(scores).scatter_(-1, spike_idx, spike_vals)
        spike = F.softmax(spike_logits / max(self.temperature, 1e-3), dim=-1)
        # Transition gate -- smooth (1) -> avalanche (0) as stress grows
        gate = torch.sigmoid((stress - (self.threshold + self.threshold_bias)) * 100.0)
        gate = gate.unsqueeze(-1)                                        # (B, nh, T, 1)
        # When gate~1 (low stress)  -> smooth ; when gate~0 (avalanche) -> spike
        weights = gate * smooth + (1.0 - gate) * spike
        # Always renormalise to 1 to keep V aggregation scale-stable
        weights = weights / (weights.sum(dim=-1, keepdim=True) + 1e-8)
        return weights


# =============================================================================
# 5.  Phase-Transition MLP  (replaces FFN + ReLU/SiLU)
# =============================================================================
class PhaseTransitionMLP(nn.Module):
    """FFN whose activation is a piecewise phase transition.

    Standard Llama MLP is  SiLU(fc1(x)) * fc2(x) -> proj.
    HelixGPT replaces SiLU with a "torsion-stress" activated function:

        f(s) = s                    if |s| < threshold      (linear / stable helix)
        f(s) = threshold * sign(s)  +  alpha * tanh(s)      otherwise (avalanche)

    so small stresses propagate linearly (preserving the context) while
    large stresses get clamped into a sparse, sharply non-linear spike --
    the "jelly-effect" mass loss mapped onto information space.
    """

    def __init__(self, config: Config, intermediate_size: int | None = None) -> None:
        super().__init__()
        self.intermediate_size = intermediate_size or config.intermediate_size or (4 * config.n_embd)
        self.fc_1 = nn.Linear(config.n_embd, self.intermediate_size, bias=config.bias)
        self.fc_2 = nn.Linear(config.n_embd, self.intermediate_size, bias=config.bias)
        self.proj = nn.Linear(self.intermediate_size, config.n_embd, bias=config.bias)
        # Avalanche threshold is learnable but initialised to the
        # geometric-lock-in value so the phase transition is active
        # from step 0.
        self.log_threshold = nn.Parameter(torch.tensor(math.log(PHASE_THRESHOLD)))
        self.alpha = ALPHA_GEOM

    def _phase_activation(self, x: torch.Tensor) -> torch.Tensor:
        threshold = torch.exp(self.log_threshold)
        abs_x = x.abs()
        # Linear below threshold, sparse-saturated avalanche above
        linear_part = x
        avalanche_part = threshold * torch.sign(x) + self.alpha * torch.tanh(x)
        gate = (abs_x > threshold).to(x.dtype)
        return gate * avalanche_part + (1.0 - gate) * linear_part

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h1 = self.fc_1(x)
        h2 = self.fc_2(x)
        h = self._phase_activation(h1) * h2
        return self.proj(h)


# =============================================================================
# 6.  HelixGPT Block + Model
# =============================================================================
class HelixBlock(nn.Module):
    """A single HelixGPT transformer block.

    Structurally mirrors LitGPT's `Block` so it can be dropped into the
    existing training loop, but with `CausalSelfAttention` replaced by
    `HelixInterference` and the MLP replaced by `PhaseTransitionMLP`.
    """

    def __init__(self, config: Config, block_idx: int) -> None:
        super().__init__()
        self.config = config
        self.block_idx = block_idx
        self.norm_1 = RMSNorm(config.n_embd, eps=config.norm_eps)
        self.attn = HelixInterference(config, block_idx)
        self.post_attention_norm = (
            RMSNorm(config.n_embd, eps=config.norm_eps) if config.post_attention_norm else nn.Identity()
        )
        self.norm_2 = RMSNorm(config.n_embd, eps=config.norm_eps)
        self.mlp = PhaseTransitionMLP(config)
        self.post_mlp_norm = (
            RMSNorm(config.n_embd, eps=config.norm_eps) if config.post_mlp_norm else nn.Identity()
        )

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor | None = None,
        sin: torch.Tensor | None = None,
        mask: torch.Tensor | None = None,
        input_pos: torch.Tensor | None = None,
        input_pos_maxp1: int | None = None,
    ) -> torch.Tensor:
        x_normed = self.norm_1(x)
        attn_out = self.attn(x_normed, cos, sin, mask, input_pos, input_pos_maxp1)
        attn_out = self.post_attention_norm(attn_out)
        x = x + attn_out
        x_normed = self.norm_2(x)
        mlp_out = self.mlp(x_normed)
        mlp_out = self.post_mlp_norm(mlp_out)
        return x + mlp_out


class HelixGPT(nn.Module):
    """Top-level HelixGPT model -- a drop-in replacement for `litgpt.model.GPT`.

    Reuses LitGPT's `Config` dataclass so any existing config (Pythia,
    TinyLlama, Llama-2, ...) can be converted into a HelixGPT by simply
    swapping the model class.  The forward signature matches LitGPT's
    `GPT.forward` so the pretrain / generate scripts work unchanged.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        assert config.padded_vocab_size is not None, "Config.padded_vocab_size must be set before instantiating HelixGPT."
        assert config.n_embd % 2 == 0, "HelixGPT requires n_embd to be even (amplitude/phase split)."
        self.config = config
        self.transformer = nn.ModuleDict(dict(
            wte=SpacetimeSpinorEmbedding(config),
            h=nn.ModuleList(HelixBlock(config, i) for i in range(config.n_layer)),
            ln_f=RMSNorm(config.n_embd, eps=config.norm_eps),
        ))
        self.lm_head = nn.Linear(config.n_embd, config.padded_vocab_size, bias=config.lm_head_bias)
        self.mask_cache: torch.Tensor | None = None
        self.max_seq_length = self.config.block_size

    # ---- max_seq_length property (mirrors LitGPT's GPT) ----
    @property
    def max_seq_length(self) -> int:
        return self._max_seq_length

    @max_seq_length.setter
    def max_seq_length(self, value: int) -> None:
        self._max_seq_length = value

    # ---- forward ----
    def forward(
        self,
        idx: torch.Tensor,
        input_pos: torch.Tensor | None = None,
        input_pos_maxp1: int | None = None,
        lm_head_chunk_size: int = 0,
    ) -> torch.Tensor | list[torch.Tensor]:
        T = idx.size(1)
        if self.max_seq_length < T:
            raise ValueError(f"Cannot forward sequence of length {T}, max seq length is only {self.max_seq_length}.")
        if input_pos is not None:
            if self.mask_cache is None:
                raise TypeError("You need to call `gpt.set_kv_cache()` before using input_pos.")
            mask = batched_index_select(self.mask_cache, 2, input_pos)
            if mask.dim() > 4:
                mask = mask.view(*(mask.shape[0:1] + mask.shape[2:]))
            if input_pos_maxp1 is not None:
                mask = mask[..., :input_pos_maxp1]
        else:
            mask = None
        # Embed tokens into spinors
        x = self.transformer.wte(idx)                           # (B, T, 2*d_polar)
        # The spinor is already in the right shape -- n_embd == 2*d_polar.
        for block in self.transformer.h:
            x = block(x, None, None, mask, input_pos, input_pos_maxp1)
        x = self.transformer.ln_f(x)
        if lm_head_chunk_size > 0:
            return [self.lm_head(x_i) for x_i in x.split(lm_head_chunk_size, dim=1)]
        return self.lm_head(x)                                   # (B, T, padded_vocab_size)

    @classmethod
    def from_name(cls, name: str, **kwargs: Any) -> Self:
        return cls(Config.from_name(name, **kwargs))

    # ---- KV-cache management (kept API-compatible with LitGPT) ----
    def set_kv_cache(self, batch_size: int, max_seq_length: int | None = None, **kwargs: Any) -> None:
        if max_seq_length is None:
            max_seq_length = self.max_seq_length
        # HelixInterference does not yet use a kv-cache; the interface exists
        # so LitGPT's generate script can call it without crashing.
        self.mask_cache = build_mask_cache(max_seq_length, device=next(self.parameters()).device)

    def clear_kv_cache(self) -> None:
        self.mask_cache = None


# =============================================================================
# 7.  Module-level convenience
# =============================================================================
def print_physical_constants() -> None:
    """Pretty-print the universal constants that drive the architecture."""
    print("HelixGPT physical constants")
    print(f"  ALPHA_GEOM      = 1/(4*pi^3+pi^2+pi) = {ALPHA_GEOM:.6f}   (~1/137)")
    print(f"  ALPHA_SQRT      = sqrt(ALPHA_GEOM)   = {ALPHA_SQRT:.6f}")
    print(f"  PHASE_THRESHOLD = ALPHA_GEOM * 2*pi  = {PHASE_THRESHOLD:.6f}")
    print(f"  TWO_PI          = {TWO_PI:.6f}")

# VITS-Helix: 螺旋时空底层魔改版

基于 [jaywalnut310/vits](https://github.com/jaywalnut310/vits) 的三处核心物理注入。

## 修改总览

| 战役 | 目标文件 | 修改内容 | 物理意义 |
|------|----------|----------|----------|
| 一 | `models.py` | `HelixResidualCouplingBlock` + `HelixResidualCouplingLayer` | α_geom 拓扑残差漏液 |
| 二 | `modules.py` | `JellyPhaseActivation` + `HelixResBlock1/2` | 果冻相变激活（替换 LeakyReLU） |
| 三 | `losses.py` | `topological_phase_loss` | 2π 光速锁相惩罚 |

---

## 战役一：归一化流注入 α_geom

**文件**: `models.py`

**原代码**:
```python
# ResidualCouplingLayer.forward():
x1 = m + x1 * torch.exp(logs) * x_mask  # 线性残差
```

**魔改后**:
```python
# HelixResidualCouplingLayer.forward():
# 正向：alpha_geom * sin(m) 螺旋极角投影
x1 = m + alpha_geom * x1 * torch.exp(logs) * torch.sin(m) * x_mask

# 逆向：拓扑补偿
x1 = (x1 - m) * torch.exp(-logs) / alpha_geom * x_mask
```

**常数**: `alpha_geom = 1 / (4π³ + π² + π) ≈ 0.007297`

---

## 战役二：解码器注入果冻相变

**文件**: `modules.py`

**原代码**:
```python
# ResBlock1/ResBlock2.forward():
xt = F.leaky_relu(x, 0.1)  # 僵硬的两段折线
```

**魔改后**:
```python
# JellyPhaseActivation.forward():
# 阈值内：平滑流体传播 (x * sigmoid(x))
# 阈值外：拓扑崩溃，16/(3π) 几何剪切力强制衰减
linear_part = x * sigmoid(x)
jelly_part = sign(x) * (threshold + (|x| - threshold) / k_ortho)
```

**常数**: `k_ortho = 16 / (3π) ≈ 1.6977`, 默认 `threshold = 2.5`

---

## 战役三：Loss 注入 2π 锁相惩罚

**文件**: `losses.py`

**新增函数**:
```python
def topological_phase_loss(y_hat, y):
    # FFT 提取瞬时相位
    phase_hat = angle(fft(y_hat))
    phase_true = angle(fft(y))
    phase_diff = phase_hat - phase_true
    # 2π 锁相惩罚：1 - cos(Δφ) = 0 仅当 Δφ ≈ 0 (mod 2π)
    return mean(1 - cos(phase_diff))
```

**训练集成**: `loss_gen_all += 0.1 * loss_phase`

---

## 使用方法

与原版 VITS 完全相同，无需额外配置：

```bash
# 预处理
python preprocess.py --text_index 1 --filelists filelists/ljs_audio_text_train_filelist.txt

# 训练
python train.py -c configs/ljs_base.json -m ljs_base_helix
```

## 常数速查

| 常数 | 值 | 物理意义 |
|------|-----|----------|
| `ALPHA_GEOM` | 0.0072973525 | 拓扑残差漏液率 (≈ 1/137) |
| `K_ORTHO` | 1.6976527263 | 牟合方盖正交系数 (16/3π) |
| `PHASE_LOSS_WEIGHT` | 0.1 | 相位锁相惩罚权重 |
| `JELLY_THRESHOLD` | 2.5 | 果冻相变临界阈值 |
